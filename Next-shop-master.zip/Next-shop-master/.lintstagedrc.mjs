import path from 'path';

const buildEslintCommand = filenames =>
  `next lint --fix --file ${filenames
    .map(f => path.relative(process.cwd(), f))
    .join(' --file ')}`;

const lintStagedObject = {
  '*.{js,jsx,ts,tsx}': [
    buildEslintCommand,
    'prettier --write --ignore-unknown',
  ],
};

export default lintStagedObject;
