'use client';

import type {
  CreateOrderRequest,
  DadataAddress,
  DeliverySubTypeParam,
  DeliveryType,
  PaymentType,
  Shop,
} from '@/lib/gigma/types';
import type {
  FieldErrors,
  Path,
  Resolver,
  SubmitHandler,
} from 'react-hook-form';

import { Fragment, useCallback, useEffect, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import op from 'object-path';
import { FormProvider, useForm } from 'react-hook-form';
import { twJoin } from 'tailwind-merge';

import { CardItem, useShop, useUser } from '@/app/components/layout/context';
import {
  createOrder,
  getDeliverySubTypeParams,
  getDeliverySubTypes,
} from '@/lib/gigma';
import { money } from '@/lib/utils';
import { Button, Checkbox } from '@/ui/components';
import { ChevronLeft } from '@/ui/components/Icons';
import { DadataField, SelectField } from '@/ui/fields';

import { Calc } from '../../components/Calc';

const SELF_PICK_TYPE_ID = 1;
const COURIER_TYPE_ID = 2;
const OFFICE_TYPE_ID = 1;

export type ProductsProps = {
  card: CardItem[];
  onRemove: (product: CardItem['product']) => void;
  onToggle: (cardItem: CardItem) => void;
};

type FormValues = {
  deliveryType?: DeliveryType;
  deliverySubType?: DeliveryType;
  deliverySubTypeParam?: DeliverySubTypeParam;
  address?: DadataAddress;
  shop?: Shop;
  payment?: PaymentType;
};

export const Checkout = ({
  shops = [],
  deliveryTypes = [],
  paymentTypes = [],
}: {
  shops?: Shop[];
  deliveryTypes?: DeliveryType[];
  paymentTypes?: PaymentType[];
}) => {
  const [deliverySubTypes, setDeliverySubTypes] = useState<DeliveryType[]>([]);
  const [deliverySubTypeParams, setDeliverySubTypeParams] = useState<
    DeliverySubTypeParam[]
  >([]);

  const [step, setStep] = useState<
    'deliveryType' | 'deliverySubType' | 'payment'
  >('deliveryType');

  const { token, user } = useUser();

  const methods = useForm<FormValues>({
    mode: 'onSubmit',
    resolver,
    defaultValues: {
      shop: shops[0] ?? undefined,
      address: user?.counterparty?.address
        ? {
            name: user.counterparty.address,
            value: user.counterparty.address,
          }
        : undefined,
    },
  });

  const {
    control,
    handleSubmit,
    formState: { isSubmitting, errors },
    setError,
    clearErrors,
    watch,
    setValue,
  } = methods;

  const [deliveryType, deliverySubType, payment] = watch([
    'deliveryType',
    'deliverySubType',
    'payment',
  ]);

  const [showPayInstruments, setShowPayInstruments] = useState(false);

  const { getSelected } = useShop();

  const router = useRouter();
  const selected = getSelected();

  const onSubmit: SubmitHandler<FormValues> = useCallback(
    async ({
      deliveryType,
      deliverySubType,
      deliverySubTypeParam,
      shop,
      address,
      payment,
    }) => {
      clearErrors();

      if (step === 'deliveryType' && deliveryType?.id === SELF_PICK_TYPE_ID) {
        setStep('payment');
        return true;
      } else if (
        step === 'deliveryType' &&
        deliveryType?.id !== SELF_PICK_TYPE_ID
      ) {
        setStep('deliverySubType');
        return true;
      } else if (step === 'deliverySubType') {
        setStep('payment');
        return true;
      }

      const orderData = {
        token,
        products: selected.map(({ product, count }) => ({
          id: product.id,
          quantity: count,
        })),
        delivery_type_id: deliveryType!.id,
        payment_type_id: payment!.id,
      } as CreateOrderRequest;

      if (deliveryType?.id === SELF_PICK_TYPE_ID) {
        orderData.shop_id = shop!.id;
      } else {
        orderData.delivery_subtype_id = deliverySubType!.id;
      }

      if (deliverySubType?.id === OFFICE_TYPE_ID) {
        orderData.delivery_subtype_param_id = deliverySubTypeParam!.id;
      } else if (deliverySubType?.id === COURIER_TYPE_ID) {
        orderData.address = address!.value;
      }

      try {
        const orderResult = await createOrder(orderData);

        if (!orderResult) {
          throw new Error('Не удалось создать заказ');
        }

        if (orderResult?.order?.payment_link) {
          window.location.href = orderResult.order.payment_link;
        } else if (orderResult) {
          router.push('/success-payment');
        }
      } catch {
        setError('root', {
          type: 'custom',
          message: 'Не удалось создать заказ',
        });
      }
    },
    [step, clearErrors, token, selected, router, setError],
  );

  const setSubTypes = useCallback(
    async (deliveryType: DeliveryType) => {
      const subtypes = await getDeliverySubTypes(deliveryType.id);
      const items = subtypes?.deliverySubtypes ?? [];
      setDeliverySubTypes(items.filter(item => item.is_active));
      setValue('deliverySubType', items[0] ?? undefined);
    },
    [setValue],
  );

  const setSubTypeParams = useCallback(
    async (deliveryType: DeliveryType, deliverySubType: DeliveryType) => {
      const subTypeParams = await getDeliverySubTypeParams(
        deliveryType.id,
        deliverySubType.id,
      );
      const items = subTypeParams?.deliverySubtypeParams ?? [];
      setDeliverySubTypeParams(items);
      setValue('deliverySubTypeParam', items[0] ?? undefined);
    },
    [setValue],
  );

  const onBack = useCallback(() => {
    if (step === 'payment') {
      setStep(
        deliveryType?.id === SELF_PICK_TYPE_ID
          ? 'deliveryType'
          : 'deliverySubType',
      );
    }

    if (step === 'deliverySubType') {
      setStep('deliveryType');
    }

    if (step === 'deliveryType') {
      router.back();
    }
  }, [step, router, deliveryType]);

  useEffect(() => {
    if (!selected.length || !user) {
      router.replace('/card');
    }
  }, [selected.length, router, user]);

  useEffect(() => {
    if (deliveryType) setSubTypes(deliveryType);
  }, [setSubTypes, deliveryType]);

  useEffect(() => {
    if (deliveryType && deliverySubType)
      setSubTypeParams(deliveryType, deliverySubType);
  }, [setSubTypeParams, deliveryType, deliverySubType]);

  return (
    <FormProvider {...methods}>
      <button
        type='button'
        className='flex items-center gap-2 px-2 py-[6px]'
        onClick={onBack}
      >
        <ChevronLeft />
        Назад
      </button>
      <div className='mt-3 flex flex-col gap-6 md:flex-row'>
        <div className='flex-grow rounded bg-white dark:bg-contrast'>
          <div className='px-4 pb-0 pt-4 md:px-6 md:pb-6 md:pt-6'>
            <div className='text-lg font-bold leading-[132%]'>
              СПОСОБ ПОЛУЧЕНИЯ {step}
            </div>
          </div>
          <div className='overflow-hidden overflow-x-auto'>
            <table className='w-full'>
              <thead>
                <tr className='bg-gold text-xs text-white'>
                  <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
                    Выбрать
                  </th>
                  <th className='w-28 p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
                    Цена
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan={2} className='p-4'>
                    <div className='flex items-center gap-4'>
                      <Image
                        src={'/delivery.png'}
                        width={42}
                        height={42}
                        alt='Выберите способ получения'
                      />
                      <div className='text-sm leading-[22px]'>
                        Выберите способ получения
                      </div>
                    </div>
                  </td>
                </tr>
                {step === 'deliveryType' && (
                  <>
                    {deliveryTypes.map(type => {
                      return (
                        <Fragment key={type.id}>
                          <tr>
                            <td>
                              <div className='flex items-center'>
                                <Checkbox
                                  className='h-4 w-4 rounded-full'
                                  wrapperClassName='px-[42px] py-4 flex items-center text-xs leading-[132%] tracking-[4%] font-semibold'
                                  checked={deliveryType?.id === type.id}
                                  onChange={() => {
                                    setValue('deliveryType', type, {
                                      shouldValidate: true,
                                    });
                                  }}
                                />
                                <div>
                                  <div
                                    className={twJoin(
                                      'cursor-pointer p-4 text-sm leading-[22px]',
                                      !!errors.deliveryType?.message &&
                                        'text-error',
                                    )}
                                    onClick={() => {
                                      setValue('deliveryType', type, {
                                        shouldValidate: true,
                                      });
                                    }}
                                  >
                                    {type.name}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className='w-36 p-4 text-sm leading-[22px]'>
                              от {money(parseFloat(type.price ?? '0'))}
                            </td>
                          </tr>
                          <tr key={`${type.id}-select`}>
                            <td colSpan={2} className='px-[42px] pb-4'>
                              {type.id === deliveryType?.id &&
                                type.id === SELF_PICK_TYPE_ID && (
                                  <SelectField
                                    control={control}
                                    name='shop'
                                    options={shops}
                                    getOptionValue={o => o.id.toString()}
                                    getOptionLabel={o => o.name}
                                  />
                                )}
                            </td>
                          </tr>
                        </Fragment>
                      );
                    })}
                  </>
                )}
                {step === 'deliverySubType' && (
                  <>
                    {deliverySubTypes.map(type => {
                      return (
                        <Fragment key={type.id}>
                          <tr>
                            <td>
                              <div className='flex items-center'>
                                <Checkbox
                                  className='h-4 w-4 rounded-full'
                                  wrapperClassName='px-[42px] py-4 flex items-center text-xs leading-[132%] tracking-[4%] font-semibold'
                                  checked={deliverySubType?.id === type.id}
                                  onChange={() => {
                                    setValue('deliverySubType', type, {
                                      shouldValidate: true,
                                    });
                                  }}
                                />
                                <div>
                                  <div
                                    className='cursor-pointer p-4 text-sm leading-[22px]'
                                    onClick={() => {
                                      setValue('deliverySubType', type, {
                                        shouldValidate: true,
                                      });
                                    }}
                                  >
                                    {type.name}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className='w-36 p-4 text-sm leading-[22px]'>
                              от {money(parseFloat(type.price ?? '0'))}
                            </td>
                          </tr>
                          <tr key={`${type.id}-select`}>
                            <td colSpan={2} className='px-[42px] pb-4'>
                              {type.id === deliverySubType?.id &&
                                type.id === OFFICE_TYPE_ID && (
                                  <SelectField
                                    key={deliverySubType.id}
                                    control={control}
                                    name='deliverySubTypeParam'
                                    options={deliverySubTypeParams}
                                    getOptionValue={o => o.id.toString()}
                                    getOptionLabel={o => o.name}
                                  />
                                )}
                              {type.id === deliverySubType?.id &&
                                type.id === COURIER_TYPE_ID && (
                                  <DadataField
                                    key={deliverySubType.id}
                                    control={control}
                                    name='address'
                                  />
                                )}
                            </td>
                          </tr>
                        </Fragment>
                      );
                    })}
                  </>
                )}
              </tbody>
            </table>
          </div>
          {!!errors.root?.message && (
            <div className='bg-error p-4 text-white'>{errors.root.message}</div>
          )}
        </div>
        <div>
          <Calc
            buttonDisabled={isSubmitting}
            onSubmit={handleSubmit(onSubmit)}
          />
        </div>
      </div>
      {showPayInstruments && (
        <div className='fixed inset-0 z-50 flex items-center justify-center bg-auth-bg-light'>
          <div onClick={() => setShowPayInstruments(false)}>
            Выбор способа оплаты
          </div>
        </div>
      )}

      {step === 'payment' && (
        <div className='fixed inset-0 z-[60] bg-auth-bg-light pt-[150px]'>
          <div className='mx-auto max-w-[424px]'>
            <button
              type='button'
              className='flex items-center gap-2 p-2'
              onClick={onBack}
            >
              <ChevronLeft />
              Назад
            </button>
            <div className='rounded bg-white p-6 dark:bg-contrast'>
              <div className='p-6 text-center text-[20px] font-bold'>
                Выберите способ оплаты
              </div>
              <hr className='h-px bg-black/50' />
              <div className='mt-12 grid grid-cols-2 gap-6'>
                {paymentTypes.map(type => {
                  return (
                    <div
                      key={type.id}
                      className='group relative flex w-full cursor-pointer flex-col items-center gap-2 border px-6 pb-3 pt-2 duration-300 hover:border-gold'
                      onClick={() => {
                        setValue('payment', type, {
                          shouldValidate: true,
                        });
                      }}
                    >
                      <Image
                        src={type.photo}
                        alt={type.name}
                        width={80}
                        height={80}
                      />
                      <Checkbox
                        className={twJoin(
                          'hidden h-4 w-4 rounded-full group-hover:block',
                          payment?.id === type.id && 'block !bg-gold',
                        )}
                        wrapperClassName='absolute left-2 top-2'
                        checked={payment?.id === type.id}
                        onChange={() => {
                          setValue('payment', type, {
                            shouldValidate: true,
                          });
                        }}
                      />

                      <div className='text-xs font-semibold leading-[12px]'>
                        {type?.name}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            {!!errors.root?.message && (
              <div className='bg-error p-4 text-white'>
                {errors.root.message}
              </div>
            )}

            <Button className='mt-6 w-full' onClick={handleSubmit(onSubmit)}>
              Оформить заказ
            </Button>
          </div>
        </div>
      )}
    </FormProvider>
  );
};

const resolver: Resolver<FormValues> = data => {
  const errors = {} as FieldErrors<FormValues>;

  const setError = (path: Path<FormValues>, message?: string): void => {
    op.set(errors, path, { message: message ?? 'Отсутствует значение' });
  };

  const { deliveryType, deliverySubType, shop, deliverySubTypeParam, address } =
    data;
  console.log(deliveryType);

  if (!deliveryType?.id) {
    setError('deliveryType');
  }

  if (deliveryType?.id === SELF_PICK_TYPE_ID && !shop?.id) {
    setError('shop');
  } else if (
    !!deliveryType?.id &&
    deliveryType?.id !== SELF_PICK_TYPE_ID &&
    !deliverySubType?.id
  ) {
    setError('deliverySubType');
  }

  if (deliverySubType?.id === COURIER_TYPE_ID && !address?.name) {
    setError('address');
  } else if (
    deliverySubType?.id === OFFICE_TYPE_ID &&
    !deliverySubTypeParam?.id
  ) {
    setError('deliverySubTypeParam');
  }

  return {
    values: Object.keys(errors).length ? {} : data,
    errors: Object.keys(errors).length ? errors : {},
  };
};
