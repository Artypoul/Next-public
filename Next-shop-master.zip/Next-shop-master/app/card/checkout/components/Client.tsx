'use client';

import { useCallback, useEffect, useState } from 'react';
import dynamic from 'next/dynamic';

import { getDeliveryTypes, getPaymentTypes, getShops } from '@/lib/gigma';
import { DeliveryType, PaymentType, Shop } from '@/lib/gigma/types';

import { CardSkeleton } from '../../components/CardSkeleton';

const Checkout = dynamic(
  () => import('./Checkout').then(module => module.Checkout),
  {
    ssr: false,
    loading: () => <CardSkeleton />,
  },
);

export function Client() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [deliveryTypes, setDeliveryTypes] = useState<DeliveryType[]>([]);
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [loading, setLoading] = useState(true);

  const getData = useCallback(async () => {
    const shopsData = await getShops();
    const typesData = await getDeliveryTypes();
    const paymentTypes = await getPaymentTypes();
    setLoading(false);
    setShops(shopsData?.shops ?? []);
    setDeliveryTypes(
      (typesData?.deliveryType ?? []).filter(item => item.is_active),
    );
    setPaymentTypes(paymentTypes?.paymentTypes ?? []);
  }, []);

  useEffect(() => {
    getData();
  }, [getData]);

  if (loading) return <CardSkeleton />;

  return (
    <Checkout
      shops={shops}
      deliveryTypes={deliveryTypes}
      paymentTypes={paymentTypes}
    />
  );
}
