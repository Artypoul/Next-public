'use client';

import { useCallback, useEffect, useState } from 'react';
import CountUp from 'react-countup';

import { useShop } from '@/app/components/layout/context';
import { GetPriceResponse } from '@/lib/gigma/types';
import { money } from '@/lib/utils';
import { Button, Input } from '@/ui/components';

type CalcProps = {
  onSubmit?: () => void;
  buttonTitle?: string;
  buttonDisabled?: boolean;
};

export function Calc({
  onSubmit = () => {},
  buttonTitle = 'Далее',
  buttonDisabled = false,
}: CalcProps) {
  const [prices, setPrices] = useState<GetPriceResponse>({
    price: 0,
    discount: 0,
    total: 0,
  });
  const { card, getPrice } = useShop();

  const syncPrice = useCallback(async () => {
    const newPrice = await getPrice(card);
    setPrices(newPrice);
  }, [card, getPrice]);

  useEffect(() => {
    syncPrice();
  }, [syncPrice]);

  return (
    <div className='sticky top-[96px]'>
      <div className='w-full rounded bg-white dark:bg-contrast md:w-[378px]'>
        <div className='px-4 pb-6 pt-4 md:px-6 md:pt-6'>
          <div className='text-lg font-bold leading-[132%]'>
            Кратко о заказе
          </div>
        </div>
        <div className='px-4 pb-4 pt-0 md:px-6 md:pb-6'>
          <div className='flex flex-col gap-4'>
            <div className='flex items-center justify-between'>
              <div className='text-sm font-semibold leading-[132%] tracking-[4%] opacity-50'>
                Цена
              </div>
              <div className='text-sm font-semibold leading-[132%] tracking-[4%]'>
                <CountUp
                  end={prices.price}
                  formattingFn={money}
                  preserveValue
                  duration={0.3}
                  decimals={2}
                />
              </div>
            </div>
            <div className='flex items-center justify-between'>
              <div className='text-sm font-semibold leading-[132%] tracking-[4%] opacity-50'>
                Скидка
              </div>
              <div className='text-sm font-semibold leading-[132%] tracking-[4%]'>
                <CountUp
                  end={prices.discount}
                  formattingFn={money}
                  preserveValue
                  duration={0.3}
                  decimals={2}
                />
              </div>
            </div>
            <hr className='h-px bg-black/50' />
            <div className='flex flex-col gap-2'>
              <div className='flex items-center justify-between'>
                <div className='text-lg font-bold leading-[132%]'>Итого</div>
                <div className='text-sm font-semibold leading-[132%] tracking-[4%]'>
                  <CountUp
                    end={prices.total}
                    formattingFn={money}
                    preserveValue
                    duration={0.3}
                    decimals={2}
                  />
                </div>
              </div>
              <div className='text-right text-sm font-semibold leading-[132%] tracking-[4%] opacity-50'>
                (НДС включен если применимо)
              </div>
            </div>
          </div>
          <div className='relative mt-6'>
            <Input
              placeholder='Есть промокод?'
              className='rounded-lg border border-gold px-3.5 py-4 text-base font-semibold leading-[132%] tracking-[4%]'
            />
            <button
              type='button'
              className='absolute bottom-0 right-3.5 top-0 text-sm font-bold leading-6 text-gold'
            >
              Применить
            </button>
          </div>
        </div>
      </div>
      <div className='mt-6'>
        <Button
          className='w-full py-[13px] text-base font-medium leading-6'
          disabled={!prices.total || buttonDisabled}
          onClick={onSubmit}
        >
          {buttonTitle}
        </Button>
      </div>
    </div>
  );
}
