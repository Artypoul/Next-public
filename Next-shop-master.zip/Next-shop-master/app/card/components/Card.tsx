'use client';

import { ChangeEventHandler, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { twJoin } from 'tailwind-merge';

import { CardItem, useShop } from '@/app/components/layout/context';
import { useTailwindBreakpoint } from '@/hooks/useTailwindBreakpoint';
import { getNoun } from '@/lib/utils';
import { Checkbox } from '@/ui/components';
import { ChevronLeft, Close } from '@/ui/components/Icons';

import { Calc } from './Calc';
import { ProductsDesktop } from './ProductsDesktop';
import { ProductsMobile } from './ProductsMobile';

export type ProductsProps = {
  card: CardItem[];
  onRemove: (product: CardItem['product']) => void;
  onToggle: (cardItem: CardItem) => void;
};

export const Card = () => {
  const { card, removeProducts, totalCount, selectProducts, unselectProducts } =
    useShop();

  const { up } = useTailwindBreakpoint();
  const router = useRouter();

  const isDesktop = up('sm');

  const onSelectAll: ChangeEventHandler<HTMLInputElement> = useCallback(
    e => {
      const checked = e.target.checked;
      if (checked) {
        selectProducts('all');
      } else {
        unselectProducts('all');
      }
    },
    [selectProducts, unselectProducts],
  );

  const allSelected = useMemo(() => {
    return card.every(item => item.selected);
  }, [card]);

  const onRemove = useCallback(
    (product: CardItem['product']) => {
      removeProducts(product.id);
    },
    [removeProducts],
  );

  const onToggle = useCallback(
    (cardItem: CardItem) => {
      if (cardItem.selected) {
        unselectProducts([cardItem.product.id]);
      } else {
        selectProducts([cardItem.product.id]);
      }
    },
    [selectProducts, unselectProducts],
  );

  const onRemoveSelected = useCallback(() => {
    const selected = card.filter(item => item.selected);
    removeProducts(selected.map(item => item.product.id));
  }, [card, removeProducts]);

  const atLeastOneSelected = card.some(item => item.selected);

  return (
    <>
      <button
        type='button'
        className='flex items-center gap-2 px-2 py-[6px]'
        onClick={() => {
          router.back();
        }}
      >
        <ChevronLeft />
        Продолжить покупки
      </button>
      <div className='mt-3 flex flex-col gap-6 md:flex-row'>
        <div className='flex-grow rounded bg-white dark:bg-contrast'>
          <div className='px-4 pb-0 pt-4 md:px-6 md:pb-6 md:pt-6'>
            <div className='text-lg font-bold leading-[132%]'>Корзина</div>
            <div className='mt-1 text-xs leading-[132%] tracking-[4%] opacity-50'>
              ({totalCount} {getNoun(totalCount, 'товар', 'товара', 'товаров')})
            </div>
          </div>
          {!!totalCount && (
            <div className='px-4 py-[10px] md:px-6'>
              <div className='flex min-h-[43px] items-center gap-[43px] md:gap-[75px] md:px-4'>
                <Checkbox
                  className='h-4 w-4 rounded-full'
                  wrapperClassName='flex items-center text-xs leading-[132%] tracking-[4%] font-semibold'
                  label='Выбрать все'
                  checked={allSelected}
                  onChange={onSelectAll}
                />
                <button
                  type='button'
                  className={twJoin(
                    'flex items-center gap-2',
                    !atLeastOneSelected && 'opacity-50',
                  )}
                  onClick={onRemoveSelected}
                  disabled={!atLeastOneSelected}
                >
                  <Close className='h-4 w-4' />
                  <span className='text-xs font-semibold leading-[132%] tracking-[4%]'>
                    Удалить выбранные
                  </span>
                </button>
              </div>
            </div>
          )}
          {!!totalCount && isDesktop && (
            <ProductsDesktop
              card={card}
              onRemove={onRemove}
              onToggle={onToggle}
            />
          )}
          {!!totalCount && !isDesktop && (
            <ProductsMobile
              card={card}
              onRemove={onRemove}
              onToggle={onToggle}
            />
          )}
        </div>
        <div>
          <Calc
            onSubmit={() => {
              router.push('/card/checkout');
            }}
            buttonTitle='Оформить заказ'
          />
        </div>
      </div>
    </>
  );
};
