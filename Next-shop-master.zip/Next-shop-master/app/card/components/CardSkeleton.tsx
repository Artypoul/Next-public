import { Shimmer } from '@/ui/components/Shimmer';

export const CardSkeleton = () => {
  return (
    <>
      <div>
        <span className='relative inline-block h-6 overflow-hidden'>
          <span className='invisible'>Продолжить покупки</span>
          <Shimmer />
        </span>
      </div>
      <div className='mt-3 flex flex-col gap-6 md:flex-row'>
        <div className='relative h-[386px] flex-grow overflow-hidden rounded'>
          <Shimmer />
        </div>
        <div className='relative h-[386px] w-full overflow-hidden rounded md:w-[378px]'>
          <Shimmer />
        </div>
      </div>
    </>
  );
};
