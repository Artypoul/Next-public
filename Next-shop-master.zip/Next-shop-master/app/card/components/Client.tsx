'use client';

import dynamic from 'next/dynamic';

import { CardSkeleton } from './CardSkeleton';

const Card = dynamic(() => import('./Card').then(module => module.Card), {
  ssr: false,
  loading: () => <CardSkeleton />,
});

export function Client() {
  return <Card />;
}
