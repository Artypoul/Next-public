'use client';

import { CardItem, useShop } from '@/app/components/layout/context';
import { Quantity } from '@/ui/components/Quantity';

export function ProductQuantity({
  product,
  count,
}: Omit<CardItem, 'selected'>) {
  const { quantity: maxCount } = product;
  const { increaseProduct, decreaseProduct } = useShop();

  return (
    <div className='inline-block text-center'>
      <Quantity
        className='mt-0 text-sm'
        quantity={count}
        maxCount={maxCount}
        onDecrease={() => decreaseProduct(product)}
        onIncrease={() => increaseProduct(product)}
      />
      <div className='mt-1 text-xs opacity-50'>доступно: {maxCount}</div>
    </div>
  );
}
