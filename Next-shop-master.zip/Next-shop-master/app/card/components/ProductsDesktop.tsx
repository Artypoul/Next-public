import Image from 'next/image';
import CountUp from 'react-countup';

import { money } from '@/lib/utils';
import { Checkbox } from '@/ui/components';
import { Close } from '@/ui/components/Icons';

import { ProductsProps } from './Card';
import { ProductQuantity } from './ProductQuantity';

export function ProductsDesktop({ card, onRemove, onToggle }: ProductsProps) {
  return (
    <div className='overflow-hidden overflow-x-auto'>
      <table className='w-full'>
        <thead>
          <tr className='bg-gold text-xs text-white'>
            <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
              Выбрать
            </th>
            <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
              Товар
            </th>
            <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
              Цена
            </th>
            <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
              Количество
            </th>
            <th className='p-4 text-left font-semibold leading-[132%] tracking-[4%]'>
              Итого
            </th>
            <th></th>
          </tr>
        </thead>
        <tbody className='text-sm'>
          {card.map(cardItem => {
            const { product, count, selected } = cardItem;
            return (
              <tr key={product.id} className='bg-white dark:bg-contrast'>
                <td className='p-4'>
                  <Checkbox
                    className='ml-6 h-4 w-4 rounded-full'
                    wrapperClassName='flex items-center text-xs leading-[132%] tracking-[4%] font-semibold'
                    checked={!!selected}
                    onChange={() => {
                      onToggle(cardItem);
                    }}
                  />
                </td>
                <td className='p-4'>
                  <div className='flex gap-6'>
                    {'photo' in product && (
                      <Image
                        className='pointer-events-none aspect-square object-cover'
                        alt={product.name}
                        src={product.photo}
                        width={64}
                        height={64}
                      />
                    )}
                    <div className='py-2'>{product.name}</div>
                  </div>
                </td>
                <td className='min-w-28 p-4 font-bold'>
                  <CountUp
                    end={parseFloat(product.price ?? 0)}
                    formattingFn={money}
                    preserveValue
                    duration={0.3}
                    decimals={2}
                  />
                </td>
                <td className='p-4'>
                  <ProductQuantity product={product} count={count} />
                </td>
                <td className='min-w-28 p-4 font-bold'>
                  <CountUp
                    end={parseFloat(product.price ?? 0) * count}
                    formattingFn={money}
                    preserveValue
                    duration={0.3}
                    decimals={2}
                  />
                </td>
                <td>
                  <button
                    type='button'
                    className='flex w-full justify-center p-4'
                    onClick={() => onRemove(product)}
                  >
                    <Close />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
