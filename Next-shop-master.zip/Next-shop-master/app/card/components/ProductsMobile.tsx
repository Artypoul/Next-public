import Image from 'next/image';
import CountUp from 'react-countup';

import { money } from '@/lib/utils';
import { Checkbox } from '@/ui/components';
import { Close } from '@/ui/components/Icons';

import { ProductsProps } from './Card';
import { ProductQuantity } from './ProductQuantity';

export function ProductsMobile({ card, onRemove, onToggle }: ProductsProps) {
  return (
    <div>
      {card.map((cardItem, index) => {
        const { product, count, selected } = cardItem;
        return (
          <div key={product.id}>
            {index > 0 && (
              <div className='px-4 py-1.5'>
                <svg
                  width='330'
                  height='2'
                  viewBox='0 0 330 2'
                  fill='none'
                  xmlns='http://www.w3.org/2000/svg'
                >
                  <path
                    opacity='0.25'
                    d='M329 1H1'
                    stroke='#6E6E6E'
                    strokeLinecap='round'
                    strokeLinejoin='round'
                  />
                </svg>
              </div>
            )}
            <div className='p-4'>
              <div className='flex flex-nowrap gap-4'>
                {'photo' in product && (
                  <Image
                    className='pointer-events-none aspect-square max-h-24 min-h-24 min-w-24 max-w-24 flex-grow overflow-hidden rounded'
                    alt={product.name}
                    src={product.photo}
                    width={96}
                    height={96}
                  />
                )}
                <div className='flex-grow'>
                  <div className='text-sm font-semibold leading-[22px]'>
                    <CountUp
                      end={parseFloat(product.price ?? 0)}
                      formattingFn={money}
                      preserveValue
                      duration={0.3}
                      decimals={2}
                    />{' '}
                    × {count} ={' '}
                    <CountUp
                      end={parseFloat(product.price ?? 0) * count}
                      formattingFn={money}
                      preserveValue
                      duration={0.3}
                      decimals={2}
                    />
                  </div>
                  <div className='mt-2 text-sm leading-[14px]'>
                    {product.name}
                  </div>
                </div>
              </div>
            </div>
            <div className='flex justify-between pl-4'>
              <ProductQuantity product={product} count={count} />
              <div className='flex items-center'>
                <div className='p-4'>
                  <Checkbox
                    className='h-4 w-4 rounded-full'
                    wrapperClassName='flex items-center text-xs leading-[132%] tracking-[4%] font-semibold'
                    checked={!!selected}
                    onChange={() => {
                      onToggle(cardItem);
                    }}
                  />
                </div>
                <button
                  type='button'
                  className='flex w-full justify-center p-4'
                  onClick={() => onRemove(product)}
                >
                  <Close />
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
