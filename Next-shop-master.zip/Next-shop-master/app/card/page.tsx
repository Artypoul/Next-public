import { Suspense } from 'react';

import { Container } from '../components/layout/container';
import Products from '../components/product/grid';
import { ProductsSkeleton } from '../components/product/grid/ProductsSkeleton';
import { Client } from './components/Client';

export default async function Page() {
  return (
    <main className='pb-10'>
      <div className='bg-card-bg-light pb-[136px] pt-[50px] dark:bg-black'>
        <Container>
          <Client />
        </Container>
      </div>
      <Container>
        <div className='py-5 text-lg font-bold leading-[22px] hover:text-gold lg:py-[44px] lg:text-[40px]'>
          Рекомендуемые товары
        </div>
        <Suspense key={`recommended`} fallback={<ProductsSkeleton />}>
          <Products perPage={8} orderBy='popularity_desc' hidePagination />
        </Suspense>
      </Container>
    </main>
  );
}
