import { Suspense } from 'react';

import { Container } from '@/app/components/layout/container';
import Products from '@/app/components/product/grid';
import { ProductsSkeleton } from '@/app/components/product/grid/ProductsSkeleton';
import { getCategories } from '@/lib/gigma';

export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;

  const res = await getCategories({});
  const { categories } = res ?? {};

  const category = (categories ?? []).find(cat => cat.id.toString() === id);

  return (
    <main className='pb-10'>
      <Container>
        {category?.name && (
          <div className='py-5 text-lg font-bold leading-[22px] hover:text-gold lg:py-[44px] lg:text-[40px]'>
            {category.name}
          </div>
        )}
        <Suspense key={`category-${id}`} fallback={<ProductsSkeleton />}>
          <Products category={id} />
        </Suspense>
      </Container>
    </main>
  );
}

export async function generateStaticParams() {
  const res = await getCategories({});
  if (!res) return [];
  const { categories } = res ?? { categories: [] };
  return categories.map(category => ({
    id: category.id.toString(),
  }));
}
