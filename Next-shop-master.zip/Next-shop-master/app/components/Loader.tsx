'use client';

import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';

export default function CustomProgressBar() {
  const [isLoading, setIsLoading] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, [pathname]);

  return (
    <div className='fixed left-0 right-0 top-0 z-50 h-1'>
      {isLoading && (
        <div className='h-full origin-left animate-progress bg-red-600'></div>
      )}
    </div>
  );
}
