import type { KeyboardEvent } from 'react';
import type { FormValues } from './';

import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import { SubmitHandler, useFormContext } from 'react-hook-form';

import { Button } from '@/ui/components';
import { TextField } from '@/ui/fields';

export function CodeForm({
  onSubmit,
  onRetry,
}: {
  onSubmit: SubmitHandler<FormValues>;
  onRetry: SubmitHandler<FormValues>;
}) {
  const {
    control,
    watch,
    handleSubmit,
    setValue,
    formState: { isSubmitting, errors },
  } = useFormContext<FormValues>();

  const [timer, setTimer] = useState(60 * 1000);

  const [password] = watch(['password']);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimer(prev => (prev > 1000 ? prev - 1000 : 0));
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit(onSubmit)();
    }
  };

  return (
    <>
      <div className='mx-auto flex max-w-[350px] flex-col gap-3 pb-[48px] pt-[100px]'>
        <div className='text-center text-xl font-bold lg:text-2xl'>
          Введите код
        </div>
        <div className='mx-auto max-w-[204px] text-center text-sm'>
          Вам поступит звонок, введите последние 4 цифры
        </div>
      </div>
      <div className='mx-auto flex max-w-[260px] flex-col gap-6'>
        <div>
          <TextField
            name='password'
            control={control}
            placeholder='0 0 0 0'
            maxLength={4}
            className='text-center'
            inputMode='decimal'
            errorClassName='text-center text-sm'
            staticValidate={{ pattern: /\d/, message: 'Только цифры' }}
            rules={{
              validate: code =>
                code && !/\d{4}/.test(code as string)
                  ? 'Введите код'
                  : undefined,
            }}
            onKeyDown={onKeyDown}
          />
          <div className='text-center text-xs text-black/50'>
            Запросите код повторно
            {timer > 1000 && ` через `}
            {timer > 1000 && (
              <span className='text-gold'>{format(timer, 'mm:ss')}</span>
            )}
          </div>
        </div>
        {errors.root?.type === 'sendPassword' && !!errors.root.message && (
          <div className='text-error'>{errors.root.message}</div>
        )}
        <div className='text-center'>
          <Button
            onClick={() => {
              setValue('password', '');
              handleSubmit(onRetry)();
              setTimer(60 * 1000);
            }}
            disabled={isSubmitting || timer !== 0}
            className='w-full'
          >
            Запросить
          </Button>
        </div>
        {errors.root?.type === 'login' && !!errors.root.message && (
          <div>{errors.root.message}</div>
        )}
        <div className='text-center'>
          <Button
            onClick={handleSubmit(onSubmit)}
            disabled={!!errors.password?.message || isSubmitting || !password}
            className='w-full'
          >
            Вход
          </Button>
        </div>
      </div>
    </>
  );
}
