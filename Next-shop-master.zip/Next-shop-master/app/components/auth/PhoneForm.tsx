import type { FormValues } from './';

import Link from 'next/link';
import { SubmitHandler, useFormContext } from 'react-hook-form';

import { Button } from '@/ui/components';
import { Phone } from '@/ui/components/Icons';
import { PhoneField } from '@/ui/fields';

export function PhoneForm({
  onSubmit,
}: {
  onSubmit: SubmitHandler<FormValues>;
}) {
  const {
    control,
    watch,
    handleSubmit,
    formState: { isSubmitting, errors },
  } = useFormContext<FormValues>();

  const phone = watch('phone');

  return (
    <>
      <div className='mx-auto flex max-w-[350px] flex-col gap-3 pb-[48px] pt-[100px]'>
        <div className='text-center text-xl font-bold lg:text-2xl'>
          Укажите номер телефона
        </div>
        <div className='mx-auto max-w-[204px] text-center text-sm opacity-50'>
          На него позвонит робот и сообщит код подтверждения
        </div>
      </div>
      <div className='mx-auto flex max-w-[260px] flex-col gap-6'>
        <div className='relative'>
          <PhoneField
            control={control}
            name='phone'
            className='pl-[43px]'
            disabled={isSubmitting}
            errorClassName='text-center text-sm'
            rules={{
              validate: phone =>
                !/\+7 \(\d{3}\) \d{3} \d{2} \d{2}/.test(phone as string)
                  ? 'Введите номер'
                  : undefined,
            }}
          />
          <Phone className='absolute left-2 top-[17.5px]' />
        </div>
        {errors.root?.type === 'sendPassword' && !!errors.root.message && (
          <div className='text-error'>{errors.root.message}</div>
        )}
        <div className='text-center'>
          <Button
            onClick={handleSubmit(onSubmit)}
            disabled={!!errors.phone?.message || isSubmitting || !phone}
            className='w-full'
          >
            Готово
          </Button>
        </div>
      </div>
      <div className='mx-auto max-w-[350px] pt-[35px] text-center text-xs leading-[130%]'>
        Отправляя форму, вы подтверждаете свое согласие на{' '}
        <Link href='/privacy-policy' target='_blank' className='text-gold'>
          обработку персональных данных
        </Link>
      </div>
    </>
  );
}
