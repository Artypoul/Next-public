import type { FormValues } from './';

import { SubmitHandler, useFormContext } from 'react-hook-form';

import { capitalize, validateEmail } from '@/lib/utils';
import { Button } from '@/ui/components';
import { TextField } from '@/ui/fields';

export function UserForm({
  onSubmit,
  title = 'Оформление заказа',
}: {
  onSubmit: SubmitHandler<FormValues>;
  title?: string;
}) {
  const {
    control,
    handleSubmit,
    formState: { isSubmitting, errors },
  } = useFormContext<FormValues>();

  return (
    <>
      <div className='mx-auto flex max-w-[350px] flex-col gap-3 pb-[48px] pt-[100px]'>
        <div className='text-center text-xl font-bold lg:text-2xl'>{title}</div>
      </div>
      <div className='mx-auto flex max-w-[260px] flex-col gap-6'>
        <TextField
          control={control}
          name='firstName'
          className='text-center'
          disabled={isSubmitting}
          placeholder='Имя*'
          parse={capitalize}
          sanitizeOnBlur
          rules={{
            required: 'Введите имя',
            minLength: { value: 2, message: 'Не менее 2 букв' },
          }}
        />
        <TextField
          control={control}
          name='lastName'
          className='text-center'
          disabled={isSubmitting}
          placeholder='Фамилия'
          parse={capitalize}
          sanitizeOnBlur
          rules={{
            minLength: { value: 2, message: 'Не менее 2 букв' },
          }}
        />
        <TextField
          control={control}
          name='email'
          className='text-center'
          disabled={isSubmitting}
          placeholder='E-mail'
          rules={{
            validate: email =>
              email && !validateEmail(email as string)
                ? 'Введите корректтный E-mail'
                : undefined,
          }}
        />
        {errors.root?.type === 'update' && !!errors.root.message && (
          <div className='text-error'>{errors.root.message}</div>
        )}
        <div className='text-center'>
          <Button
            disabled={!!errors.firstName?.message || isSubmitting}
            onClick={handleSubmit(onSubmit)}
            className='w-full'
          >
            Готово
          </Button>
        </div>
      </div>
    </>
  );
}
