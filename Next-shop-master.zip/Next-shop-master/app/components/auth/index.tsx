'use client';

import type { ReactNode } from 'react';

import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form';

import { useUser } from '@/app/components/layout/context/user-context';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { login, sendCode, updateUser } from '@/lib/gigma';
import { ArrowBack } from '@/ui/components/Icons';

import { CodeForm } from './CodeForm';
import { PhoneForm } from './PhoneForm';
import { UserForm } from './UserForm';

export type FormValues = {
  phone: string;
  password: string;
  firstName: string;
  lastName: string;
  email: string;
};

export type Step = 'phone' | 'code' | 'update';

export const ENDPOINT = process.env.NEXT_PUBLIC_API ?? '';
export const TOKEN = process.env.NEXT_PUBLIC_TOKEN ?? '';
const TOKEN_KEY = process.env.NEXT_PUBLIC_TOKEN_KEY ?? 'customerToken';

export function AuthGuard({
  children,
  title = 'Заполните форму',
  hidden = false,
  onGoBack,
}: {
  children?: ReactNode;
  title?: string;
  hidden?: boolean;
  onGoBack?: () => void;
}) {
  const [authToken] = useLocalStorage<string>(TOKEN_KEY, '');
  const [step, setStep] = useState<Step>('phone');
  const [updateReason, setUpdateReason] = useState('');
  const { user, userIsFilled, isLoading, setToken, mutate } = useUser();

  const router = useRouter();

  const formMethods = useForm<FormValues>({
    mode: 'onSubmit',
    defaultValues: {
      phone: '',
      password: '',
      firstName: '',
      lastName: '',
      email: '',
    },
  });

  const { setError, clearErrors, reset, setValue } = formMethods;

  const onPhoneSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ phone }) => {
      try {
        clearErrors('root');

        const codeSended = await sendCode(phone.replace(/\D/g, ''));

        if (!codeSended) {
          throw new Error('Не удалось отправить запрос');
        }
        setStep('code');
      } catch {
        setError('root', {
          type: 'sendPassword',
          message: 'Не удалось отправить запрос',
        });
      }
    },
    [clearErrors, setError],
  );

  const onCodeSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ phone, password }) => {
      try {
        clearErrors('root');
        const userData = await login({
          phone: phone.replace(/\D/g, ''),
          password,
        });

        if (!userData) {
          throw new Error('Не удалось войти');
        }

        if (!userData?.counterparty?.access_token?.value) {
          throw new Error('Не удалось войти');
        }

        setToken(userData.counterparty.access_token.value);
      } catch {
        setError('root', {
          type: 'login',
          message: 'Не удалось войти',
        });
      }
    },
    [clearErrors, setError, setToken],
  );

  const onUserUpdate: SubmitHandler<FormValues> = useCallback(
    async ({ email, firstName, lastName }) => {
      if (!authToken) {
        console.error('no token found');
        return;
      }
      try {
        clearErrors('root');
        const user = await updateUser({
          first_name: firstName,
          last_name: lastName,
          email,
          token: authToken,
        });

        if (!user) {
          throw new Error('Не удалось обновить данные');
        }

        if (!user?.counterparty?.first_name) {
          throw new Error('Не удалось обновить данные');
        }

        mutate(user);
      } catch {
        setError('root', {
          type: 'login',
          message: 'Не удалось войти',
        });
      }
    },
    [clearErrors, setError, authToken, mutate],
  );

  const goBack = useCallback(() => {
    if (step === 'phone' || step === 'update') {
      reset();
      if (onGoBack) {
        onGoBack();
      } else {
        router.back();
      }
    } else if (step === 'code') {
      setStep('phone');
      setValue('password', '');
    }
  }, [step, router, setValue, reset, onGoBack]);

  useEffect(() => {
    if (user && !userIsFilled) {
      setUpdateReason(title);
      setStep('update');
    } else if (userIsFilled) {
      reset();
    }
  }, [user, userIsFilled, title, reset]);

  if (hidden) {
    return null;
  }

  if (userIsFilled && !isLoading) {
    return children;
  }

  if (isLoading || (user && !userIsFilled && !updateReason)) {
    return null;
  }

  return (
    <FormProvider {...formMethods}>
      <div className='fixed inset-0 z-50 bg-auth-bg-light text-foreground dark:bg-contrast dark:text-white'>
        <div className='mx-auto max-w-[500px] lg:mt-[150px]'>
          <div className='flex items-center gap-6 px-[18px] py-[9px]'>
            <button type='button' onClick={() => goBack()}>
              <ArrowBack />
            </button>
            <div className='flex-grow text-center font-medium'>
              Вход/Регистрация
            </div>
            <div className='w-6' />
          </div>
        </div>
        {step === 'phone' && <PhoneForm onSubmit={onPhoneSubmit} />}
        {step === 'code' && (
          <CodeForm onSubmit={onCodeSubmit} onRetry={onPhoneSubmit} />
        )}
        {step === 'update' && (
          <UserForm onSubmit={onUserUpdate} title={updateReason} />
        )}
      </div>
    </FormProvider>
  );
}
