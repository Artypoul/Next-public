import type { ButtonHTMLAttributes } from 'react';

import { twJoin } from 'tailwind-merge';

import { ArrowLeft, ArrowRight } from '@/ui/components/Icons';

type ArrowButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  direction: 'left' | 'right';
};

export function ArrowButton({ direction, disabled }: ArrowButtonProps) {
  const className = twJoin(
    'flex h-[42px] w-[42px] items-center justify-center text-black/50 duration-300 hover:bg-input-bg dark:text-white/50 dark:hover:bg-foreground',
    !disabled && 'hover:text-black dark:hover:text-white',
    disabled && 'pointer-events-none',
    direction === 'left' ? 'prevBrand' : 'nextBrand',
  );

  const icon = direction === 'left' ? <ArrowLeft /> : <ArrowRight />;

  return (
    <button type='button' className={className} disabled={disabled}>
      {icon}
    </button>
  );
}
