'use client';

import type { Brand as BrandType } from '@/lib/gigma/types';

import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

import { useFilters } from '../layout/context';

export function Brand(brand: BrandType) {
  const { photo, name } = brand;
  const { toggleFilter, setSearchQuery } = useFilters();

  return (
    <div
      className='relative !h-[66px] !max-h-[66px] select-none lg:cursor-pointer'
      onClick={() => {
        toggleFilter('brand', brand, true);
        setSearchQuery('');
      }}
    >
      <Image
        src={photo}
        alt={name}
        fill
        className={twJoin(
          photo.endsWith('.svg') && 'dark:invert',
          'pointer-events-none object-scale-down',
        )}
      />
    </div>
  );
}
