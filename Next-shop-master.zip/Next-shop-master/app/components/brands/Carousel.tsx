'use client';

import { FreeMode, Navigation } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';
import 'swiper/css/free-mode';

import type { GetBrandsResponse } from '@/lib/gigma/types';

import { Brand } from './Brand';

export function Carousel({ brands }: GetBrandsResponse) {
  return (
    <div>
      <Swiper
        slidesPerView={2.5}
        spaceBetween={0}
        breakpoints={{
          640: {
            slidesPerView: 7,
            spaceBetween: 73,
          },
        }}
        modules={[Navigation, FreeMode]}
        navigation={{
          nextEl: '.nextBrand',
          prevEl: '.prevBrand',
        }}
        loop
        freeMode
      >
        {brands.map((brand, index) => (
          <SwiperSlide key={index}>
            <Brand {...brand} />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}
