import { getBrands } from '@/lib/gigma';

import { Container } from '../layout/container';
import { ArrowButton } from './ArrowButton';
import { Carousel } from './Carousel';

export default async function Brands() {
  const brands = await getBrands();

  if (!brands || !brands?.brands?.length) return null;

  return (
    <>
      <Container className='flex flex-row justify-between'>
        <div className='py-5 text-lg font-bold leading-[22px] hover:text-gold lg:py-[44px] lg:text-[40px]'>
          Бренды
        </div>
        <div className='flex items-center'>
          <ArrowButton direction='left' className='prevBrand' />
          <ArrowButton direction='right' className='nextBrand' />
        </div>
      </Container>
      <Container className='w-full max-w-full pb-[50px] pt-[44px] lg:px-[60px]'>
        <Carousel {...brands} />
      </Container>
    </>
  );
}
