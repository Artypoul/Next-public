import type { HTMLAttributes } from 'react';

import { twMerge } from 'tailwind-merge';

export function Container({
  children,
  className = '',
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={twMerge(
        'mx-auto flex w-full flex-grow flex-col px-4 2xl:max-w-[1744px] 2xl:px-[100px]',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
