'use client';

import type { ReadonlyURLSearchParams } from 'next/navigation';
import type { PropsWithChildren } from 'react';
import type { FilterOption, Filters, FilterType, PriceRange } from './types';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useDebouncedCallback } from 'use-debounce';

import { availabilities, useShop } from './shop-context';

type FilterContext = {
  query: string;
  filters: Filters;
  priceRange?: PriceRange;
  clearFilters: () => void;
  toggleFilter: (
    code: FilterType,
    option?: FilterOption,
    replace?: boolean,
  ) => void;
  setPriceRangeFilter: (range?: PriceRange) => void;
  setSearchQuery: (query: string) => void;
};

export const getSelectedFilter = (
  searchParams: ReadonlyURLSearchParams,
  code: FilterType,
  records: FilterOption[],
) => {
  const selected = searchParams.get(code);

  const selectedIds = selected ? selected.split(',').map(Number) : [];
  return records.filter(record => selectedIds.includes(record.id));
};

const Context = createContext({} as FilterContext);

export function useFilters() {
  return useContext(Context);
}

export function FiltersProvider({ children }: PropsWithChildren) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { categories, brands, countries } = useShop();
  const [priceRange, setPriceRange] = useState<PriceRange>();
  const [filters, setFilters] = useState<Filters>(() => ({
    category: getSelectedFilter(searchParams, 'category', categories),
    brand: getSelectedFilter(searchParams, 'brand', brands),
    country: getSelectedFilter(searchParams, 'country', countries),
    availability: getSelectedFilter(
      searchParams,
      'availability',
      availabilities,
    ),
  }));
  const [query, setQuery] = useState(searchParams.get('query') ?? '');

  const { replace } = useRouter();

  const firstRender = useRef(false);
  const searchParamsRef = useRef(searchParams);

  const toggleFilter = useCallback(
    (code: FilterType, option?: FilterOption, replace?: boolean) => {
      if (option && replace) {
        setFilters(prev => {
          const updated = { ...prev };
          for (const filter in updated) {
            if (
              filter !== code &&
              Object.prototype.hasOwnProperty.call(updated, filter)
            ) {
              updated[filter as FilterType] = [];
            }
          }

          updated[code] = [option];
          return updated;
        });
      } else if (!option) {
        setFilters(prev => {
          const updated = { ...prev, [code]: [] };

          return updated;
        });
      } else {
        setFilters(prev => {
          const prevFilter = prev[code];

          if (typeof prevFilter === 'string') return prev;

          const updatedFilters = { ...prev };
          const updated: FilterOption[] = [];

          if (prevFilter) {
            const arr = [...prevFilter];
            if (arr.some(item => item.id === option.id)) {
              updated.push(...arr.filter(item => item.id !== option.id));
            } else {
              updated.push(...[...arr, option]);
            }
          } else {
            updated.push(option);
          }

          return { ...updatedFilters, [code]: updated };
        });
      }
    },
    [],
  );

  const clearFilters = useCallback(() => {
    setFilters(prev => {
      const updated = { ...prev };
      for (const filter in updated) {
        if (Object.prototype.hasOwnProperty.call(updated, filter)) {
          updated[filter as FilterType] = [];
        }
      }

      return updated;
    });
  }, []);

  const handleSearch = useDebouncedCallback((query: string) => {
    if (query.length && query.length < 3) {
      return;
    }

    const params = new URLSearchParams(searchParams);
    params.delete('page');
    params.delete('priceFrom');
    params.delete('priceTo');
    if (query) {
      params.set('query', query);
    } else {
      params.delete('query');
    }
    replace(`/shop?${params.toString()}`);
  }, 600);

  const setPriceRangeFilter = useCallback(
    (range?: PriceRange) => {
      setPriceRange(range);
      const min = range?.[0] || 0;
      const max = range?.[1] || 0;

      const params = new URLSearchParams(searchParams);

      if (min) {
        params.set('priceFrom', String(min));
      } else {
        params.delete('priceFrom');
      }

      if (max) {
        params.set('priceTo', String(max));
      } else {
        params.delete('priceTo');
      }

      replace(`/shop?${params.toString()}`);
    },
    [searchParams, replace],
  );

  const setSearchQuery = useCallback(
    (query: string) => {
      setQuery(query);
      handleSearch(query);
    },
    [handleSearch],
  );

  const clearAllFilters = useCallback(() => {
    clearFilters();
    setQuery('');
    setPriceRange(undefined);
  }, [clearFilters]);

  useEffect(() => {
    searchParamsRef.current = searchParams;
  }, [searchParams]);

  useEffect(() => {
    if (firstRender.current && pathname === '/shop') {
      const params = new URLSearchParams(searchParamsRef.current);
      const { brand, category, country, availability } = filters;

      if (brand.length) {
        const brandsIds = brand.map(item => item.id).join(',');
        params.set('brand', brandsIds);
      } else {
        params.delete('brand');
      }

      if (category.length) {
        const categoriesIds = category.map(item => item.id).join(',');
        params.set('category', categoriesIds);
      } else {
        params.delete('category');
      }

      if (country.length) {
        const countriesIds = country.map(item => item.id).join(',');
        params.set('country', countriesIds);
      } else {
        params.delete('country');
      }

      if (availability.length) {
        const availabilityIds = availability.map(item => item.id).join(',');
        params.set('availability', availabilityIds);
      } else {
        params.delete('availability');
      }

      params.delete('priceFrom');
      params.delete('priceTo');

      replace(`/shop?${params.toString()}`);
    }

    return () => {
      firstRender.current = true;
    };
  }, [filters, replace, pathname]);

  useEffect(() => {
    if (pathname !== '/shop' && !pathname.startsWith('/product/')) {
      clearAllFilters();
    }
  }, [pathname, clearAllFilters]);

  return (
    <Context.Provider
      value={{
        filters,
        toggleFilter,
        clearFilters,
        query,
        setSearchQuery,
        setPriceRangeFilter,
        priceRange,
      }}
    >
      {children}
    </Context.Provider>
  );
}
