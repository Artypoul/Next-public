'use client';

import type {
  Brand,
  Category,
  Country,
  GetPriceRequest,
  GetPriceResponse,
  PopularSeachData,
  SingleProduct,
  Product as TableProduct,
  Tag,
} from '@/lib/gigma/types';
import type { PropsWithChildren } from 'react';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

import { useLocalStorage } from '@/hooks/useLocalStorage';
import {
  addToFavorite,
  getDictionaries,
  getOrderPrice,
  removeFromFavorite,
} from '@/lib/gigma';

import { FilterOption } from './types';
import { useUser } from './user-context';

type Product = TableProduct | SingleProduct;

export type CardItem = {
  product: Product;
  count: number;
  selected: boolean;
};

type ShopContext = {
  card: CardItem[];
  favorites: number[];
  totalCount: number;
  brands: Brand[];
  categories: Category[];
  countries: Country[];
  tags: Tag[];
  popular: PopularSeachData[];
  getSelected: () => CardItem[];
  getPrice: (card: CardItem[]) => Promise<GetPriceResponse>;
  getCount: (product: Product) => number;
  increaseProduct: (product: Product) => void;
  isFavorite: (product: Product) => boolean;
  decreaseProduct: (product: Product) => void;
  toggleFavorite: (product: Product) => void;
  removeProducts: (ids: number | number[]) => void;
  selectProducts: (ids: number[] | 'all') => void;
  unselectProducts: (ids: number[] | 'all') => void;
};

const Context = createContext({} as ShopContext);

export function useShop() {
  return useContext(Context);
}

export const availabilities: FilterOption[] = [
  { id: 1, name: 'В интернет-магазинах' },
  { id: 2, name: 'В розничных магазинах' },
];

export function ShopProvider({ children }: PropsWithChildren) {
  const [loaded, setLoaded] = useState(false);
  const [card, setCard] = useLocalStorage<CardItem[]>('card', []);
  const [favorites, setFavorites] = useState<number[]>([]);
  const [popular, setPopular] = useState<PopularSeachData[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);

  const { user, token } = useUser();

  const toggleFavorite = useCallback(
    async (product: Product) => {
      if (!user) return;

      const isInFavorites = favorites.includes(product.id);

      setFavorites(prev => {
        if (isInFavorites) {
          return (prev ?? []).filter(id => id !== product.id);
        }

        return [...(prev ?? []), product.id];
      });

      if (isInFavorites) {
        await removeFromFavorite(product.id, token);
      } else {
        await addToFavorite(product.id, token);
      }
    },
    [user, token, favorites],
  );

  const selectProducts = useCallback(
    (ids: number[] | 'all') => {
      setCard(prev => {
        const updated = [...(prev ?? [])];
        if (ids === 'all') {
          return updated.map(item => ({ ...item, selected: true }));
        } else {
          return updated.map(item => ({
            ...item,
            selected: ids.includes(item.product.id) ? true : item.selected,
          }));
        }
      });
    },
    [setCard],
  );

  const unselectProducts = useCallback(
    (ids: number[] | 'all') => {
      setCard(prev => {
        const updated = [...(prev ?? [])];
        if (ids === 'all') {
          return updated.map(item => ({ ...item, selected: false }));
        } else {
          return updated.map(item => ({
            ...item,
            selected: ids.includes(item.product.id) ? false : item.selected,
          }));
        }
      });
    },
    [setCard],
  );

  const increaseProduct = useCallback(
    (product: Product) => {
      setCard(prev => {
        const updated = [...(prev ?? [])];
        const index = updated.findIndex(
          item => item.product.id === product.id && !!item.count,
        );
        if (index !== -1) {
          const newItem = {
            ...updated[index],
            count: updated[index].count + 1,
          };
          updated.splice(index, 1, newItem);
        } else {
          updated.push({ product, count: 1, selected: true });
        }

        return updated;
      });
    },
    [setCard],
  );

  const decreaseProduct = useCallback(
    (product: Product) => {
      setCard(prev => {
        const updated = [...(prev ?? [])];
        const index = (prev ?? []).findIndex(
          item => item.product.id === product.id && !!item.count,
        );

        if (index !== -1) {
          const { count } = updated[index];
          if (count <= 1) {
            updated.splice(index, 1);
          } else {
            const newItem = {
              ...updated[index],
              count: updated[index].count - 1,
            };
            updated.splice(index, 1, newItem);
          }

          return updated;
        }

        return prev;
      });
    },
    [setCard],
  );

  const removeProducts = useCallback(
    (ids: number | number[]) => {
      const products = Array.isArray(ids) ? ids : [ids];
      setCard(prev => {
        return [...(prev ?? [])].filter(
          item => !products.includes(item.product.id),
        );
      });
    },
    [setCard],
  );

  const isFavorite = useCallback(
    (product: Product) => {
      return favorites.includes(product.id);
    },
    [favorites],
  );

  const getCount = useCallback(
    (product: Product) => {
      const exists = card.find(item => item.product.id === product.id);
      return exists ? exists.count : 0;
    },
    [card],
  );

  const getSelected = useCallback(() => {
    return card.filter(item => item.selected);
  }, [card]);

  const totalCount = useMemo(() => {
    return card.reduce((acc, item) => {
      return acc + item.count;
    }, 0);
  }, [card]);

  const setInitialFavorites = useCallback(async () => {
    if (!user) return;

    if (user?.counterparty?.favourite_products?.length) {
      setFavorites(
        user.counterparty.favourite_products.map(product => product.id),
      );
    }
  }, [user]);

  const getPrice = useCallback(
    async (card: CardItem[]): Promise<GetPriceResponse> => {
      const selected = card.reduce<GetPriceRequest>((acc, item) => {
        if (item.selected) {
          acc.push({
            id: item.product.id,
            quantity: item.count,
          });
        }
        return acc;
      }, []);

      if (!selected.length)
        return {
          price: 0,
          discount: 0,
          total: 0,
        };
      try {
        const currentPrice = await getOrderPrice(selected);
        return currentPrice;
      } catch {
        return {
          price: 0,
          discount: 0,
          total: 0,
        };
      }
    },
    [],
  );

  const getNeededDictionaries = useCallback(async () => {
    const dicts = await getDictionaries();
    if (dicts?.dictionaries) {
      const { brands, categories, countries, popular_requests, tags } =
        dicts.dictionaries;
      setBrands(brands ?? []);
      setCategories(categories ?? []);
      setCountries(countries ?? []);
      setPopular(popular_requests ?? []);
      setTags(tags ?? []);
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    setInitialFavorites();
  }, [setInitialFavorites]);

  useEffect(() => {
    getNeededDictionaries();
  }, [getNeededDictionaries]);

  if (!loaded) {
    return (
      <div className='flex h-full items-center justify-center'>
        <div className='left-0 right-0 top-0 z-50 h-2 w-full max-w-sm'>
          <div className='h-full origin-left animate-progress rounded-full bg-gradient-to-r from-purple-500 to-red-500'></div>
        </div>
      </div>
    );
  }

  return (
    <Context.Provider
      value={{
        card,
        getPrice,
        favorites,
        toggleFavorite,
        decreaseProduct,
        increaseProduct,
        isFavorite,
        getCount,
        removeProducts,
        totalCount,
        selectProducts,
        unselectProducts,
        getSelected,
        brands,
        categories,
        countries,
        tags,
        popular,
      }}
    >
      {children}
    </Context.Provider>
  );
}
