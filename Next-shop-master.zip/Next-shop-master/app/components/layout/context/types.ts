import type { User } from '@/lib/gigma/types';
import type { Dispatch, SetStateAction } from 'react';
import type { KeyedMutator } from 'swr';

export interface UserContextValue {
  user?: User;
  userIsFilled: boolean;
  error: string | null;
  isLoading: boolean;
  token: string;
  setToken: Dispatch<SetStateAction<string | undefined>>;
  mutate: KeyedMutator<User | undefined>;
  logout: (allDevices?: boolean) => Promise<boolean>;
}

export type FilterOption = {
  id: number;
  name: string;
  photo?: string;
};

export type FilterType = 'category' | 'brand' | 'country' | 'availability';

export type Filters = {
  category: FilterOption[];
  brand: FilterOption[];
  availability: FilterOption[];
  country: FilterOption[];
};

export type PriceRange = [number, number];
