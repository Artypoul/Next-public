'use client';

import type { User } from '@/lib/gigma/types';
import type { ReactNode } from 'react';
import type { UserContextValue } from './types';

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import useSWR from 'swr';

import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getUser, logout } from '@/lib/gigma';

const UserContext = createContext({} as UserContextValue);

export function useUser() {
  return useContext(UserContext);
}

export interface UserProviderProps {
  children: ReactNode;
}

const TOKEN_KEY = process.env.NEXT_PUBLIC_TOKEN_KEY ?? 'customerToken';

export function UserProvider({
  children,
}: UserProviderProps): React.JSX.Element {
  const [isLoading, setIsLoading] = useState(true);
  const [authToken, setAuthToken] = useLocalStorage<string>(TOKEN_KEY, '');

  const {
    data: user,
    error,
    mutate,
  } = useSWR<User | undefined, Error, string | null>(
    authToken ? authToken : null,
    token => getUser(token),

    {
      onSuccess: () => {
        setIsLoading(false);
      },
      onError: () => {
        setIsLoading(false);
        setAuthToken('');
      },
      shouldRetryOnError: true,
      //revalidateOnMount: false,
    },
  );

  const prevToken = useRef(authToken);

  useEffect(() => {
    if (!authToken) {
      setIsLoading(false);
    }
  }, [authToken, setAuthToken]);

  useEffect(() => {
    return () => {
      prevToken.current = authToken;
    };
  }, [authToken]);

  useEffect(() => {
    if (prevToken.current) {
      void mutate();
    }
  }, [authToken, mutate]);

  const _logout = useCallback(
    async (allDevices?: boolean) => {
      const res = await logout(authToken, allDevices);

      setAuthToken('');
      mutate();
      return res;
    },
    [authToken, setAuthToken, mutate],
  );

  return (
    <UserContext.Provider
      value={{
        user,
        userIsFilled: !!user?.counterparty?.first_name,
        error: error?.message || '',
        isLoading,
        token: authToken,
        mutate,
        setToken: setAuthToken,
        logout: _logout,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}
