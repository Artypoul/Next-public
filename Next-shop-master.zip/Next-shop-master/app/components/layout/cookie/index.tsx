'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { Button } from '@/ui/components';

export function CookieConsient() {
  const [showConsient, setShowConsient] = useState(false);

  useEffect(() => {
    const accepted = localStorage.getItem('cookieConsent') === 'true';
    if (!accepted) setShowConsient(true);
  }, []);

  return (
    <div
      className={twJoin(
        'fixed bottom-5 left-5 right-5 z-[9999] max-w-[600px] delay-1000 duration-300',
        showConsient ? 'translate-x-0' : '-translate-x-[800px]',
      )}
    >
      <div className='flex items-start gap-4 rounded-lg bg-contrast p-5 text-white shadow-xl dark:bg-white dark:text-foreground'>
        <div>
          Мы используем{' '}
          <Link href='/privacy-policy' target='_blank' className='text-gold'>
            cookies
          </Link>
          , чтобы сохранять ваш поиск, рекомендовать полезное и создавать другие
          удобства на сайте
        </div>
        <Button
          className='w-full max-w-[100px]'
          onClick={() => {
            localStorage.setItem('cookieConsent', 'true');
            setShowConsient(false);
          }}
        >
          Окей
        </Button>
      </div>
    </div>
  );
}
