'use client';

import type { ReactNode } from 'react';
import type { FilterOption, FilterType } from '../../context/types';

import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

import { ArrowDown, Undo } from '@/ui/components/Icons';

type FilterProps = {
  icon: ReactNode;
  code: FilterType;
  title: string;
  currentOpened?: FilterType;
  onToggle: (tab: FilterType) => void;
  onToggleFilter: (code: FilterType, option: FilterOption) => void;
  options: FilterOption[];
  selected: FilterOption[];
};

export function Filter({
  title,
  icon,
  code,
  options,
  currentOpened,
  onToggle,
  onToggleFilter,
  selected,
}: FilterProps) {
  return (
    <>
      <div className='px-[25px] py-3.5 text-xs font-semibold leading-none opacity-50'>
        {title}
      </div>
      <div className='filters-scroll my-4 flex max-h-[300px] flex-col gap-2.5 overflow-y-auto bg-white px-[25px] dark:bg-contrast'>
        <div
          role='button'
          onClick={() => onToggle(code)}
          className='sticky top-0 z-10 flex cursor-pointer items-center gap-3 bg-white dark:bg-contrast'
        >
          {icon}
          <div className='flex-grow text-sm font-medium leading-[22px]'>
            {selected?.length ? 'Выбрано' : 'Все'}
          </div>
          <ArrowDown
            className={twJoin(
              currentOpened === code && '-rotate-180',
              'min-w-[14px] duration-200',
            )}
          />
        </div>
        {currentOpened === code && (
          <>
            {options.map(item => {
              const isSelected = selected.some(s => s.id === item.id);
              if (isSelected) return null;
              return (
                <button
                  key={item.id}
                  type='button'
                  className='flex items-center gap-3'
                  onClick={() => {
                    onToggleFilter(code, item);
                  }}
                >
                  {item.photo ? (
                    <Image
                      src={item.photo}
                      alt={item.name}
                      width={16}
                      height={16}
                      className={twJoin(
                        item.photo.endsWith('.svg') && 'dark:invert',
                        'h-4 w-4 min-w-4 object-scale-down',
                      )}
                    />
                  ) : (
                    <div className='h-4 w-4' />
                  )}
                  <div className='text-sm font-medium leading-[22px]'>
                    {item.name}
                  </div>
                </button>
              );
            })}
          </>
        )}
      </div>
      <div className='flex flex-wrap content-start items-start gap-2 self-stretch px-[25px]'>
        {selected.map(item => {
          return (
            <button
              key={item.id}
              className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
              onClick={() => {
                onToggleFilter(code, item);
              }}
            >
              <Undo />
              {item.name}
            </button>
          );
        })}
      </div>
    </>
  );
}
