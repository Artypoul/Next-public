'use client';

import RangeSlider from 'react-range-slider-input';
import { twJoin } from 'tailwind-merge';

import 'react-range-slider-input/dist/style.css';

import type { Filters, FilterType, PriceRange } from '../context/types';

import { useCallback, useEffect, useState } from 'react';

import { useClickOutside } from '@/hooks/useClickOutside';
import { getPricesRange } from '@/lib/gigma';
import { Avail, Brand, Category, Close, World } from '@/ui/components/Icons';

import { availabilities, useFilters, useShop } from '../context';
import { Filter } from './components/Filter';

type FiltersProps = {
  opened: boolean;
  onToggle: () => void;
};

const DEFAULT_PRICE = 100000;

export function Filters({ opened, onToggle }: FiltersProps) {
  const [priceRange, setPriceRange] = useState<PriceRange>([0, DEFAULT_PRICE]);
  const [maxPrice, setMaxPrice] = useState(DEFAULT_PRICE);
  const { categories, brands, countries } = useShop();
  const { filters, toggleFilter, setPriceRangeFilter, query } = useFilters();

  const [openedFilter, setOpenedFilter] = useState<FilterType>();

  const { category, brand, country, availability } = filters;

  const ref = useClickOutside<HTMLDivElement>(onToggle);

  const onFilterTabClick = (filter: FilterType) => {
    setOpenedFilter(prev => {
      if (prev === filter) {
        return undefined;
      } else {
        return filter;
      }
    });
  };

  const getPrices = useCallback(async (filters: Filters, query: string) => {
    const res = await getPricesRange({
      query,
      category: filters.category.map(c => c.id).join(','),
      brand: filters.brand.map(c => c.id).join(','),
    });
    if (res) {
      setPriceRange([0, res.max_price || DEFAULT_PRICE]);
      if (res.max_price) {
        setMaxPrice(res.max_price);
      }
    }
  }, []);

  const onSetPrice = useCallback(() => {
    setPriceRangeFilter(priceRange);
  }, [priceRange, setPriceRangeFilter]);

  useEffect(() => {
    getPrices(filters, query);
  }, [filters, query, getPrices]);

  useEffect(() => {
    if (!opened) setOpenedFilter(undefined);
  }, [opened]);

  return (
    <>
      <div
        ref={ref}
        className={twJoin(
          'fixed bottom-0 top-0 z-40 w-[280px] overflow-hidden overflow-y-auto border-l border-light bg-white text-foreground shadow-lg duration-300 ease-in-out dark:border-light/10 dark:bg-contrast dark:text-white',
          opened ? 'right-0' : '-right-full',
        )}
      >
        <div className='py-4'>
          <div className='flex items-center justify-between px-[25px] py-[11px]'>
            <div className='text-sm'>Фильтры</div>
            <button
              type='button'
              onClick={() => {
                onToggle();
              }}
            >
              <Close />
            </button>
          </div>
        </div>
        <div className='px-[25px] py-3.5 text-xs font-semibold leading-none opacity-50'>
          Цена
        </div>
        <div className='px-[25px] py-2.5'>
          <RangeSlider
            className='price-slider'
            value={priceRange}
            max={maxPrice}
            onInput={range => {
              setPriceRange(range);
            }}
            onThumbDragEnd={onSetPrice}
            onRangeDragEnd={onSetPrice}
          />
          <div className='mt-4 flex select-none justify-between text-xs leading-[16px]'>
            <span>{priceRange[0]} ₽</span>
            <span>{priceRange[1]} ₽</span>
          </div>
        </div>
        <Filter
          code='category'
          icon={<Category className='min-w-4' />}
          currentOpened={openedFilter}
          onToggle={onFilterTabClick}
          onToggleFilter={toggleFilter}
          title='Категория'
          options={categories}
          selected={category}
        />
        <Filter
          code='brand'
          icon={<Brand className='min-w-4' />}
          currentOpened={openedFilter}
          onToggle={onFilterTabClick}
          onToggleFilter={toggleFilter}
          title='Бренды'
          options={brands}
          selected={brand}
        />
        <Filter
          code='country'
          icon={<World className='min-w-4' />}
          currentOpened={openedFilter}
          onToggle={onFilterTabClick}
          onToggleFilter={toggleFilter}
          title='Страны'
          options={countries}
          selected={country}
        />
        <Filter
          code='availability'
          icon={<Avail className='min-w-4' />}
          currentOpened={openedFilter}
          onToggle={onFilterTabClick}
          onToggleFilter={toggleFilter}
          title='Наличие'
          options={availabilities}
          selected={availability}
        />
      </div>
    </>
  );
}
