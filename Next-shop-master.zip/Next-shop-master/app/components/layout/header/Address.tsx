'use client';

import { useState } from 'react';
import { twJoin } from 'tailwind-merge';

import { Dialog, DialogContent, DialogHeader } from '@/ui/components';
import { Dropdown, DropdownItem } from '@/ui/components/Dropdown';
import { Pencil } from '@/ui/components/Icons';

import { AuthGuard } from '../../auth';
import { useUser } from '../context';
import { EditAddress } from '../profile/EditAddress';

export function Address() {
  const [isOpen, setIsOpen] = useState(false);
  const [showGuard, setShowGuard] = useState(false);
  const { user, token, mutate, userIsFilled, isLoading } = useUser();

  const dropdownButtonClassName = twJoin(
    'h-[43px] w-[134px] px-2 py-[10px] text-sm leading-normal text-foreground/50 focus:outline-none dark:text-white hover:bg-input-bg  rounded',
    isLoading && '!invisible',
  );
  const dropdownRootClassName = twJoin(
    'max-w-md rounded shadow-xl overflow-hidden z-30 border-contrast bg-white/70 dark:bg-foreground/70 backdrop-blur-sm focus-visible:outline-none',
  );
  const dropdownItemClassName = twJoin(
    'py-[10px] text-sm leading-normal dark:text-white w-full text-left px-4 hover:text-foreground hover:backdrop-blur-lg',
  );

  const address = user?.counterparty?.address ?? 'г Москва';

  return (
    <div className='hidden lg:block'>
      <AuthGuard
        hidden={!showGuard && !userIsFilled}
        onGoBack={() => {
          setShowGuard(false);
        }}
      />
      <Dropdown
        label={address}
        className={dropdownButtonClassName}
        rootClassName={dropdownRootClassName}
      >
        <DropdownItem
          label={address}
          className={dropdownItemClassName}
          onClick={() => {
            if (!userIsFilled) setShowGuard(true);
            setIsOpen(true);
          }}
        >
          <div className='font-semibold'>Адрес доставки</div>
          <div className='flex min-w-60 items-start gap-4'>
            <div className='flex-grow'>{address}</div>{' '}
            <Pencil className='mt-1 min-w-4' width={16} height={16} />
          </div>
        </DropdownItem>
      </Dropdown>
      {user && token && (
        <Dialog
          isOpen={isOpen}
          onToggle={() => {
            setIsOpen(false);
          }}
        >
          <DialogContent>
            <DialogHeader>Адрес доставки</DialogHeader>
            <EditAddress
              user={user}
              token={token}
              mutate={mutate}
              close={() => {
                setIsOpen(false);
              }}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
