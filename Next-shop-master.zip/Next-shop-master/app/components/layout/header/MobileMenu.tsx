'use client';

import type { MenuItems } from '@/lib/gigma/types';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { twJoin } from 'tailwind-merge';

import { useClickOutside } from '@/hooks/useClickOutside';
import { ArrowLeft, ArrowRight } from '@/ui/components/Icons';

import { ItemWide } from '../navbar/ItemWide';

type MobileMenuProps = {
  items: MenuItems[];
};

const shopName = process.env.NEXT_PUBLIC_SHOP_NAME ?? 'Component';

export function MobileMenu({ items }: MobileMenuProps) {
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [opened, setOpened] = useState<number>();

  const pathname = usePathname();

  const ref = useClickOutside<HTMLDivElement>(() => {
    setMenuIsOpen(false);
  });

  const onToggle = (index: number) => {
    setOpened(prev => {
      if (prev !== index) return index;
      return undefined;
    });
  };

  const closeMenu = useCallback(() => {
    setOpened(undefined);
    setMenuIsOpen(false);
  }, []);

  useEffect(() => {
    closeMenu();
  }, [pathname, closeMenu]);

  return (
    <nav className='lg:hidden'>
      <button
        type='button'
        className='flex h-[30px] w-[30px] items-center justify-center'
        onClick={() => {
          setMenuIsOpen(true);
        }}
      >
        <ArrowRight />
      </button>
      <div
        ref={ref}
        className={twJoin(
          'fixed inset-y-0 left-0 z-40 w-[280px] bg-white shadow-lg duration-300 dark:bg-black',
          menuIsOpen ? 'translate-x-0' : '-translate-x-full',
        )}
      >
        <div className='flex items-center gap-4 p-4 md:gap-[18px] md:px-5 md:py-[18px]'>
          <button
            type='button'
            className='flex h-[30px] w-[30px] items-center justify-center'
            onClick={() => {
              setMenuIsOpen(false);
            }}
          >
            <ArrowLeft />
          </button>
          <Link
            href='/'
            onClick={() => {
              closeMenu();
            }}
          >
            {shopName}
          </Link>
        </div>
        <div className='px-[10px] py-4 text-xs font-semibold leading-[22px] text-foreground/50 dark:text-light/50'>
          магазин
        </div>
        <ul className='flex flex-grow flex-col'>
          {items.map((item, index) => {
            return (
              <ItemWide
                key={index}
                index={index}
                item={item}
                opened={opened === index}
                onToggle={onToggle}
              />
            );
          })}
        </ul>
      </div>
      {menuIsOpen && <div className='fixed inset-0' />}
    </nav>
  );
}
