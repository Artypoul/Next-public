'use client';

import type { GetProductsRequest, OrderBy } from '@/lib/gigma/types';

import { useMemo, useState } from 'react';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { twJoin, twMerge } from 'tailwind-merge';

import { Dropdown, DropdownItem } from '@/ui/components/Dropdown';
import { Filter } from '@/ui/components/Icons';

import { useFilters } from '../context';
import { FilterType } from '../context/types';
import { Filters } from '../filters';

type Options = Record<OrderBy, string>;

const options = {
  popularity_desc: 'Популярные',
  price_desc: 'Дороже',
  price_asc: 'Дешевле',
} as Options;

export function Params({ className = '' }: { className?: string }) {
  const [filtersOpened, setFiltersOpened] = useState(false);
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const { filters, priceRange } = useFilters();

  const order =
    (searchParams.get('orderBy') as GetProductsRequest['orderBy']) || undefined;

  const { push } = useRouter();

  const setOrderByParam = (order: GetProductsRequest['orderBy']) => {
    const params = new URLSearchParams(searchParams);
    if (order) {
      params.set('orderBy', order);
    } else {
      params.delete('orderBy');
    }
    push(`${pathname}?${params.toString()}`);
  };

  const dropdownButtonClassName = twJoin(
    'h-[43px] px-2 py-[10px] text-sm leading-normal text-foreground/50 focus:outline-none dark:text-white hover:bg-input-bg rounded min-w-[125px]',
  );
  const dropdownRootClassName = twJoin(
    'max-w-40 rounded shadow-xl overflow-hidden z-30 border-contrast bg-white/60 dark:bg-foreground/60 backdrop-blur-sm focus-visible:outline-none',
  );
  const dropdownItemClassName = twJoin(
    'py-[10px] text-sm leading-normal dark:text-white w-full text-left px-4 hover:text-foreground hover:backdrop-blur-lg',
  );

  const filtersCount = useMemo(() => {
    let count = 0;
    for (const filter in filters) {
      if (Object.prototype.hasOwnProperty.call(filters, filter)) {
        count += filters[filter as FilterType].length;
      }
    }

    if (priceRange) count += 1;

    return count;
  }, [filters, priceRange]);

  if (pathname !== '/shop') return null;

  return (
    <div className='relative'>
      <div className={twMerge('flex items-center gap-3', className)}>
        <Dropdown
          label={!order ? 'Сортировка' : options[order]}
          className={dropdownButtonClassName}
          rootClassName={dropdownRootClassName}
        >
          {Object.entries(options).map(([value, label]) => {
            return (
              <DropdownItem
                key={value}
                label={label}
                className={dropdownItemClassName}
                onClick={() => {
                  setOrderByParam(value as keyof Options);
                }}
              />
            );
          })}
          <DropdownItem
            label='По умолчанию'
            className={dropdownItemClassName}
            onClick={() => {
              setOrderByParam(undefined);
            }}
          />
        </Dropdown>
        <Filters
          opened={filtersOpened}
          onToggle={() => {
            setFiltersOpened(false);
          }}
        />
        <button
          className={dropdownButtonClassName}
          onClick={() => {
            setFiltersOpened(true);
          }}
        >
          <div className='flex items-center gap-2'>
            Фильтр <Filter />
            {!!filtersCount && (
              <div className='relative -left-3 -top-2.5 flex h-[14px] w-[14px] items-center justify-center rounded-full bg-[#FF5630] text-[10px] leading-3 text-white'>
                {filtersCount}
              </div>
            )}
          </div>
        </button>
      </div>
    </div>
  );
}
