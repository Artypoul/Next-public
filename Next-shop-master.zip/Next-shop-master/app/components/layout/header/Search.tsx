'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { getSearchHistory } from '@/lib/gigma';
import { Close, History, Search as SearchIcon } from '@/ui/components/Icons';

import { useFilters, useShop, useUser } from '../context';

export function Search() {
  const [isActive, setIsActive] = useState(false);
  const [searches, setSearches] = useState<string[]>([]);

  const { setSearchQuery, query } = useFilters();
  const { popular } = useShop();

  const ref = useRef<HTMLInputElement>(null);

  const { token, userIsFilled } = useUser();

  const getHistory = useCallback(async () => {
    if (!token || !userIsFilled) {
      setSearches([]);
      return;
    }

    const res = await getSearchHistory(token);
    if (res?.searchRequests?.length) {
      const uniq = [
        ...new Set(res.searchRequests.map(item => item.value.toLowerCase())),
      ];
      setSearches(uniq.slice(0, 10));
    }
  }, [token, userIsFilled]);

  const popularSearches = useMemo(() => {
    const uniq = [...new Set(popular.map(item => item.value.toLowerCase()))];
    return uniq.slice(0, 10);
  }, [popular]);

  useEffect(() => {
    getHistory();
  }, [getHistory]);

  return (
    <div className='relative w-full'>
      <div className='group relative flex-grow'>
        <input
          ref={ref}
          type='text'
          className='w-full rounded bg-input-bg py-1.5 pl-9 pr-3 text-xs leading-[19px] placeholder:text-input-text focus:outline-none placeholder:group-hover:text-foreground dark:placeholder:group-hover:text-light md:py-3 md:text-sm'
          placeholder='хочу купить'
          spellCheck={false}
          onFocus={() => {
            setIsActive(true);
          }}
          onBlur={() => {
            setIsActive(false);
          }}
          onChange={e => {
            setSearchQuery(e.target.value);
          }}
          value={query}
        />
        <SearchIcon className='absolute left-3 top-1/2 -translate-y-1/2 text-input-text group-hover:text-foreground dark:group-hover:text-light' />
        {!!query && (
          <Close
            className='absolute right-3 top-1/2 -translate-y-1/2 text-foreground dark:text-light lg:cursor-pointer'
            onClick={() => {
              setSearchQuery('');
            }}
          />
        )}
      </div>
      {isActive && !!searches?.length && (
        <div className='absolute inset-x-0 bottom-0 translate-y-full rounded-b-lg bg-white p-5 shadow-lg dark:bg-black'>
          {searches.map((item, index) => {
            return (
              <button
                key={index}
                type='button'
                className='flex w-full items-center gap-4 py-2'
                onMouseDown={() => {
                  setSearchQuery(item);
                  setIsActive(false);
                }}
              >
                <History className='min-w-6 opacity-50' /> {item}
              </button>
            );
          })}
        </div>
      )}
      {isActive && !searches?.length && !!popularSearches?.length && (
        <div className='absolute inset-x-0 bottom-0 translate-y-full rounded-b-lg bg-white p-5 shadow-lg dark:bg-black'>
          {popularSearches.map((item, index) => {
            return (
              <button
                key={index}
                type='button'
                className='flex w-full items-center gap-4 py-2'
                onMouseDown={() => {
                  setSearchQuery(item);
                  setIsActive(false);
                }}
              >
                <History className='min-w-6 opacity-50' /> {item}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
