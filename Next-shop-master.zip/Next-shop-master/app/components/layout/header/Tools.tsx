'use client';

import type { Notification } from '@/lib/gigma/types';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { getNotifications } from '@/lib/gigma';
import { Bag, Bell } from '@/ui/components/Icons';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/ui/components/Popover';

import { useShop, useUser } from '../context';
import { Profile } from '../profile';
import { ThemeChanger } from '../theme/ThemeChanger';

export function Tools() {
  const [isClient, setIsClient] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const { totalCount } = useShop();
  const { token } = useUser();

  useEffect(() => {
    const getData = async () => {
      const notificationsData = await getNotifications(token);
      if (notificationsData.length) {
        setNotifications(notificationsData);
      }
    };

    getData();
  }, [token]);

  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <div className='flex items-center gap-3 text-foreground/50 dark:text-white md:gap-3'>
      <div className='hidden h-[42px] w-[42px] items-center justify-center rounded hover:bg-input-bg md:flex'>
        <ThemeChanger />
      </div>
      <Popover>
        <PopoverTrigger className='relative hidden h-[42px] w-[42px] items-center justify-center rounded hover:bg-input-bg md:flex'>
          <Bell />
          {!!notifications.length && (
            <div className='absolute right-1 top-1 flex h-[14px] w-[14px] items-center justify-center rounded-full bg-[#FF5630] text-[10px] leading-3 text-white'>
              {notifications.length}
            </div>
          )}
        </PopoverTrigger>
        <PopoverContent className='z-50 w-full max-w-[280px] gap-2 rounded border-l border-light bg-white px-2 py-4 shadow-lg dark:border-light/10 dark:bg-foreground'>
          {notifications.map((notification, index) => {
            return (
              <Link
                key={index}
                className={twJoin(
                  'flex items-center gap-2.5 px-4 py-[5px]',
                  !notification.action_url && 'pointer-events-none',
                )}
                href={notification.action_url || '#'}
              >
                {!!notification.icon && (
                  <Image
                    src={notification.icon}
                    alt=''
                    width={17}
                    height={17}
                    className={twJoin(
                      notification.icon.endsWith('.svg') && 'dark:invert',
                      'h-[17px] w-[17px] object-scale-down',
                    )}
                  />
                )}

                <div className='text-sm font-medium leading-[22px]'>
                  {notification.title}
                </div>
              </Link>
            );
          })}

          {!notifications.length && (
            <div className='px-4 py-[5px] text-center text-sm leading-[22px] opacity-50'>
              У вас нет новых уведомлений
            </div>
          )}
        </PopoverContent>
      </Popover>
      <Link href='/card'>
        <div className='relative flex items-center justify-center rounded hover:bg-input-bg md:h-[42px] md:w-[42px] lg:cursor-pointer'>
          <Bag className='max-w-[18px]' />
          {isClient && !!totalCount && (
            <div className='absolute -right-[6px] -top-[2px] flex h-[14px] w-[14px] items-center justify-center rounded-full bg-[#FF5630] text-[10px] leading-3 text-white md:right-1 md:top-1'>
              {totalCount}
            </div>
          )}
        </div>
      </Link>
      <Profile />
    </div>
  );
}
