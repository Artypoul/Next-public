import { getMenu } from '@/lib/gigma';

import { Address } from './Address';
import { MobileMenu } from './MobileMenu';
import { Params } from './Params';
import { Search } from './Search';
import { Tools } from './Tools';

export default async function Header() {
  const menu = await getMenu('navpanel');

  return (
    <>
      <header className='sticky top-0 z-30 flex items-center gap-2 bg-white p-4 dark:bg-contrast md:gap-4 lg:gap-[18px] lg:px-5 lg:py-[18px]'>
        <MobileMenu items={menu ? menu.children : []} />
        <Address />
        <Search />
        <Params className='hidden lg:flex' />
        <Tools />
      </header>
      <Params className='flex justify-between px-4 lg:hidden' />
    </>
  );
}
