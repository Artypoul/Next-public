'use client';

import type { MenuItems } from '@/lib/gigma/types';

import Image from 'next/image';
import Link from 'next/link';
import { twJoin, twMerge } from 'tailwind-merge';

import { ArrowRight } from '@/ui/components/Icons';

type ItemProps = {
  index: number;
  item: MenuItems;
  opened: boolean;
  expanded: boolean;
  onToggle: (index: number) => void;
};

export function Item({ item, expanded, opened, onToggle, index }: ItemProps) {
  const collapsedClass = twJoin(
    'relative flex flex-col items-center justify-center gap-2 overflow-hidden ease-in after:absolute after:inset-y-0 after:right-0 after:-z-10 after:w-px after:translate-y-full after:bg-black after:transition-transform after:duration-500 after:content-[""] hover:after:translate-y-0 text-xs',
  );
  const expandedClass = twJoin(
    'flex items-center gap-x-[10px] font-medium leading-[22px] text-sm hover:text-gold',
  );

  return (
    <li
      className={twJoin(
        'relative overflow-hidden',
        expanded ? 'flex flex-col px-[10px] py-3' : 'py-1',
      )}
    >
      {item.children.length ? (
        <div
          className={twMerge(
            expanded ? expandedClass : collapsedClass,
            'lg:cursor-pointer',
          )}
          onClick={() => {
            if (item.children.length) {
              onToggle(index);
            }
          }}
        >
          <Image
            src={item.avatar}
            alt={item.name}
            width={30}
            height={30}
            className={twJoin(item.avatar.endsWith('.svg') && 'dark:invert')}
          />

          <span className='flex-grow'>{item.name}</span>
          {expanded && !!item.children?.length && (
            <ArrowRight
              className={twJoin(opened && '-rotate-90', 'duration-200')}
            />
          )}
        </div>
      ) : (
        <Link
          href={item.url}
          className={twMerge(
            expanded ? expandedClass : collapsedClass,
            'lg:cursor-pointer',
          )}
        >
          <Image
            src={item.avatar}
            alt={item.name}
            width={30}
            height={30}
            className='dark:invert'
          />

          <span className='flex-grow'>{item.name}</span>
        </Link>
      )}
      {!!item.children?.length && (
        <ul
          className={twJoin(
            'flex flex-col gap-4 px-10 duration-200',
            !opened ? 'h-0 opacity-0' : 'mt-4 opacity-100',
          )}
        >
          {item.children.map((subItem, subIndex) => {
            return (
              <li
                key={`parent-${index}-children-${subIndex}`}
                className='text-sm font-semibold lg:cursor-pointer'
              >
                <Link href={subItem.url}>{subItem.name}</Link>
              </li>
            );
          })}
        </ul>
      )}
    </li>
  );
}
