'use client';

import type { MenuItems } from '@/lib/gigma/types';

import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

type MiniItemProps = {
  index: number;
  item: MenuItems;
  onToggle: (index: number) => void;
};

export function ItemMini({ item, index, onToggle }: MiniItemProps) {
  const className =
    'text-center w-full relative flex flex-col items-center justify-center gap-2 overflow-hidden ease-in after:absolute after:inset-y-0 after:right-0 after:-z-10 after:w-px after:translate-y-full after:bg-black after:transition-transform after:duration-500 after:content-[""] hover:after:translate-y-0 text-xs lg:cursor-pointer';
  return (
    <li className='relative overflow-hidden py-1'>
      {item.children.length ? (
        <div
          className={className}
          onClick={() => {
            onToggle(index);
          }}
        >
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={30}
              height={30}
              className={twJoin(
                item.avatar.endsWith('.svg') && 'dark:invert',
                'h-[30px] w-[30px] object-scale-down',
              )}
            />
          )}

          <span className='flex-grow'>{item.name}</span>
        </div>
      ) : (
        <button
          type='button'
          onClick={() => {
            window.location.href = item.url;
          }}
          className={className}
        >
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={30}
              height={30}
              className='h-[30px] w-[30px] object-scale-down dark:invert'
            />
          )}

          <span className='flex-grow text-center'>{item.name}</span>
        </button>
      )}
    </li>
  );
}
