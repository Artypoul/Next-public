'use client';

import type { MenuItems } from '@/lib/gigma/types';

import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

import { ArrowRight } from '@/ui/components/Icons';

type ItemWideProps = {
  index: number;
  item: MenuItems;
  opened: boolean;
  onToggle: (index: number) => void;
};

export function ItemWide({ item, opened, onToggle, index }: ItemWideProps) {
  const className =
    'text-left flex items-center gap-x-[10px] font-medium leading-[22px] text-sm hover:text-gold lg:cursor-pointer duration-200';

  return (
    <li className='relative flex flex-col overflow-hidden px-[10px] py-3'>
      {item.children.length ? (
        <div
          className={className}
          onClick={() => {
            if (item.children.length) {
              onToggle(index);
            }
          }}
        >
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={30}
              height={30}
              className={twJoin(
                item.avatar.endsWith('.svg') && 'dark:invert',
                'h-[30px] w-[30px] object-scale-down',
              )}
            />
          )}

          <span className='flex-grow'>{item.name}</span>
          {!!item.children?.length && (
            <ArrowRight
              className={twJoin(opened && '-rotate-90', 'duration-200')}
            />
          )}
        </div>
      ) : (
        <button
          type='button'
          onClick={() => {
            window.location.href = item.url;
          }}
          className={className}
        >
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={30}
              height={30}
              className='h-[30px] w-[30px] object-scale-down dark:invert'
            />
          )}

          <span className='flex-grow'>{item.name}</span>
        </button>
      )}
      {!!item.children?.length && (
        <ul
          className={twJoin(
            'flex flex-col gap-4 px-10 duration-200',
            !opened ? 'h-0 opacity-0' : 'mt-4 opacity-100',
          )}
        >
          {item.children.map((subItem, subIndex) => {
            return (
              <li
                key={`parent-${index}-children-${subIndex}`}
                className='text-sm font-semibold lg:cursor-pointer'
              >
                <button
                  type='button'
                  onClick={() => {
                    window.location.href = subItem.url;
                  }}
                  className='text-left duration-200 hover:text-gold'
                >
                  {subItem.name}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </li>
  );
}
