import Image from 'next/image';
import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { Star } from '@/ui/components/Icons';

type LogoProps = {
  expanded?: boolean;
  src?: string;
};

const shopName = process.env.NEXT_PUBLIC_SHOP_NAME ?? 'Component';

export function Logo({ expanded = true, src }: LogoProps) {
  return (
    <Link href='/'>
      <div
        className={twJoin(
          'flex h-[72px] items-center gap-2',
          !expanded ? 'justify-center' : 'pl-[10px]',
        )}
      >
        {src ? (
          <Image
            src={src}
            width={40}
            height={40}
            alt='seimoment'
            className={twJoin(
              src.endsWith('.svg') && 'dark:invert',
              'h-10 w-10 object-scale-down',
            )}
          />
        ) : (
          <Star />
        )}

        {expanded && shopName}
      </div>
    </Link>
  );
}
