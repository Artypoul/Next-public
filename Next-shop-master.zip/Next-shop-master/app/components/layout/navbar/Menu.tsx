'use client';

import type { MenuItems } from '@/lib/gigma/types';

import { Suspense, useEffect, useState } from 'react';
import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

import { getUserFullName } from '@/lib/utils';
import { ArrowLeft, ArrowRight } from '@/ui/components/Icons';

import { useUser } from '../context';
import { ItemMini } from './ItemMini';
import { ItemWide } from './ItemWide';
import { Logo } from './Logo';

type MenuItemsProps = {
  items: MenuItems[];
  logo?: string;
};

export function Menu({ items, logo }: MenuItemsProps) {
  const [expanded, setExpanded] = useState(false);
  const [opened, setOpened] = useState<number>();
  const { user } = useUser();

  const onToggle = (index: number) => {
    setExpanded(true);
    setOpened(prev => {
      if (prev !== index) return index;
      return undefined;
    });
  };

  useEffect(() => {
    if (!expanded) {
      setOpened(undefined);
    }
  }, [expanded]);

  const userName = getUserFullName(user) ?? '';

  return (
    <nav
      className={twJoin(
        expanded ? 'w-[280px] min-w-[280px]' : 'w-[108px] min-w-[108px]',
        'sticky top-0 float-left hidden h-screen flex-col overflow-hidden overflow-y-auto border-r border-r-light dark:border-r-light/10 lg:flex',
      )}
    >
      <Suspense>
        <Logo expanded={expanded} src={logo} />
      </Suspense>
      {expanded && (
        <div className='flex h-[72px] items-center px-[10px]'>
          <div className='flex items-center gap-4'>
            <div className='flex h-10 w-10 items-center justify-center'>
              <Image
                src='/avatar_default.jpg'
                width={40}
                height={40}
                alt={userName}
                className='scale-90 overflow-hidden rounded object-cover hover:scale-100'
              />
            </div>
            <div className='flex flex-col gap-2 font-medium'>
              <div className='text-sm leading-none'>{userName}</div>
              <div className='text-xs leading-none text-foreground/50 dark:text-light/50'>
                {user?.counterparty?.type?.name ?? 'Пользователь'}
              </div>
            </div>
          </div>
        </div>
      )}
      {expanded && (
        <div className='px-[10px] py-4 text-xs font-semibold leading-[22px] text-foreground/50 dark:text-light/50'>
          магазин
        </div>
      )}
      <ul className={twJoin('flex flex-grow flex-col', !expanded && 'gap-2')}>
        {items.map((item, index) => {
          if (expanded) {
            return (
              <ItemWide
                key={index}
                index={index}
                item={item}
                opened={opened === index}
                onToggle={onToggle}
              />
            );
          } else {
            return (
              <ItemMini
                key={index}
                index={index}
                item={item}
                onToggle={onToggle}
              />
            );
          }
        })}
      </ul>
      <button
        type='button'
        className='relative hidden min-h-[60px] w-full items-center justify-center overflow-hidden after:absolute after:inset-0 after:-z-10 after:translate-y-full after:bg-foreground after:transition-transform after:duration-300 after:content-[""] hover:text-white hover:after:translate-y-0 md:flex'
        onClick={() => setExpanded(prev => !prev)}
      >
        {!expanded ? <ArrowRight /> : <ArrowLeft />}
      </button>
    </nav>
  );
}
