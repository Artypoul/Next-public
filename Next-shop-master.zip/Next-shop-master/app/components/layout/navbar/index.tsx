import { getLogoContent, getMenu } from '@/lib/gigma';
import { BlockTypeId } from '@/lib/gigma/types';

import { Menu } from './Menu';

export default async function Navbar() {
  const menu = await getMenu('navpanel');

  const logoRes = await getLogoContent();
  let logo: string | undefined = undefined;
  if (logoRes?.block_type?.id === BlockTypeId.Image && logoRes.file?.path) {
    logo = logoRes.file.path;
  }

  return <Menu items={menu ? menu.children : []} logo={logo} />;
}
