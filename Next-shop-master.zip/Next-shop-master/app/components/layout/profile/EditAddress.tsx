'use client';

import type { DadataAddress, User } from '@/lib/gigma/types';

import { useCallback } from 'react';
import { FormProvider, SubmitHandler, useForm } from 'react-hook-form';
import { KeyedMutator } from 'swr';
import { twJoin } from 'tailwind-merge';

import { updateUser } from '@/lib/gigma';
import { Button } from '@/ui/components';
import { DadataField } from '@/ui/fields';

type FormValues = {
  address?: DadataAddress;
};

export function EditAddress({
  user,
  token,
  mutate,
  close,
}: {
  user: User;
  token: string;
  mutate: KeyedMutator<User | undefined>;
  close: () => void;
}) {
  const methods = useForm<FormValues>({
    mode: 'onSubmit',
    defaultValues: {
      address: user?.counterparty?.address
        ? {
            name: user.counterparty.address,
            value: user.counterparty.address,
          }
        : undefined,
    },
  });

  const {
    handleSubmit,
    watch,
    control,
    formState: { isSubmitting, errors },
    setError,
    clearErrors,
  } = methods;

  const addr = watch('address');

  const onSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ address }) => {
      if (!token) return;

      clearErrors('root');
      try {
        const userUpdated = await updateUser({
          address: address?.value,
          token,
        });

        if (!userUpdated) throw new Error('Не удалось обновить данные');

        mutate(userUpdated);
        close();
      } catch {
        setError('root', {
          type: 'server',
          message: 'Не удалось обновить данные',
        });
      }
    },
    [token, clearErrors, setError, mutate, close],
  );

  return (
    <FormProvider {...methods}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className='flex flex-col gap-[10px]'>
          <DadataField
            control={control}
            name='address'
            initialValue={addr?.value ?? 'г Москва'}
            errorClassName={twJoin(errors.address?.message ? 'mt-2' : 'mt-0')}
            disabled={isSubmitting}
            placeholder='Адрес'
            rules={{
              validate: address =>
                (address as DadataAddress)?.value ? undefined : 'Введите адрес',
            }}
          />
          {errors.root?.type === 'server' && !!errors.root.message && (
            <div className='text-error'>{errors.root.message}</div>
          )}
          <div>
            <Button
              type='submit'
              variant='outlined'
              className='w-full border-black bg-black text-white duration-300 hover:text-gold'
              disabled={isSubmitting || !!errors.address?.message}
            >
              ГОТОВО
            </Button>
          </div>
        </div>
      </form>
    </FormProvider>
  );
}
