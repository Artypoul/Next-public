'use client';

import type { User } from '@/lib/gigma/types';

import { useCallback } from 'react';
import { SubmitHandler, useForm } from 'react-hook-form';
import { KeyedMutator } from 'swr';
import { twJoin } from 'tailwind-merge';

import { updateUser } from '@/lib/gigma';
import { validateEmail } from '@/lib/utils';
import { Button } from '@/ui/components';
import { TextField } from '@/ui/fields';

type FormValues = {
  email: string;
};

export function EditEmail({
  user,
  token,
  mutate,
  close,
}: {
  user: User;
  token: string;
  mutate: KeyedMutator<User | undefined>;
  close: () => void;
}) {
  const {
    handleSubmit,
    control,
    formState: { isSubmitting, errors },
    setError,
    clearErrors,
  } = useForm<FormValues>({
    mode: 'onSubmit',
    defaultValues: {
      email: user?.counterparty?.email ?? '',
    },
  });

  const onSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ email }) => {
      if (!token) return;

      clearErrors('root');
      try {
        const userUpdated = await updateUser({
          email,
          token,
        });

        if (!userUpdated) throw new Error('Не удалось обновить данные');

        mutate(userUpdated);
        close();
      } catch {
        setError('root', {
          type: 'server',
          message: 'Не удалось обновить данные',
        });
      }
    },
    [token, clearErrors, setError, mutate, close],
  );

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className='flex flex-col gap-[10px]'>
        <TextField
          control={control}
          name='email'
          className='h-[40px] border border-gold text-sm'
          errorClassName={twJoin(errors.email?.message ? 'mt-2' : 'mt-0')}
          disabled={isSubmitting}
          placeholder='E-mail'
          rules={{
            validate: email =>
              email && !validateEmail(email as string)
                ? 'Введите корректтный E-mail'
                : undefined,
          }}
        />
        {errors.root?.type === 'server' && !!errors.root.message && (
          <div className='text-error'>{errors.root.message}</div>
        )}
        <div>
          <Button
            type='submit'
            variant='outlined'
            className='w-full border-black bg-black text-white duration-300 hover:text-gold'
            disabled={isSubmitting || !!errors.email?.message}
          >
            ГОТОВО
          </Button>
        </div>
      </div>
    </form>
  );
}
