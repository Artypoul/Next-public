'use client';

import type { User } from '@/lib/gigma/types';

import { useCallback } from 'react';
import { SubmitHandler, useForm } from 'react-hook-form';
import { KeyedMutator } from 'swr';
import { twJoin } from 'tailwind-merge';

import { updateUser } from '@/lib/gigma';
import { capitalize } from '@/lib/utils';
import { Button } from '@/ui/components';
import { TextField } from '@/ui/fields';

type FormValues = {
  firstName: string;
  lastName: string;
};

export function EditName({
  user,
  token,
  mutate,
  close,
}: {
  user: User;
  token: string;
  mutate: KeyedMutator<User | undefined>;
  close: () => void;
}) {
  const {
    handleSubmit,
    control,
    formState: { isSubmitting, errors },
    setError,
    clearErrors,
  } = useForm<FormValues>({
    mode: 'onSubmit',
    defaultValues: {
      firstName: user?.counterparty?.first_name ?? '',
      lastName: user?.counterparty?.last_name ?? '',
    },
  });

  const onSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ firstName, lastName }) => {
      if (!token) return;

      clearErrors('root');
      try {
        const userUpdated = await updateUser({
          first_name: firstName,
          last_name: lastName,
          token,
        });

        if (!userUpdated) throw new Error('Не удалось обновить данные');

        mutate(userUpdated);
        close();
      } catch {
        setError('root', {
          type: 'server',
          message: 'Не удалось обновить данные',
        });
      }
    },
    [token, clearErrors, setError, mutate, close],
  );

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className='flex flex-col gap-[10px]'>
        <TextField
          control={control}
          name='firstName'
          className='h-[40px] border border-gold text-sm'
          errorClassName={twJoin(errors.firstName?.message ? 'mt-2' : 'mt-0')}
          disabled={isSubmitting}
          placeholder='Имя*'
          parse={capitalize}
          sanitizeOnBlur
          rules={{
            required: 'Введите имя',
            minLength: { value: 2, message: 'Не менее 2 букв' },
          }}
        />
        <TextField
          control={control}
          name='lastName'
          className='h-[40px] border border-gold text-sm'
          errorClassName={twJoin(errors.lastName?.message ? 'mt-2' : 'mt-0')}
          parse={capitalize}
          sanitizeOnBlur
          rules={{
            minLength: { value: 2, message: 'Не менее 2 букв' },
          }}
          disabled={isSubmitting}
          placeholder='Фамилия'
        />
        {errors.root?.type === 'server' && !!errors.root.message && (
          <div className='text-error'>{errors.root.message}</div>
        )}
        <div>
          <Button
            type='submit'
            variant='outlined'
            className='w-full border-black bg-black text-white duration-300 hover:text-gold'
            disabled={isSubmitting || !!errors.firstName?.message}
          >
            ГОТОВО
          </Button>
        </div>
      </div>
    </form>
  );
}
