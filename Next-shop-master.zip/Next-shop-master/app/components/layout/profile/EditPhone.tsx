'use client';

import type { User } from '@/lib/gigma/types';
import type { KeyboardEvent } from 'react';

import { useCallback, useEffect, useState } from 'react';
import { format } from 'date-fns';
import { SubmitHandler, useForm } from 'react-hook-form';
import { KeyedMutator } from 'swr';
import { twJoin } from 'tailwind-merge';

import { requestPnoneChange, verifyPhoneChange } from '@/lib/gigma';
import { Button } from '@/ui/components';
import { PhoneField, TextField } from '@/ui/fields';

type FormValues = {
  phone: string;
  password: string;
};

export function EditPhone({
  user,
  token,
  mutate,
  close,
}: {
  user: User;
  token: string;
  mutate: KeyedMutator<User | undefined>;
  close: () => void;
}) {
  const [codeWaiting, setCodeWaiting] = useState(false);
  const [timer, setTimer] = useState(60 * 1000);
  const {
    handleSubmit,
    watch,
    control,
    formState: { isSubmitting, errors },
    setError,
    clearErrors,
  } = useForm<FormValues>({
    mode: 'onSubmit',
    defaultValues: {
      phone: user?.counterparty?.phone_1 ?? '',
      password: '',
    },
  });

  const [phone, password] = watch(['phone', 'password']);

  const phoneChanged = phone.replace(/\D/g, '') !== user?.counterparty?.phone_1;

  const onPhoneSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ phone }) => {
      if (!token) return;
      setCodeWaiting(false);
      clearErrors('root');
      try {
        const codeSended = await requestPnoneChange(
          phone.replace(/\D/g, ''),
          token,
        );

        if (!codeSended) throw new Error('Не удалось обновить данные');

        setCodeWaiting(true);
      } catch {
        setError('root', {
          type: 'phone',
          message: 'Не удалось обновить данные',
        });
      }
    },
    [token, clearErrors, setError],
  );

  const onCodeSubmit: SubmitHandler<FormValues> = useCallback(
    async ({ password }) => {
      if (!token) return;

      clearErrors('root');
      try {
        const userUpdated = await verifyPhoneChange(password, token);

        if (!userUpdated) throw new Error('Не удалось обновить данные');

        mutate(userUpdated);
        close();
      } catch {
        setError('root', {
          type: 'code',
          message: 'Не удалось обновить данные',
        });
      }
    },
    [token, clearErrors, setError, mutate, close],
  );

  useEffect(() => {
    if (!codeWaiting) return;
    const timer = setInterval(() => {
      setTimer(prev => (prev > 1000 ? prev - 1000 : 0));
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, [codeWaiting]);

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit(onCodeSubmit)();
    }
  };

  return (
    <div className='flex flex-col gap-[10px]'>
      <PhoneField
        control={control}
        name='phone'
        className='h-[40px] border border-gold text-sm'
        errorClassName={twJoin(errors.phone?.message ? 'mt-2' : 'mt-0')}
        disabled={isSubmitting || (codeWaiting && timer > 0)}
        placeholder='E-mail'
        rules={{
          validate: phone =>
            !/\+7 \(\d{3}\) \d{3} \d{2} \d{2}/.test(phone as string)
              ? 'Введите номер'
              : undefined,
        }}
      />
      {errors.root?.type === 'phone' && !!errors.root.message && (
        <div className='text-error'>{errors.root.message}</div>
      )}
      <TextField
        name='password'
        control={control}
        placeholder={
          codeWaiting ? 'Введите последние 4 цифры' : 'Вам поступит звонок...'
        }
        maxLength={4}
        className='h-[40px] border border-gold text-sm'
        errorClassName={twJoin(errors.password?.message ? 'mt-2' : 'mt-0')}
        inputMode='decimal'
        disabled={isSubmitting || !codeWaiting}
        staticValidate={{ pattern: /\d/, message: 'Только цифры' }}
        rules={{
          validate: code =>
            code && !/\d{4}/.test(code as string) ? 'Введите код' : undefined,
        }}
        onKeyDown={onKeyDown}
      />
      {codeWaiting && (
        <div className='text-center text-xs text-black/50'>
          Запросите код повторно
          {timer > 1000 && ` через `}
          {timer > 1000 && (
            <span className='text-gold'>{format(timer, 'mm:ss')}</span>
          )}
        </div>
      )}
      <div className='flex gap-6'>
        <Button
          variant='outlined'
          className='w-full border-black bg-black text-white duration-300 hover:text-gold'
          disabled={
            isSubmitting ||
            !!errors.password?.message ||
            !!errors.phone?.message ||
            !phoneChanged ||
            !password
          }
          onClick={handleSubmit(onCodeSubmit)}
        >
          ГОТОВО
        </Button>
        <Button
          variant='outlined'
          className='w-full border-black bg-black text-white duration-300 hover:text-gold'
          disabled={
            isSubmitting ||
            !!errors.phone?.message ||
            !phoneChanged ||
            (codeWaiting && timer > 0)
          }
          onClick={handleSubmit(onPhoneSubmit)}
        >
          ЗАПРОСИТЬ
        </Button>
      </div>
    </div>
  );
}
