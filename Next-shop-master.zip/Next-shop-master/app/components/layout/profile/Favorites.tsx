import Link from 'next/link';

import { getNoun } from '@/lib/utils';
import { Favorite } from '@/ui/components/Icons';

import { useShop } from '../context';

export function Favorites({ onClick }: { onClick: () => void }) {
  const { favorites } = useShop();

  return (
    <div className='relative flex min-h-[45px] flex-col px-[25px] py-4'>
      <Link
        href='/favorites'
        className='group flex cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
        onClick={onClick}
      >
        <Favorite />
        <div>
          <span className='duration-200 group-hover:text-gold'>Избранное</span>
          <div className='text-sm opacity-50'>
            {favorites.length}{' '}
            {getNoun(favorites.length, 'товар', 'товара', 'товаров')}
          </div>
        </div>
      </Link>
    </div>
  );
}
