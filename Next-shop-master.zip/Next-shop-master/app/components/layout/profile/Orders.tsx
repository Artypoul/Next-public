import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';

import { getOrders } from '@/lib/gigma';
import { getNoun } from '@/lib/utils';
import { Orders as OrdersIcon } from '@/ui/components/Icons';

import { useUser } from '../context';

export function Orders({ onClick }: { onClick: () => void }) {
  const [ordersCount, setOrdersCount] = useState(0);
  const { userIsFilled, token } = useUser();

  const getOrdesCount = useCallback(async () => {
    if (!userIsFilled || !token) return;
    try {
      const res = await getOrders(token);
      if (res) setOrdersCount(res.ordersCount);
    } catch (error) {
      console.error(error);
    }
  }, [userIsFilled, token]);

  useEffect(() => {
    getOrdesCount();
  }, [getOrdesCount]);

  return (
    <div className='relative flex min-h-[45px] flex-col px-[25px] py-4'>
      <Link
        href='/orders'
        className='group flex cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
        onClick={onClick}
      >
        <OrdersIcon />
        <div>
          <span className='duration-200 group-hover:text-gold'>Заказы</span>
          <div className='text-sm opacity-50'>
            {ordersCount} {getNoun(ordersCount, 'заказ', 'заказа', 'заказов')}
          </div>
        </div>
      </Link>
    </div>
  );
}
