import { useCallback, useEffect, useMemo, useState } from 'react';

import { getMenu } from '@/lib/gigma';
import { MenuItems } from '@/lib/gigma/types';

import { ProfileMenuItem } from './ProfileMenuItem';

export function ProfileMenu() {
  const [opened, setOpened] = useState<number>();
  const [loading, setLoading] = useState(false);
  const [profileMenu, setProfileMenu] = useState<MenuItems>();

  const getProfileMenu = useCallback(async () => {
    setLoading(true);
    try {
      const MENU_ID = process.env.NEXT_PUBLIC_PROFILE_MENU_ID ?? '';
      const menu = await getMenu(MENU_ID);
      setProfileMenu(menu);
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    getProfileMenu();
  }, [getProfileMenu]);

  const items = useMemo(() => {
    return profileMenu?.children ?? [];
  }, [profileMenu]);

  const onToggle = (index: number) => {
    setOpened(prev => {
      if (prev !== index) return index;
      return undefined;
    });
  };

  if (loading) return null;

  return (
    <>
      {items.map((item, index) => {
        return (
          <ProfileMenuItem
            key={index}
            index={index}
            item={item}
            opened={opened === index}
            onToggle={onToggle}
          />
        );
      })}
    </>
  );
}
