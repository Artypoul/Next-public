'use client';

import type { MenuItems } from '@/lib/gigma/types';

import Image from 'next/image';
import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { ArrowDown } from '@/ui/components/Icons';

type ProfileMenuItemProps = {
  index: number;
  item: MenuItems;
  opened: boolean;
  onToggle: (index: number) => void;
};

export function ProfileMenuItem({
  item,
  opened,
  onToggle,
  index,
}: ProfileMenuItemProps) {
  const className =
    'flex items-center gap-x-[10px] font-medium leading-[22px] text-sm hover:text-gold cursor-pointer duration-200 min-h-[45px]';

  return (
    <div className='relative flex flex-col overflow-hidden px-[25px] py-4'>
      {item.children.length ? (
        <div
          className={className}
          onClick={() => {
            if (item.children.length) {
              onToggle(index);
            }
          }}
        >
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={24}
              height={24}
              className={twJoin(item.avatar.endsWith('.svg') && 'dark:invert')}
            />
          )}

          <span className='flex-grow'>{item.name}</span>
          {!!item.children?.length && (
            <ArrowDown
              className={twJoin(opened && '-rotate-180', 'duration-200')}
            />
          )}
        </div>
      ) : (
        <Link href={item.url} className={className}>
          {item.avatar && (
            <Image
              src={item.avatar}
              alt={item.name}
              width={24}
              height={24}
              className='dark:invert'
            />
          )}

          <span className='flex-grow'>{item.name}</span>
        </Link>
      )}
      {!!item.children?.length && (
        <ul
          className={twJoin(
            'flex flex-col gap-4 px-6 duration-200',
            !opened ? 'h-0 opacity-0' : 'mt-4 opacity-100',
          )}
        >
          {item.children.map((subItem, subIndex) => {
            return (
              <li
                key={`parent-${index}-children-${subIndex}`}
                className='text-sm font-semibold lg:cursor-pointer'
              >
                <Link
                  href={subItem.url}
                  className='flex min-h-[45px] items-center gap-x-[10px] duration-200 hover:text-gold'
                >
                  {subItem.avatar && (
                    <Image
                      src={subItem.avatar}
                      alt={subItem.name}
                      width={24}
                      height={24}
                      className={twJoin(
                        subItem.avatar.endsWith('.svg') && 'dark:invert',
                      )}
                    />
                  )}
                  <span className='flex-grow'>{subItem.name}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
