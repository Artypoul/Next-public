'use client';

import { useEffect, useState } from 'react';
import { twJoin } from 'tailwind-merge';

import { formatPhone, getUserFullName } from '@/lib/utils';
import { Button } from '@/ui/components';
import {
  ArrowDown,
  Delivery,
  Email,
  Phone,
  User as UserIcon,
} from '@/ui/components/Icons';

import { useUser } from '../context';
import { EditAddress } from './EditAddress';
import { EditEmail } from './EditEmail';
import { EditName } from './EditName';
import { EditPhone } from './EditPhone';

type EditMode = 'name' | 'phone' | 'email' | 'address' | undefined;

export function User({ menuIsOpened }: { menuIsOpened: boolean }) {
  const { user, token, mutate, logout } = useUser();
  const [edit, setEdit] = useState<EditMode>();
  const fullName = getUserFullName(user);

  useEffect(() => {
    setEdit(undefined);
  }, [menuIsOpened]);

  if (!user) return null;

  return (
    <>
      <div className='relative flex flex-col gap-[10px] px-[25px] py-4'>
        <div
          className='group flex min-h-[45px] cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
          onClick={() => {
            setEdit(prev => (prev === 'name' ? undefined : 'name'));
          }}
        >
          <UserIcon className='min-w-6' />
          <span className='flex-grow overflow-hidden text-ellipsis whitespace-nowrap duration-200 group-hover:text-gold'>
            {fullName}
          </span>
          <ArrowDown
            className={twJoin(
              edit === 'name' && '-rotate-180',
              'min-w-[14px] duration-200',
            )}
          />
        </div>
        {edit === 'name' && (
          <EditName
            user={user}
            token={token}
            mutate={mutate}
            close={() => {
              setEdit(undefined);
            }}
          />
        )}
        <Button onClick={() => logout()}>Выйти</Button>
        <div
          className='group flex min-h-[45px] cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
          onClick={() => {
            setEdit(prev => (prev === 'phone' ? undefined : 'phone'));
          }}
        >
          <Phone className='min-w-6 text-gold' />
          <div className='flex-grow overflow-hidden text-ellipsis whitespace-nowrap'>
            <div className='text-xs opacity-50'>Телефон</div>
            <div className='group-hover:text-gold'>
              {!!user?.counterparty.phone_1 &&
                formatPhone(user.counterparty.phone_1)}
            </div>
          </div>
          <ArrowDown
            className={twJoin(
              edit === 'phone' && '-rotate-180',
              'min-w-[14px] duration-200',
            )}
          />
        </div>
        {edit === 'phone' && (
          <EditPhone
            user={user}
            token={token}
            mutate={mutate}
            close={() => {
              setEdit(undefined);
            }}
          />
        )}
        <div
          className='group flex min-h-[45px] cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
          onClick={() => {
            setEdit(prev => (prev === 'address' ? undefined : 'address'));
          }}
        >
          <Delivery className='min-w-6 text-gold' width={24} />
          <div className='flex-grow overflow-hidden'>
            <div className='text-xs opacity-50'>Адрес доставки</div>
            <div className='overflow-hidden text-ellipsis whitespace-nowrap group-hover:text-gold'>
              {user?.counterparty.address ?? 'г Москва'}
            </div>
          </div>
          <ArrowDown
            className={twJoin(
              edit === 'address' && '-rotate-180',
              'min-w-[14px] duration-200',
            )}
          />
        </div>
        {edit === 'address' && (
          <EditAddress
            user={user}
            token={token}
            mutate={mutate}
            close={() => {
              setEdit(undefined);
            }}
          />
        )}
        <div
          className='group flex min-h-[45px] cursor-pointer items-center gap-x-[10px] text-sm font-medium leading-[22px]'
          onClick={() => {
            setEdit(prev => (prev === 'email' ? undefined : 'email'));
          }}
        >
          <Email className='min-w-6 text-gold' />
          <div className='flex-grow overflow-hidden'>
            <div className='text-xs opacity-50'>Email</div>
            <div className='overflow-hidden text-ellipsis whitespace-nowrap group-hover:text-gold'>
              {user?.counterparty.email ?? ''}
            </div>
          </div>
          <ArrowDown
            className={twJoin(
              edit === 'email' && '-rotate-180',
              'min-w-[14px] duration-200',
            )}
          />
        </div>
        {edit === 'email' && (
          <EditEmail
            user={user}
            token={token}
            mutate={mutate}
            close={() => {
              setEdit(undefined);
            }}
          />
        )}
      </div>
    </>
  );
}
