'use client';

import { useState } from 'react';
import Image from 'next/image';
import { twJoin } from 'tailwind-merge';

import { Button } from '@/ui/components';
import { ArrowRight, Close } from '@/ui/components/Icons';

import { AuthGuard } from '../../auth';
import { useUser } from '../context';
import { ThemeChanger } from '../theme/ThemeChanger';
import { Favorites } from './Favorites';
import { Orders } from './Orders';
import { ProfileMenu } from './ProfileMenu';
import { User } from './User';

export function Profile() {
  const { userIsFilled } = useUser();
  const [opened, setOpened] = useState(false);
  const [showGuard, setShowGuard] = useState(false);

  return (
    <>
      <AuthGuard
        hidden={!showGuard && !userIsFilled}
        onGoBack={() => {
          setShowGuard(false);
        }}
      />
      <div className='flex h-[30px] w-[30px] cursor-pointer items-center justify-center md:h-[42px] md:w-[42px]'>
        <Image
          src='/avatar_default.jpg'
          width={42}
          height={42}
          alt='Артём Полищук'
          className='overflow-hidden rounded object-cover hover:scale-100 md:scale-90'
          onClick={() => {
            setOpened(true);
          }}
        />
      </div>
      {opened && (
        <div
          className='fixed inset-0 z-40'
          onClick={() => {
            setOpened(false);
          }}
        />
      )}
      <div
        className={twJoin(
          'fixed bottom-0 top-0 z-40 w-[360px] overflow-hidden overflow-y-auto bg-white text-foreground duration-300 ease-in-out dark:bg-contrast dark:text-white',
          opened ? 'right-0' : '-right-full',
        )}
      >
        <div className='py-4'>
          <div className='flex items-center justify-between px-[25px] py-[11px]'>
            <div className='text-sm'>Профиль</div>
            <button
              type='button'
              onClick={() => {
                setOpened(false);
              }}
            >
              <Close />
            </button>
          </div>
          {!userIsFilled && (
            <div className='px-[25px] py-4'>
              <Button
                onClick={() => {
                  setShowGuard(true);
                }}
                className='w-full py-[10px]'
              >
                Войдите в профиль <ArrowRight />
              </Button>
            </div>
          )}
          {userIsFilled && (
            <>
              <User menuIsOpened={opened} />
              <Favorites
                onClick={() => {
                  setOpened(false);
                }}
              />
              <Orders
                onClick={() => {
                  setOpened(false);
                }}
              />
            </>
          )}
          <ProfileMenu />
        </div>
        <div className='absolute bottom-4 right-4 z-50'>
          <ThemeChanger />
        </div>
      </div>
    </>
  );
}
