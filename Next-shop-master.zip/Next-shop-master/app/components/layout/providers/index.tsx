'use client';

import type { ReactNode } from 'react';

import { ThemeProvider } from 'next-themes';

import { FiltersProvider, ShopProvider, UserProvider } from '../context';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider
      attribute={'class'}
      defaultTheme='system'
      disableTransitionOnChange
    >
      <UserProvider>
        <ShopProvider>
          <FiltersProvider>{children}</FiltersProvider>
        </ShopProvider>
      </UserProvider>
    </ThemeProvider>
  );
}
