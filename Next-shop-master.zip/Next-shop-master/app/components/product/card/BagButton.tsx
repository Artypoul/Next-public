import type { MouseEventHandler } from 'react';

import { Bag } from '@/ui/components/Icons';

export function BagButton({
  onClick = () => {},
}: {
  onClick?: MouseEventHandler<HTMLButtonElement>;
}) {
  return (
    <button
      type='button'
      className='ml-2 mt-2 flex h-[42px] w-[42px] items-center justify-center rounded-full bg-black text-white duration-300 hover:bg-gold'
      onClick={onClick}
    >
      <Bag />
    </button>
  );
}
