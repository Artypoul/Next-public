import { twJoin } from 'tailwind-merge';

import { Heart } from '@/ui/components/Icons';

type FavoriteProps = {
  isActive?: boolean;
  onClick?: () => void;
};

export function Favorite({
  isActive = false,
  onClick = () => {},
}: FavoriteProps) {
  return (
    <button
      type='button'
      className={twJoin(
        'absolute right-[18px] top-[18px] z-10 flex h-8 w-8 items-center justify-center',
        'scale-100 duration-300 hover:scale-75',
        isActive
          ? 'stroke-gold text-gold'
          : 'stroke-black text-transparent hover:text-black',
      )}
      onClick={e => {
        e.preventDefault();
        onClick();
      }}
    >
      <Heart />
    </button>
  );
}
