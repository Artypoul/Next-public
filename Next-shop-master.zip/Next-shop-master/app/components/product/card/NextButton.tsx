import { ButtonHTMLAttributes } from 'react';
import { twMerge } from 'tailwind-merge';

import { ArrowRight } from '@/ui/components/Icons';

export function NextButton({
  className = 'next',
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type='button'
      className={twMerge(
        'absolute right-0 top-1/2 z-10 flex h-[42px] w-[42px] -translate-y-1/2 translate-x-14 items-center justify-center text-black/50 duration-300 hover:bg-input-bg hover:text-black group-hover/gallery:translate-x-0',
        className,
      )}
    >
      <ArrowRight />
    </button>
  );
}
