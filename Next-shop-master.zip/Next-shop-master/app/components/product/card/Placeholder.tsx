import { Shimmer } from '@/ui/components/Shimmer';

export function Placeholder() {
  return (
    <div>
      <div className='relative aspect-square overflow-hidden'>
        <Shimmer />
      </div>
      <div className='relative mt-4 inline-block overflow-hidden text-xs font-semibold uppercase leading-[132%]'>
        <span className='invisible'>long product name to shimm</span>
        <Shimmer />
      </div>
      <div className='mt-[5px]'>
        <div className='relative inline-block overflow-hidden text-lg font-bold uppercase leading-[132%]'>
          <span className='invisible'>brand name to shimm</span>
          <Shimmer />
        </div>
        <div />
        <span className='relative mt-3 inline-block overflow-hidden text-lg font-bold leading-[132%]'>
          <span className='invisible'>price</span>
          <Shimmer />
        </span>
      </div>
    </div>
  );
}
