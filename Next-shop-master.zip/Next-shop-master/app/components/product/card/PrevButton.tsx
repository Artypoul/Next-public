import { ButtonHTMLAttributes } from 'react';
import { twMerge } from 'tailwind-merge';

import { ArrowLeft } from '@/ui/components/Icons';

export function PrevButton({
  className = 'prev',
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type='button'
      className={twMerge(
        'absolute left-0 top-1/2 z-10 flex h-[42px] w-[42px] -translate-x-14 -translate-y-1/2 items-center justify-center text-black/50 duration-300 hover:bg-input-bg hover:text-black group-hover/gallery:translate-x-0',
        className,
      )}
    >
      <ArrowLeft />
    </button>
  );
}
