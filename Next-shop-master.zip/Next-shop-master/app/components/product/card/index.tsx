'use client';

import type { Product } from '@/lib/gigma/types';

import { Navigation, Pagination } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';

import { getDiscount, money } from '@/lib/utils';
import { Quantity } from '@/ui/components/Quantity';

import { useShop } from '../../layout/context';
import { BagButton } from './BagButton';
import { Favorite } from './Favorite';
import { NextButton } from './NextButton';
import { PrevButton } from './PrevButton';

type CardProps = {
  product: Product;
  count?: number;
  onToggleFavorite?: (product: Product) => void;
  onBagClick?: (product: Product, quantity: number) => void;
};

export function Card({ product, onBagClick = () => {} }: CardProps) {
  const {
    isFavorite,
    toggleFavorite,
    getCount,
    increaseProduct,
    decreaseProduct,
  } = useShop();

  const count = getCount(product);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const { photo, name, price, brand, quantity: maxCount, discount } = product;

  const isActive = isFavorite(product);

  return (
    <div
      className='group/product w-full overflow-hidden'
      data-product={product.id}
    >
      <Link href={`/product/${product.id}`}>
        <div className='group/gallery relative'>
          <Favorite
            isActive={isActive}
            onClick={() => {
              toggleFavorite(product);
            }}
          />
          <Swiper
            spaceBetween={0}
            modules={[Navigation, Pagination]}
            navigation={{
              nextEl: '.next',
              prevEl: '.prev',
            }}
            pagination={{
              clickable: true,
            }}
            loop
            className='aspect-square'
          >
            <SwiperSlide className='relative aspect-square w-full max-w-full overflow-hidden'>
              <Image
                src={photo}
                className='pointer-events-none aspect-square w-full object-cover'
                fill
                alt={name}
              />
            </SwiperSlide>{' '}
            <SwiperSlide className='relative aspect-square w-full max-w-full overflow-hidden'>
              <Image
                src={photo}
                className='pointer-events-none aspect-square w-full object-cover'
                fill
                alt={name}
              />
            </SwiperSlide>
            <PrevButton />
            <NextButton />
          </Swiper>
        </div>
      </Link>
      <div className='mt-4 overflow-hidden text-ellipsis text-nowrap text-xs font-semibold uppercase leading-[132%] tracking-[0.04em] text-black/50 dark:text-white/70'>
        {name}
      </div>
      <div className='flex'>
        <div className='mt-[5px] flex flex-grow flex-col gap-3 overflow-hidden'>
          <div className='overflow-hidden text-ellipsis text-nowrap text-lg font-bold uppercase leading-[132%]'>
            {brand?.name ?? ''}
          </div>
          <div className='flex items-end gap-3'>
            <span className='text-lg font-bold leading-[132%]'>
              {money(parseFloat(price ?? 0))}
            </span>
            {!!discount &&
              !!parseFloat(discount) &&
              price &&
              !!parseFloat(price) && (
                <span className='text-sm font-light leading-[132%] line-through'>
                  {money(getDiscount({ price, percent: discount }))}
                </span>
              )}
          </div>
        </div>
        <div className='relative flex translate-x-[50px] duration-300 group-hover/product:translate-x-0'>
          {isClient && (
            <Quantity
              quantity={count}
              maxCount={maxCount}
              onDecrease={() => decreaseProduct(product)}
              onIncrease={() => increaseProduct(product)}
            />
          )}
          <Link
            href='/card'
            onClick={() => {
              if (!count) increaseProduct(product);
              onBagClick(product, count);
            }}
          >
            <BagButton />
          </Link>
        </div>
      </div>
    </div>
  );
}
