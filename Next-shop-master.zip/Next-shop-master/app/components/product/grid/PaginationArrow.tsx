import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { ArrowLeft, ArrowRight } from '@/ui/components/Icons';

type PaginationArrowProps = {
  href: string;
  direction: 'left' | 'right';
  isDisabled?: boolean;
};

export function PaginationArrow({
  href,
  direction,
  isDisabled,
}: PaginationArrowProps) {
  const className = twJoin(
    'flex h-[42px] w-[42px] items-center justify-center text-black/50 duration-300 hover:bg-input-bg dark:text-white/50 dark:hover:bg-foreground',
    !isDisabled && 'hover:text-black dark:hover:text-white',
    isDisabled && 'pointer-events-none',
  );

  const icon = direction === 'left' ? <ArrowLeft /> : <ArrowRight />;

  return isDisabled ? (
    <div className={className}>{icon}</div>
  ) : (
    <Link className={className} href={href}>
      {icon}
    </Link>
  );
}
