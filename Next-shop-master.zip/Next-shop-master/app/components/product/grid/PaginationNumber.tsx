import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

type PaginationNumberProps = {
  page: number | string;
  href: string;
  position?: 'first' | 'last' | 'middle' | 'single';
  isActive: boolean;
};

export function PaginationNumber({
  page,
  href,
  isActive,
  position,
}: PaginationNumberProps) {
  const className = twJoin(
    'flex h-[42px] w-[42px] items-center justify-center duration-300 hover:bg-input-bg dark:bg-contrast dark:hover:bg-foreground',
    !isActive && 'text-black/50 dark:text-white/50',
    isActive && 'text-black dark:text-white',
  );

  return isActive || position === 'middle' ? (
    <div className={className}>{page}</div>
  ) : (
    <Link href={href} className={className}>
      {page}
    </Link>
  );
}
