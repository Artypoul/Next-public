import { Placeholder } from '../card/Placeholder';

export function ProductsSkeleton() {
  return (
    <div className='grid grid-cols-1 gap-x-6 gap-y-[10px] md:grid-cols-3 lg:grid-cols-4'>
      <Placeholder />
      <Placeholder />
      <Placeholder />
      <Placeholder />
      <Placeholder />
      <Placeholder />
      <Placeholder />
      <Placeholder />
    </div>
  );
}
