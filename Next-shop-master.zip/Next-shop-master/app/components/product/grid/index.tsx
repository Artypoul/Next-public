import type { GetProductsRequest } from '@/lib/gigma/types';

import { getProducts } from '@/lib/gigma';

import { Card } from '../card';
import { Pagination } from './Pagination';

export default async function Products({
  query,
  page,
  orderBy,
  brand,
  category,
  hidePagination = false,
}: GetProductsRequest & { hidePagination?: boolean }) {
  const res = await getProducts({
    query,
    page,
    orderBy,
    perPage: 8,
    brand,
    category,
  });

  const { data, total } = res?.products ?? {
    data: [],
    total: 0,
  };

  const showPagination =
    !hidePagination && !!data.length && data.length < total;

  if (query && !data?.length) {
    return (
      <div className='mt-6 text-center'>
        По запросу «<span className='font-semibold'>{query}</span>» ничего не
        найдено!
      </div>
    );
  }

  if (!data?.length) {
    return <div className='mt-6 text-center'>Ничего не найдено!</div>;
  }

  return (
    <>
      <div className='grid grid-cols-1 gap-x-6 gap-y-[10px] md:grid-cols-3 lg:grid-cols-4'>
        {data.map((product, index) => {
          return <Card key={index} product={product} />;
        })}
      </div>
      {showPagination && <Pagination totalPages={total} />}
    </>
  );
}
