'use client';

import { Autoplay, Navigation, Pagination } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';

import type { ContentBlock } from '@/lib/gigma/types';

import { NextButton } from './NextButton';
import { PrevButton } from './PrevButton';
import { Slide } from './Slide';

export type SlideProps = {
  img?: ContentBlock;
  bg?: ContentBlock;
  header?: string;
  description?: string;
  link?: ContentBlock;
};

type SlidesProps = {
  slides: SlideProps[];
};

export function Carousel({ slides }: SlidesProps) {
  return (
    <div className='w-full bg-input-bg lg:my-[50px]'>
      <Swiper
        slidesPerView={1}
        spaceBetween={0}
        modules={[Navigation, Pagination, Autoplay]}
        navigation={{
          nextEl: '.nextSlide',
          prevEl: '.prevSlide',
        }}
        pagination={{
          clickable: true,
        }}
        loop
        //autoplay={{ delay: 10000 }}
      >
        {slides.map((slide, index) => (
          <SwiperSlide key={index} className='!w-full'>
            <Slide data={slide} />
          </SwiperSlide>
        ))}
        <PrevButton className='prevSlide' />
        <NextButton className='nextSlide' />
      </Swiper>
    </div>
  );
}
