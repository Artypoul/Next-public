import { ButtonHTMLAttributes } from 'react';
import { twMerge } from 'tailwind-merge';

import { ArrowLeft } from '@/ui/components/Icons';

export function PrevButton({
  className = 'prev',
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type='button'
      className={twMerge(
        'absolute left-[20px] top-1/2 z-10 hidden h-[42px] w-[42px] -translate-y-1/2 items-center justify-center text-black/50 duration-300 hover:bg-input-bg hover:text-black lg:flex',
        className,
      )}
    >
      <ArrowLeft />
    </button>
  );
}
