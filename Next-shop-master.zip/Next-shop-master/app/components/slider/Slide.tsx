import type { CSSProperties } from 'react';
import type { SlideProps } from './Carousel';

import { getImageProps } from 'next/image';
import Link from 'next/link';

import { ArrowRight } from '@/ui/components/Icons';

function getBackgroundImage(srcSet = '') {
  const imageSet = srcSet
    .split(', ')
    .map(str => {
      const [url, dpi] = str.split(' ');
      return `url("${url}") ${dpi}`;
    })
    .join(', ');
  return `image-set(${imageSet})`;
}

export function Slide({ data }: { data: SlideProps }) {
  const { img, link, header, description, bg } = data;

  const src = img?.file?.path;
  if (!src) return null;

  const bgSrc = bg?.file?.path;
  let bgStyle: CSSProperties = {};
  if (bgSrc) {
    const {
      props: { srcSet },
    } = getImageProps({ alt: '', width: 1512, height: 600, src: bgSrc });

    if (srcSet) {
      bgStyle = {
        backgroundImage: getBackgroundImage(srcSet),
      };
    }
  }

  const {
    props: { srcSet },
  } = getImageProps({ alt: '', width: 1512, height: 600, src });

  const mainImage = getBackgroundImage(srcSet);

  return (
    <div
      className='hideBgOnMobile relative grid grid-cols-1 gap-2.5 bg-center bg-no-repeat lg:h-[600px] lg:grid-cols-2 lg:bg-cover lg:px-16'
      style={bgStyle}
    >
      <div className='order-2 flex flex-col items-start justify-center gap-6 px-4 py-10 lg:order-1'>
        {!!header && (
          <div className='text-lg font-bold leading-[130%] text-black lg:text-4xl'>
            {header}
          </div>
        )}
        {!!description && (
          <div className='text-xs text-black lg:text-base'>{description}</div>
        )}
        {!!link?.link && (
          <Link
            href={link.link}
            className='relative z-0 flex items-center gap-[10px] overflow-hidden rounded bg-black px-4 py-[10px] text-sm font-medium leading-6 text-white before:absolute before:inset-0 before:-z-10 before:translate-y-full before:bg-gold before:duration-300 before:content-[""] hover:before:translate-y-0'
          >
            {link.name ?? 'Подробнее'} <ArrowRight />
          </Link>
        )}
      </div>
      <div
        className='order-1 aspect-[4/3] lg:order-2 lg:aspect-auto lg:h-[600px]'
        style={{
          backgroundImage: mainImage,
          backgroundRepeat: 'no-repeat',
          backgroundSize: 'contain',
          backgroundPosition: 'center',
        }}
      ></div>
    </div>
  );
}
