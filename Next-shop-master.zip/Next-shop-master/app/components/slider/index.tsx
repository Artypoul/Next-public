import type { SlideProps } from './Carousel';

import { getSliderContent } from '@/lib/gigma';
import { BlockTypeId } from '@/lib/gigma/types';

import { Carousel } from './Carousel';

export default async function Slider() {
  const res = await getSliderContent();

  if (!res || !res?.children?.length) return null;

  const slides = res.children.reduce<SlideProps[]>((acc, slide) => {
    const img = slide?.children?.find(
      item =>
        item.block_type?.id === BlockTypeId.Image &&
        item.identifier === 'image',
    );
    const header = slide?.children?.find(
      item =>
        item.block_type?.id === BlockTypeId.Text &&
        item.identifier === 'header',
    );
    const description = slide?.children?.find(
      item =>
        item.block_type?.id === BlockTypeId.Text &&
        item.identifier === 'description',
    );
    const link = slide?.children?.find(
      item => item.block_type?.id === BlockTypeId.Link,
    );

    const bg = slide?.children?.find(
      item =>
        item.block_type?.id === BlockTypeId.Image &&
        item.identifier === 'background',
    );

    if (img?.file?.path) {
      acc.push({
        img,
        header: header?.text ?? '',
        description: description?.text ?? '',
        link,
        bg,
      });
    }

    return acc;
  }, []);

  return <Carousel slides={slides} />;
}
