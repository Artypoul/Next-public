'use client';

// Error boundaries must be Client Components
import { useEffect } from 'react';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <div className='flex flex-grow items-center justify-center p-4'>
      <div className='text-center'>
        <h2>500</h2>
        <p>Страница не найдена</p>
        <button
          type='button'
          onClick={
            // Attempt to recover by trying to re-render the segment
            () => reset()
          }
        >
          Отправить запрос повторно
        </button>
      </div>
    </div>
  );
}
