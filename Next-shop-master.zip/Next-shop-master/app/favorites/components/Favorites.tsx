'use client';

import useSWR from 'swr';

import { useUser } from '@/app/components/layout/context';
import { Card } from '@/app/components/product/card';
import { Pagination } from '@/app/components/product/grid/Pagination';
import { ProductsSkeleton } from '@/app/components/product/grid/ProductsSkeleton';
import { getFavorites } from '@/lib/gigma';
import { GetFavoritesRequest, GetFavoritesResponse } from '@/lib/gigma/types';

export function Favorites({
  perPage = 10000,
  page = 1,
}: Pick<GetFavoritesRequest, 'page' | 'perPage'>) {
  const { token } = useUser();
  const { data, isLoading } = useSWR<
    GetFavoritesResponse | undefined,
    Error,
    [number, string] | null
  >(
    token ? [perPage, token] : null,
    ([perPage, token]) => getFavorites({ page, perPage, token }),
    {
      shouldRetryOnError: true,
    },
  );

  const products = data?.products?.data ?? [];
  const total = data?.products?.total ?? 0;

  const showPagination = !!total && products?.length > total;

  if (isLoading) return <ProductsSkeleton />;

  return (
    <>
      <div className='grid grid-cols-1 gap-x-6 gap-y-[10px] md:grid-cols-3 lg:grid-cols-4'>
        {products.map((product, index) => {
          return <Card key={index} product={product} />;
        })}
        {!products.length && <div>Нет товаров в избранном</div>}
      </div>
      {showPagination && <Pagination totalPages={total} />}
    </>
  );
}
