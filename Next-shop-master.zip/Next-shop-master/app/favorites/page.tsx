import type { Metadata } from 'next';

import { GetFavoritesRequest } from '@/lib/gigma/types';

import { AuthGuard } from '../components/auth';
import { Container } from '../components/layout/container';
import { Favorites } from './components/Favorites';

export const metadata: Metadata = {
  title: 'Seimoment Shop',
  description: 'Избранное',
};

type Props = {
  searchParams?: Promise<Pick<GetFavoritesRequest, 'page' | 'perPage'>>;
};

export default async function FavoritesProducts(props: Props) {
  const searchParams = await props.searchParams;
  const page = Number(searchParams?.page) || 1;
  const perPage = Number(searchParams?.perPage) || 1000;

  return (
    <AuthGuard>
      <main className='pb-10'>
        <Container>
          <div className='py-5 text-lg font-bold leading-[22px] hover:text-gold lg:py-[44px] lg:text-[40px]'>
            Избранное
          </div>
          <Favorites page={page} perPage={perPage} />
        </Container>
      </main>
    </AuthGuard>
  );
}
