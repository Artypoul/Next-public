import type { Metadata } from 'next';

import { Suspense } from 'react';
import { Manrope } from 'next/font/google';

import './globals.css';

import { CookieConsient } from './components/layout/cookie';
import Header from './components/layout/header';
import Navbar from './components/layout/navbar';
import { Providers } from './components/layout/providers';
import Loader from './components/Loader';

const manrope = Manrope({
  subsets: ['latin', 'cyrillic'],
  weight: ['400', '500', '600', '700'],
});

const shopName = process.env.NEXT_PUBLIC_SHOP_NAME ?? 'Next';

export const metadata: Metadata = {
  title: `${shopName} Shop`,
  description: 'Powered by Gitsite',
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang='ru' suppressHydrationWarning>
      <body className={`${manrope.className} antialiased`}>
        <Loader />
        <Providers>
          <div className='clear-both'>
            <Navbar />
            <Suspense>
              <div className='flex flex-col'>
                <Header />
                {children}
              </div>
            </Suspense>
          </div>
        </Providers>
        <CookieConsient />
      </body>
    </html>
  );
}
