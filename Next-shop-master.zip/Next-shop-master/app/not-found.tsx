import Link from 'next/link';

export default function NotFound() {
  return (
    <div className='flex flex-grow items-center justify-center p-4'>
      <div className='text-center'>
        <h2>404</h2>
        <p>Страница не найдена</p>
        <Link href='/'>На главную</Link>
      </div>
    </div>
  );
}
