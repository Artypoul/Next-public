'use client';

import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';

import { money } from '@/lib/utils';
import { ChevronLeft, Delivery, Form } from '@/ui/components/Icons';

import { OrdersProps } from '../page';

export function OrdersDesktop({ orders }: OrdersProps) {
  const router = useRouter();
  return (
    <>
      <button
        type='button'
        className='flex items-center gap-2 px-2 py-[6px]'
        onClick={() => {
          router.back();
        }}
      >
        <ChevronLeft />
        Назад
      </button>
      <div className='mt-3 flex flex-col gap-6 rounded bg-white dark:bg-contrast'>
        <div className='px-4 pb-0 pt-4 md:px-6 md:pt-6'>
          <div className='text-lg font-bold leading-[132%]'>Заказы</div>
        </div>
        <div className='overflow-hidden overflow-x-auto'>
          <table className='w-full'>
            <tbody>
              {orders.map(order => {
                const productWithPhoto = order.products.find(
                  item => !!item?.photos.some(p => !!p.path),
                );
                const firstPhoto =
                  productWithPhoto &&
                  productWithPhoto.photos.find(item => item.path);

                return (
                  <tr key={order.id}>
                    <td className='w-[100px] px-11'>
                      {order.status.id === 1 ? <Delivery /> : <Form />}
                    </td>
                    <td className='p-4'>
                      <div className='flex items-center gap-4'>
                        {firstPhoto && (
                          <Image
                            className='pointer-events-none aspect-square overflow-hidden rounded-lg object-cover'
                            src={firstPhoto.path}
                            alt={order.status.name}
                            width={64}
                            height={64}
                          />
                        )}
                        {!firstPhoto && (
                          <div className='h-16 w-16 bg-auth-bg-light' />
                        )}
                        <div className='text-sm font-medium leading-[22px]'>
                          <div>Заказ №{order.id}</div>
                          <div className='whitespace-nowrap opacity-50'>
                            {order.status.name}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className='w-[100px] p-4 text-sm font-semibold leading-[22px]'>
                      {money(parseFloat(order.price ?? '0'))}
                    </td>
                    <td className='w-[100px] p-4 text-sm leading-[22px]'>
                      {format(order.created_at, 'dd.MM.yy')}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
