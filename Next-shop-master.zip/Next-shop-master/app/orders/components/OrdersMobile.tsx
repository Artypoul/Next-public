'use client';

import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';

import { money } from '@/lib/utils';
import { ChevronLeft } from '@/ui/components/Icons';

import { OrdersProps } from '../page';

export function OrdersMobile({ orders }: OrdersProps) {
  const router = useRouter();
  return (
    <>
      <button
        type='button'
        className='flex items-center gap-2 px-2 py-[6px]'
        onClick={() => {
          router.back();
        }}
      >
        <ChevronLeft />
        Назад
      </button>
      <div className='mt-3 flex flex-col gap-6 rounded bg-white dark:bg-contrast'>
        <div className='px-4 pb-0 pt-4 md:px-6 md:pt-6'>
          <div className='text-lg font-bold leading-[132%]'>Заказы</div>
        </div>
        {orders.map(order => {
          const productWithPhoto = order.products.find(
            item => !!item?.photos.some(p => !!p.path),
          );
          const firstPhoto =
            productWithPhoto && productWithPhoto.photos.find(item => item.path);

          return (
            <div key={order.id} className='p-4'>
              <div className='flex items-center gap-4'>
                <div className='h-16 w-16 min-w-16'>
                  {firstPhoto && (
                    <Image
                      className='pointer-events-none aspect-square overflow-hidden rounded-lg object-cover'
                      src={firstPhoto.path}
                      alt={order.status.name}
                      width={64}
                      height={64}
                    />
                  )}
                  {!firstPhoto && (
                    <div className='h-16 w-16 min-w-16 bg-auth-bg-light' />
                  )}
                </div>
                <div className='flex-grow text-sm font-medium leading-[22px]'>
                  <div>Заказ №{order.id}</div>

                  <div className='whitespace-nowrap opacity-50'>
                    {order.status.name}
                  </div>
                </div>
                <div className='p-4 text-sm leading-[22px]'>
                  {format(order.created_at, 'dd.MM.yy')}
                  <div className='text-sm font-semibold leading-[22px]'>
                    {money(parseFloat(order.price ?? '0'))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}
