'use client';

import { useCallback, useEffect, useState } from 'react';

import { useTailwindBreakpoint } from '@/hooks/useTailwindBreakpoint';
import { getOrders } from '@/lib/gigma';
import { OrderData } from '@/lib/gigma/types';

import { AuthGuard } from '../components/auth';
import { Container } from '../components/layout/container';
import { useUser } from '../components/layout/context';
import { OrdersDesktop } from './components/OrdersDesktop';
import { OrdersMobile } from './components/OrdersMobile';

export type OrdersProps = {
  orders: OrderData[];
};

export default function Orders() {
  const [orders, setOrders] = useState<OrderData[]>([]);
  const { token } = useUser();

  const { up } = useTailwindBreakpoint();
  const isDesktop = up('sm');

  const getOrdersData = useCallback(async () => {
    const ordersResult = await getOrders(token);
    if (ordersResult) setOrders(ordersResult.orders);
  }, [token]);

  useEffect(() => {
    getOrdersData();
  }, [getOrdersData]);

  return (
    <AuthGuard>
      <main className='flex-grow bg-auth-bg-light pb-[136px] pt-[50px]'>
        <Container>
          {isDesktop && <OrdersDesktop orders={orders} />}
          {!isDesktop && <OrdersMobile orders={orders} />}
        </Container>
      </main>
    </AuthGuard>
  );
}
