import { Suspense } from 'react';

import Brands from './components/brands';
import { Container } from './components/layout/container';
import Products from './components/product/grid';
import { ProductsSkeleton } from './components/product/grid/ProductsSkeleton';
import Slider from './components/slider';

export default async function Home() {
  return (
    <main className='pb-10'>
      <Container className='flex flex-row justify-between'>
        <Suspense>
          <Slider />
        </Suspense>
      </Container>
      <Brands />
      <Container>
        <div className='py-5 text-lg font-bold leading-[22px] hover:text-gold lg:py-[44px] lg:text-[40px]'>
          Рекомендуемые товары
        </div>
        <Suspense key='recommended' fallback={<ProductsSkeleton />}>
          <Products
            perPage={8}
            page={1}
            orderBy='popularity_desc'
            hidePagination
          />
        </Suspense>
      </Container>
    </main>
  );
}
