import { Suspense } from 'react';
import { notFound } from 'next/navigation';

import { Container } from '@/app/components/layout/container';
import { getPrivacyPolicyContent } from '@/lib/gigma';

export default async function Policy() {
  const res = await getPrivacyPolicyContent();
  if (!res) {
    notFound();
  }

  const { text } = res;

  return (
    <main className='pb-10'>
      <Container>
        <Suspense>
          <div
            className='rich-text'
            dangerouslySetInnerHTML={{ __html: text ?? '' }}
          />
        </Suspense>
      </Container>
    </main>
  );
}
