'use client';

import type { SingleProduct } from '@/lib/gigma/types';
import type { Review } from './Reviews';

import { useState } from 'react';
import { twJoin } from 'tailwind-merge';

import { Reviews } from './Reviews';

const review: Review = {
  date: new Date(2024, 5, 20),
  name: 'Александр К.',
  rating: 5,
  text: 'Недавно приобрёл комплект пастельного белья, и он превзошёл все ожидания! 🌸 Мягкая, приятная на ощупь ткань создаёт ощущение уюта и комфорта, а нежные оттенки придают спальне особую атмосферу.',
};

const reviews = [review, review, review, review];

export function Content({ product }: { product: SingleProduct }) {
  const [show, setShow] = useState<'description' | 'reviews'>('description');

  const { description } = product;
  return (
    <div>
      <div className='flex gap-3'>
        <button
          type='button'
          className={twJoin(
            'flex h-[60px] w-[88px] items-center justify-center',
            show === 'description'
              ? 'border-b border-black dark:border-white'
              : 'text-black/50 dark:text-white/50',
          )}
          onClick={() => {
            setShow('description');
          }}
        >
          Описание
        </button>
        <button
          type='button'
          className={twJoin(
            'px-2 py-1',
            show === 'reviews'
              ? 'border-b border-black dark:border-white'
              : 'text-black/50 dark:text-white/50',
          )}
          onClick={() => {
            setShow('reviews');
          }}
        >
          Отзывы({reviews?.length ?? 0})
        </button>
      </div>
      {show === 'description' && (
        <>
          {!!description && (
            <div
              dangerouslySetInnerHTML={{ __html: description }}
              className='rich-text mt-8'
            />
          )}
        </>
      )}
      {show === 'reviews' && <Reviews reviews={reviews} />}
    </div>
  );
}
