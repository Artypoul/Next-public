'use client';

import type { SingleProduct } from '@/lib/gigma/types';
import type { MouseEvent } from 'react';

import { useMemo, useRef, useState } from 'react';
import Image from 'next/image';
import { Navigation } from 'swiper/modules';
import { Swiper, SwiperSlide } from 'swiper/react';

import 'swiper/css';

import { Thumbs } from './Thumbs';

export function Gallery({ product }: { product: SingleProduct }) {
  const { photos } = product;
  const [position, setPosition] = useState({ x: 50, y: 50 });
  const zoomContainerRef = useRef<HTMLDivElement>(null);

  const gallery = useMemo(
    () =>
      photos.filter(
        image =>
          !!image?.path &&
          typeof image.path === 'string' &&
          /\.(gif|jpe?g|tiff?|png|webp|bmp)$/i.test(image.path),
      ),
    [photos],
  );

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!zoomContainerRef.current) return;
    const { left, top, width, height } =
      zoomContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;

    setPosition({ x, y });
  };

  if (!gallery.length)
    return (
      <div className='flex aspect-[900/610] w-full items-center justify-center bg-input-bg'>
        No image
      </div>
    );

  return (
    <div ref={zoomContainerRef}>
      <Swiper
        slidesPerView={1}
        spaceBetween={0}
        className='overflow-hidden rounded'
        wrapperClass='h-full'
        modules={[Navigation]}
        navigation={{
          nextEl: '.nextProductSlide',
          prevEl: '.prevProductSlide',
        }}
        loop
      >
        {gallery.map((slide, index) => {
          const rutubeUrl =
            slide?.link?.includes('rutube.ru') && getRutubeSrc(slide.link);
          return (
            <SwiperSlide
              key={index}
              className='relative aspect-[900/610] h-auto w-full overflow-hidden bg-input-bg'
              onMouseMove={handleMouseMove}
            >
              {rutubeUrl ? (
                <iframe
                  className='relative top-1/2 aspect-video w-full -translate-y-1/2'
                  src={rutubeUrl}
                  allow='clipboard-write; autoplay'
                  allowFullScreen
                ></iframe>
              ) : (
                <Image
                  src={slide.path}
                  alt={slide.name}
                  fill
                  className='scale-1 scale-100 object-contain md:hover:scale-[1.7]'
                  style={{
                    transformOrigin: `${position.x}% ${position.y}%`,
                  }}
                />
              )}
            </SwiperSlide>
          );
        })}

        <Thumbs gallery={gallery} />
      </Swiper>
    </div>
  );
}

function getRutubeSrc(url: string) {
  try {
    const urlParts = url.split('/video/');
    if (urlParts.length > 1) {
      const idPart = urlParts[1];
      const id = idPart?.split('/')[0].split('?')[0].split('#')[0];

      if (!id) return null;

      return `https://rutube.ru/play/embed/${id}`;
    }
  } catch (error) {
    console.error('Error parsing Rutube URL:', error);
  }
  return null;
}
