'use client';

import type { SingleProduct } from '@/lib/gigma/types';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { twJoin } from 'tailwind-merge';

import { useShop } from '@/app/components/layout/context';
import { money } from '@/lib/utils';
import { Button } from '@/ui/components';
import { Bag, Heart } from '@/ui/components/Icons';
import { Quantity } from '@/ui/components/Quantity';

import { Rating } from './Rating';
import { Views } from './Views';

export function Info({ product }: { product: SingleProduct }) {
  const {
    brand,
    name,
    discount,
    specification,
    price,
    old_price,
    quantity: maxCount,
  } = product;
  const {
    isFavorite,
    getCount,
    increaseProduct,
    decreaseProduct,
    toggleFavorite,
  } = useShop();
  const [isClient, setIsClient] = useState(false);

  const count = getCount(product);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const isActive = isFavorite(product);

  return (
    <div className='flex h-full flex-col'>
      <div className='flex-grow'>
        <div className='flex flex-col gap-4'>
          {!!discount && (
            <div>
              <span className='inline-block rounded-md bg-error px-2 py-0.5 text-xs font-bold leading-5 text-error-contrast'>
                Распродажа
              </span>
            </div>
          )}
          <div>
            <div className='mb-2 text-sm font-bold leading-5 text-gold'>
              {brand?.name ?? ''}
            </div>
            <div className='mb-4 text-[30px] font-bold leading-8'>{name}</div>
            <div className='mb-4 flex items-center gap-2'>
              {isClient && (
                <Rating
                  product={product.id}
                  total={200}
                  votes={40}
                  activeStarClassName='text-[#FFAB00]'
                  starClassName='text-[#919EAB]'
                  allowMultipleClicks={false}
                />
              )}
              <Views views={product.views_count} />
            </div>
            <div className='flex items-center gap-2'>
              <span className='text-2xl font-bold leading-[132%]'>
                {money(parseFloat(price ?? 0))}
              </span>
              {!!old_price && (
                <span className='text-lg font-light leading-[132%] line-through'>
                  {money(parseFloat(old_price ?? 0))}
                </span>
              )}
            </div>
            <hr className='my-8 bg-light' />
          </div>
        </div>
        {!!specification && (
          <div
            dangerouslySetInnerHTML={{ __html: specification }}
            className='rich-text [&>p]:leading-6'
          />
        )}
        <div className='flex items-center justify-between'>
          <div>Количество</div>
          {isClient && (
            <Quantity
              quantity={count}
              maxCount={maxCount}
              onDecrease={() => decreaseProduct(product)}
              onIncrease={() => increaseProduct(product)}
            />
          )}
        </div>
        <div className='mt-1 flex items-center justify-end text-xs font-medium leading-6 text-black/50 dark:text-white/50'>
          Доступно: {maxCount}
        </div>
      </div>
      <div className='max-h-[120px] min-h-[120px]'>
        <div className='mt-8 flex items-center gap-2'>
          <Link
            href='/card'
            onClick={() => {
              if (!count) increaseProduct(product);
            }}
          >
            <Button>
              <Bag /> В корзину
            </Button>
          </Link>
          <Button
            className={twJoin(
              '',
              'group',
              isActive
                ? 'stroke-gold text-gold hover:stroke-white hover:text-white'
                : 'stroke-white text-transparent hover:stroke-black hover:text-black',
            )}
            onClick={() => {
              toggleFavorite(product);
            }}
          >
            <Heart className='w-[18px] scale-100 group-hover:scale-110' />
          </Button>
        </div>
      </div>
    </div>
  );
}
