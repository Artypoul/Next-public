'use client';

import type { MouseEvent } from 'react';

import { useCallback, useRef, useState } from 'react';
import { twJoin } from 'tailwind-merge';

import { useLocalStorage } from '@/hooks/useLocalStorage';
import { RatingStar } from '@/ui/components/Icons';

type RatingProps = {
  product: number;
  votes?: number;
  total?: number;
  allowMultipleClicks?: boolean;
  activeStarClassName?: string;
  starClassName?: string;
};

const precision = 1;
const totalStars = 5;

export function Rating({
  product,
  votes = 0,
  total = 0,
  allowMultipleClicks = false,
  activeStarClassName = 'text-yellow-500',
  starClassName = 'text-slate-300',
}: RatingProps) {
  const [productVotes, setProductVotes] = useState(votes);
  const [productTotal, setProductTotal] = useState(total);
  const [userRatings, setUserRatings] = useLocalStorage<
    { product: number; value: number }[]
  >('seimoment-product-votes', []);
  const [userRating, setUserRating] = useState(() => {
    const index = userRatings.findIndex(r => r.product === product);
    return index !== -1 ? userRatings[index].value : null;
  });
  const [activeStar, setActiveStar] = useState(userRating || -1);
  const [hoverActiveStar, setHoverActiveStar] = useState(-1);
  const [isHovered, setIsHovered] = useState(false);

  const ratingContainerRef = useRef<HTMLDivElement>(null);

  const calculateRating = useCallback((e: MouseEvent<HTMLDivElement>) => {
    if (!ratingContainerRef?.current) {
      return 0;
    }

    const { width, left } = ratingContainerRef.current.getBoundingClientRect();
    const percent = (e.clientX - left) / width;
    const numberInStars = percent * totalStars;
    const nearestNumber =
      Math.round((numberInStars + precision / 2) / precision) * precision;

    return Number(
      nearestNumber.toFixed(precision.toString().split('.')[1]?.length || 0),
    );
  }, []);

  const handleClick = useCallback(
    (e: MouseEvent<HTMLDivElement>) => {
      const selected = calculateRating(e);
      const updatedProductVotes = productVotes + 1;
      const updatedProductTotal = productTotal + selected;
      setIsHovered(false);
      setActiveStar(selected);

      if (!allowMultipleClicks) {
        setUserRatings(prev => [
          ...(prev ?? []).filter(item => item.product !== product),
          { product, value: selected },
        ]);
      }

      setUserRating(selected);
      setProductVotes(updatedProductVotes);
      setProductTotal(updatedProductTotal);
      //sendRating(selected);
    },
    [
      product,
      calculateRating,
      productTotal,
      productVotes,
      setUserRatings,
      allowMultipleClicks,
    ],
  );

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (userRating) return;
    setIsHovered(true);
    setHoverActiveStar(calculateRating(e));
  };

  const handleMouseLeave = () => {
    if (userRating) return;
    setHoverActiveStar(-1); // Reset to default state
    setIsHovered(false);
  };

  return (
    <div
      ref={ratingContainerRef}
      className={twJoin(
        'relative inline-flex text-left text-2xl',
        !userRating && 'lg:cursor-pointer',
      )}
      onClick={e => {
        if (!userRating || allowMultipleClicks) {
          handleClick(e);
        }
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {[...new Array(totalStars)].map((_, index) => {
        const activeState = isHovered ? hoverActiveStar : activeStar;

        const showEmptyIcon = activeState === -1 || activeState < index + 1;

        const isActiveRating = activeState !== 1;
        const isRatingWithPrecision = activeState % 1 !== 0;
        const isRatingEqualToIndex = Math.ceil(activeState) === index + 1;
        const showRatingWithPrecision =
          isActiveRating && isRatingWithPrecision && isRatingEqualToIndex;

        return (
          <div
            key={index}
            className={twJoin(
              'relative',
              (!userRating || allowMultipleClicks) && 'lg:cursor-pointer',
            )}
          >
            <div
              style={{
                width: showRatingWithPrecision
                  ? `${(activeState % 1) * 100}%`
                  : '0%',
              }}
              className={twJoin(
                activeStarClassName,
                'absolute overflow-hidden',
                'flex h-5 w-5 items-center justify-center',
              )}
            >
              <RatingStar />
            </div>
            <div
              className={twJoin(
                showEmptyIcon ? starClassName : activeStarClassName,
                'flex h-5 w-5 items-center justify-center',
              )}
            >
              <RatingStar />
            </div>
          </div>
        );
      })}
    </div>
  );
}
