export function ReviewRating({ rating }: { rating: number }) {
  const stars = rating > 5 ? 5 : rating;

  return (
    <div className='flex gap-2'>
      {[...new Array(5)].map((_, index) => {
        return (
          <div key={index}>
            <svg
              width='16'
              height='16'
              viewBox='0 0 16 16'
              fill='none'
              xmlns='http://www.w3.org/2000/svg'
            >
              <path
                d='M7.99967 1.33331L10.0597 5.50665L14.6663 6.17998L11.333 9.42665L12.1197 14.0133L7.99967 11.8466L3.87967 14.0133L4.66634 9.42665L1.33301 6.17998L5.93967 5.50665L7.99967 1.33331Z'
                fill={index <= stars - 1 ? '#E7B66B' : '#919EAB'}
                stroke={index <= stars - 1 ? '#E7B66B' : '#919EAB'}
                strokeWidth='2'
                strokeLinecap='round'
                strokeLinejoin='round'
              />
            </svg>
          </div>
        );
      })}
    </div>
  );
}
