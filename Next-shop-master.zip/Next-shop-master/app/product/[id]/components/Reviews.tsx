import { format } from 'date-fns';
import { ru } from 'date-fns/locale';

import { ReviewRating } from './ReviewRating';

export type Review = {
  date: Date;
  rating: number;
  name: string;
  text: string;
};

export function Reviews({ reviews }: { reviews: Review[] }) {
  const getShortName = (name: string) => {
    const arr = name.split(' ');
    return `${arr[0][0]}${arr?.[1][0] ?? ''}`;
  };

  return (
    <div className='mt-8 flex flex-col gap-8'>
      {reviews.map((rewiew, index) => {
        const shortName = getShortName(rewiew.name);
        return (
          <div key={index} className='flex flex-col gap-3'>
            <div className='text-sm font-semibold leading-5 text-[#858585]'>
              {format(rewiew.date, 'LLLL dd, yyyy', { locale: ru })}
            </div>
            <div className='flex items-center gap-3'>
              <div className='flex h-9 w-9 items-center justify-center rounded-full bg-input-bg text-sm font-semibold leading-5 text-gold'>
                {shortName}
              </div>
              <div>{rewiew.name}</div>
            </div>
            <ReviewRating rating={rewiew.rating} />
            <div>{rewiew.text}</div>
            <hr className='h-[2.15px] bg-[#f8f7f4] dark:opacity-10' />
          </div>
        );
      })}
    </div>
  );
}
