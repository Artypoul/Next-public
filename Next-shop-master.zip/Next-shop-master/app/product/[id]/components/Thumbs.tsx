'use client';

import Image from 'next/image';
import { useSwiper } from 'swiper/react';

import { ProductPhoto } from '@/lib/gigma/types';

export function Thumbs({ gallery }: { gallery: ProductPhoto[] }) {
  const swiper = useSwiper();

  return (
    <div className='mt-[10px] flex gap-4'>
      {gallery.map((thumb, index) => {
        return (
          <div
            key={index}
            className='relative h-[110px] w-[110px] select-none overflow-hidden rounded bg-input-bg hover:opacity-75 lg:cursor-pointer'
            onClick={() => swiper.slideTo(index)}
          >
            <Image
              src={thumb.path}
              alt={thumb.name}
              fill
              className='pointer-events-none object-cover'
            />
          </div>
        );
      })}
    </div>
  );
}
