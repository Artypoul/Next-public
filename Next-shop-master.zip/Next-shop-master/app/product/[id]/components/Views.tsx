import { formatCompactNumber, getNoun } from '@/lib/utils';

export function Views({ views = 0 }: { views?: number }) {
  const noun = getNoun(views, 'просмотр', 'просмотра', 'просмотров');
  return (
    <div className='text-sm leading-5 text-[#637381]'>
      ({formatCompactNumber(views)} {noun})
    </div>
  );
}
