import { notFound } from 'next/navigation';

import { Container } from '@/app/components/layout/container';
import { getProduct, getProducts } from '@/lib/gigma';

import { Content } from './components/Content';
import { Gallery } from './components/Gallery';
import { Info } from './components/Info';

export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const res = await getProduct(id);
  if (!res) {
    notFound();
  }

  const { product } = res;

  return (
    <main className='pb-10'>
      <Container>
        <div className='flex flex-col items-stretch gap-10 py-[50px] xl:flex-row'>
          <div className='xl:min-w-[700px] xl:max-w-[700px] 2xl:min-w-[900px] 2xl:max-w-[900px]'>
            <Gallery product={product} />
          </div>
          <div className='flex-grow'>
            <Info product={product} />
          </div>
        </div>
        <Content product={product} />
      </Container>
    </main>
  );
}

export async function generateStaticParams() {
  const res = await getProducts({});
  if (!res) return [];
  return res.products.data.map(product => ({
    id: product.id.toString(),
  }));
}
