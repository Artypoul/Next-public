'use client';

import { useFilters } from '@/app/components/layout/context';
import { Undo } from '@/ui/components/Icons';

export function SearchHeader() {
  const {
    filters,
    toggleFilter,
    clearFilters,
    priceRange,
    setPriceRangeFilter,
  } = useFilters();

  const {
    brand: selectedBrands,
    category: selectedCategories,
    country: selectedCountries,
    availability: selectedAvailabilities,
  } = filters;

  const singleCategoryName =
    selectedCategories?.length === 1 && selectedCategories[0].name;
  const singleBrandName =
    selectedBrands?.length === 1 && selectedBrands[0].name;

  const title = singleCategoryName || singleBrandName;

  const multiCategories = selectedCategories.map(item => item.name).join(', ');
  const multiBrands = selectedBrands.map(item => item.name).join(', ');
  const multiCountries = selectedCountries.map(item => item.name).join(', ');
  const multiAvailabilities = selectedAvailabilities
    .map(item => item.name)
    .join(', ');
  const pricesSetted = priceRange
    ? `от ${priceRange[0]} ₽ - до ${priceRange[1]} ₽`
    : false;

  const filtersArray: string[] = [];
  if (multiCategories) filtersArray.push(multiCategories);
  if (multiBrands) filtersArray.push(multiBrands);
  if (pricesSetted) filtersArray.push(pricesSetted);
  if (multiCountries) filtersArray.push(multiCountries);
  if (multiAvailabilities) filtersArray.push(multiAvailabilities);

  const showFilters = !!filtersArray.length;
  return (
    <>
      <div className='py-5 lg:py-[44px]'>
        <div className='text-lg font-bold leading-[22px] hover:text-gold lg:text-[40px]'>
          {title || 'Все бренды и категории'}
        </div>
        {showFilters && (
          <div className='mt-5 flex flex-wrap content-start items-start gap-2 self-stretch'>
            {!!multiCategories && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  toggleFilter('category');
                }}
              >
                <Undo />
                Категории: {multiCategories}
              </button>
            )}
            {!!multiBrands && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  toggleFilter('brand');
                }}
              >
                <Undo />
                Бренды: {multiBrands}
              </button>
            )}
            {!!multiCountries && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  toggleFilter('country');
                }}
              >
                <Undo />
                Страны: {multiCountries}
              </button>
            )}
            {!!multiAvailabilities && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  toggleFilter('availability');
                }}
              >
                <Undo />
                Наличие: {multiAvailabilities}
              </button>
            )}
            {!!pricesSetted && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  setPriceRangeFilter(undefined);
                }}
              >
                <Undo />
                Цена: {pricesSetted}
              </button>
            )}
            {filtersArray.length > 1 && (
              <button
                className='flex items-center gap-2 rounded-full bg-tag-bg py-[3px] pl-[3px] pr-3 text-xs leading-[140%] text-white'
                onClick={() => {
                  clearFilters();
                  setPriceRangeFilter(undefined);
                }}
              >
                <Undo />
                Очистить все
              </button>
            )}
          </div>
        )}
      </div>
    </>
  );
}
