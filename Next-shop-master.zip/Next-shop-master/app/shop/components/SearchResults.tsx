'use client';

import type {
  GetProductsRequest,
  GetProductsResponse,
} from '@/lib/gigma/types';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';

import { useShop, useUser } from '@/app/components/layout/context';
import { Card } from '@/app/components/product/card';
import { Pagination } from '@/app/components/product/grid/Pagination';
import { ProductsSkeleton } from '@/app/components/product/grid/ProductsSkeleton';
import { getProducts } from '@/lib/gigma';

import { SearchHeader } from './SearchHeader';

export function SearchResults() {
  const [response, setProductResponse] = useState<GetProductsResponse>();
  const [loading, setLoading] = useState(true);

  const searchParams = useSearchParams();
  const { token } = useUser();
  const { tags } = useShop();

  const query = searchParams.get('query') ?? '';
  const page = Number(searchParams.get('page')) || 1;
  const orderBy = searchParams.get('orderBy') ?? undefined;
  const brand = searchParams.get('brand') ?? undefined;
  const category = searchParams.get('category') ?? undefined;
  const country = searchParams.get('country') ?? undefined;
  const availability = searchParams.get('availability') ?? undefined;

  const priceFrom = searchParams.get('priceFrom') ?? undefined;
  const priceTo = searchParams.get('priceTo') ?? undefined;

  const getData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getProducts({
        query,
        page,
        orderBy: orderBy as GetProductsRequest['orderBy'],
        brand,
        category,
        priceFrom,
        priceTo,
        available: availability,
        country,
        token,
      });

      setProductResponse(res);
    } catch {}

    setLoading(false);
  }, [
    query,
    page,
    orderBy,
    brand,
    category,
    token,
    priceFrom,
    priceTo,
    country,
    availability,
  ]);

  useEffect(() => {
    getData();
  }, [getData]);

  const data = useMemo(() => response?.products?.data ?? [], [response]);
  const total = useMemo(() => response?.products?.total ?? 0, [response]);

  const showPagination = !!data.length && data.length < total;

  return (
    <>
      <div className='flex flex-wrap gap-[10px]'>
        {tags.map((tag, index) => {
          return (
            <div
              key={index}
              className='rounded bg-input-bg/50 px-4 py-[10px] text-xs uppercase leading-6 tracking-[0.12em]'
            >
              {tag.name}
            </div>
          );
        })}
      </div>
      <SearchHeader />
      {loading && <ProductsSkeleton />}
      {!loading && !data.length && (
        <div className='mt-6 text-center'>
          {!!query ? (
            <>
              По запросу «<span className='font-semibold'>{query}</span>» ничего
              не найдено!
            </>
          ) : (
            'Ничего не найдено!'
          )}
        </div>
      )}
      <div className='grid grid-cols-1 gap-x-6 gap-y-[10px] md:grid-cols-3 lg:grid-cols-4'>
        {data.map((product, index) => {
          return <Card key={index} product={product} />;
        })}
      </div>
      {showPagination && <Pagination totalPages={total} />}
    </>
  );
}
