'use client';

import { useEffect, useRef } from 'react';
import Link from 'next/link';

import { useShop } from '@/app/components/layout/context';
import { Button } from '@/ui/components';

export function Success() {
  const { getSelected, removeProducts } = useShop();
  const selected = getSelected();

  const cleanSelected = useRef(false);

  useEffect(() => {
    if (!cleanSelected.current) {
      removeProducts(selected.map(item => item.product.id));
    }

    return () => {
      cleanSelected.current = true;
    };
  }, [selected, removeProducts]);

  return (
    <div className='fixed inset-0 z-[60] flex items-center justify-center bg-auth-bg-light'>
      <div className='w-full max-w-[378px]'>
        <div className='rounded bg-white p-6 text-center text-lg font-bold leading-6 dark:bg-contrast'>
          Заказ успешно оформлен
        </div>
        <Link href='/orders'>
          <Button className='mt-6 w-full'>В заказы</Button>
        </Link>
      </div>
    </div>
  );
}
