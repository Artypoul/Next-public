import { Container } from '../components/layout/container';
import { Success } from './components/Success';

export default async function Page() {
  return (
    <main className='pb-10'>
      <div className='bg-card-bg-light pb-[136px] pt-[50px] dark:bg-black'>
        <Container>
          <Success />
        </Container>
      </div>
    </main>
  );
}
