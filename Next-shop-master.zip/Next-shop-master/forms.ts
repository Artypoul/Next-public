import svgToDataUri from 'mini-svg-data-uri';
import colors from 'tailwindcss/colors';
import defaultTheme from 'tailwindcss/defaultTheme';
import plugin from 'tailwindcss/plugin';

const [baseFontSize, { lineHeight: baseLineHeight }] =
  defaultTheme.fontSize.base;
const { spacing, borderWidth, borderRadius } = defaultTheme;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
interface RecursiveKeyValuePair<K extends keyof any = string, V = string> {
  [key: string]: V | RecursiveKeyValuePair<K, V>;
}
type CSSRuleObject = RecursiveKeyValuePair<string, null | string | string[]>;
type Options = { strategy?: 'base' | 'class' };
type Rule = {
  base: string[];
  class: string[] | null;
  styles: CSSRuleObject;
};

function resolveColor(color: string, opacityVariableName: string) {
  return color.replace('<alpha-value>', `var(${opacityVariableName}, 1)`);
}

const forms = plugin.withOptions<Options>(
  (options = { strategy: undefined }) => {
    return function ({ addBase, addComponents, theme }) {
      const strategy =
        options.strategy === undefined ? ['base', 'class'] : [options.strategy];

      const rules: Rule[] = [
        {
          base: [
            "[type='text']",
            "[type='email']",
            "[type='url']",
            "[type='password']",
            "[type='number']",
            "[type='date']",
            "[type='datetime-local']",
            "[type='month']",
            "[type='search']",
            "[type='tel']",
            "[type='time']",
            "[type='week']",
            '[multiple]',
            'textarea',
            'select',
          ],
          class: [
            '.seimoment-form-input',
            '.seimoment-form-textarea',
            '.seimoment-form-select',
            '.seimoment-form-multiselect',
          ],
          styles: {
            appearance: 'none',
            'background-color': '#fff',
            'border-color': 'transparent',
            'border-width': borderWidth['DEFAULT'],
            'border-radius': borderRadius.none,
            'padding-top': spacing[2],
            'padding-right': spacing[3],
            'padding-bottom': spacing[2],
            'padding-left': spacing[3],
            'font-size': baseFontSize,
            'line-height': baseLineHeight,
            '&:focus': {
              outline: 'none',
            },
          },
        },
        {
          base: ['input::placeholder', 'textarea::placeholder'],
          class: [
            '.seimoment-form-input::placeholder',
            '.seimoment-form-textarea::placeholder',
          ],
          styles: {
            color: theme('colors.input.text'),
            opacity: '1',
          },
        },
        {
          base: ['::-webkit-datetime-edit-fields-wrapper'],
          class: [
            '.seimoment-form-input::-webkit-datetime-edit-fields-wrapper',
          ],
          styles: {
            padding: '0',
          },
        },
        {
          // Unfortunate hack until https://bugs.webkit.org/show_bug.cgi?id=198959 is fixed.
          // This sucks because users can't change line-height with a utility on date inputs now.
          // Reference: https://github.com/twbs/bootstrap/pull/31993
          base: ['::-webkit-date-and-time-value'],
          class: ['.seimoment-form-input::-webkit-date-and-time-value'],
          styles: {
            'min-height': '1.5em',
          },
        },
        {
          // In Safari on iOS date and time inputs are centered instead of left-aligned and can't be
          // changed with `text-align` utilities on the input by default. Resetting this to `inherit`
          // makes them left-aligned by default and makes it possible to override the alignment with
          // utility classes without using an arbitrary variant to target the pseudo-elements.
          base: ['::-webkit-date-and-time-value'],
          class: ['.seimoment-form-input::-webkit-date-and-time-value'],
          styles: {
            'text-align': 'inherit',
          },
        },
        {
          // In Safari on macOS date time inputs that are set to `display: block` have unexpected
          // extra bottom spacing. This can be corrected by setting the `::-webkit-datetime-edit`
          // pseudo-element to `display: inline-flex`, instead of the browser default of
          // `display: inline-block`.
          base: ['::-webkit-datetime-edit'],
          class: ['.seimoment-form-input::-webkit-datetime-edit'],
          styles: {
            display: 'inline-flex',
          },
        },
        {
          // In Safari on macOS date time inputs are 4px taller than normal inputs
          // This is because there is extra padding on the datetime-edit and datetime-edit-{part}-field pseudo elements
          // See https://github.com/tailwindlabs/tailwindcss-forms/issues/95
          base: [
            '::-webkit-datetime-edit',
            '::-webkit-datetime-edit-year-field',
            '::-webkit-datetime-edit-month-field',
            '::-webkit-datetime-edit-day-field',
            '::-webkit-datetime-edit-hour-field',
            '::-webkit-datetime-edit-minute-field',
            '::-webkit-datetime-edit-second-field',
            '::-webkit-datetime-edit-millisecond-field',
            '::-webkit-datetime-edit-meridiem-field',
          ],
          class: [
            '.seimoment-form-input::-webkit-datetime-edit',
            '.seimoment-form-input::-webkit-datetime-edit-year-field',
            '.seimoment-form-input::-webkit-datetime-edit-month-field',
            '.seimoment-form-input::-webkit-datetime-edit-day-field',
            '.seimoment-form-input::-webkit-datetime-edit-hour-field',
            '.seimoment-form-input::-webkit-datetime-edit-minute-field',
            '.seimoment-form-input::-webkit-datetime-edit-second-field',
            '.seimoment-form-input::-webkit-datetime-edit-millisecond-field',
            '.seimoment-form-input::-webkit-datetime-edit-meridiem-field',
          ],
          styles: {
            'padding-top': '0',
            'padding-bottom': '0',
          },
        },
        {
          base: ['select'],
          class: ['.seimoment-form-select'],
          styles: {
            'background-image': `url("${svgToDataUri(
              `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"><path stroke="${resolveColor(
                theme('colors.gray.500', colors.gray[500]),
                '--tw-stroke-opacity',
              )}" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 8l4 4 4-4"/></svg>`,
            )}")`,
            'background-position': `right ${spacing[2]} center`,
            'background-repeat': `no-repeat`,
            'background-size': `1.5em 1.5em`,
            'padding-right': spacing[10],
            'print-color-adjust': `exact`,
          },
        },
        {
          base: ['[multiple]', '[size]:where(select:not([size="1"]))'],
          class: ['.seimoment-form-select:where([size]:not([size="1"]))'],
          styles: {
            'background-image': 'initial',
            'background-position': 'initial',
            'background-repeat': 'unset',
            'background-size': 'initial',
            'padding-right': spacing[3],
            'print-color-adjust': 'unset',
          },
        },
        {
          base: [`[type='checkbox']`, `[type='radio']`],
          class: ['.seimoment-form-checkbox', '.seimoment-form-radio'],
          styles: {
            appearance: 'none',
            padding: '0',
            'print-color-adjust': 'exact',
            display: 'inline-block',
            'vertical-align': 'middle',
            'background-origin': 'border-box',
            'user-select': 'none',
            'flex-shrink': '0',
            height: spacing[4],
            width: spacing[4],
            color: '#000',
            'background-color': '#fff',
            'border-color': theme('colors.foreground'),
            'border-width': borderWidth['DEFAULT'],
          },
        },
        {
          base: [`[type='checkbox']`],
          class: ['.seimoment-form-checkbox'],
          styles: {
            'border-radius': '5px',
          },
        },
        {
          base: [`[type='radio']`],
          class: ['.seimoment-form-radio'],
          styles: {
            'border-radius': '100%',
          },
        },
        {
          base: [`[type='checkbox']:focus`, `[type='radio']:focus`],
          class: [
            '.seimoment-form-checkbox:focus',
            '.seimoment-form-radio:focus',
          ],
          styles: {
            outline: 'none',
          },
        },
        {
          base: [`[type='checkbox']:checked`, `[type='radio']:checked`],
          class: [
            '.seimoment-form-checkbox:checked',
            '.seimoment-form-radio:checked',
          ],
          styles: {
            'border-color': `transparent`,
            'background-color': `currentColor`,
            'background-size': `100% 100%`,
            'background-position': `center`,
            'background-repeat': `no-repeat`,
          },
        },
        {
          base: [`[type='checkbox']:checked`],
          class: ['.seimoment-form-checkbox:checked'],
          styles: {
            'background-image': `url("${svgToDataUri(
              `<svg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 20 20' fill='none'><rect width='20' height='20' rx='4' fill='%23E86630'/><path d='M7 10.5L9.4974 13L13.9927 7' stroke='white' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/></svg>`,
            )}")`,

            '@media (forced-colors: active) ': {
              appearance: 'auto',
            },
          },
        },
        {
          base: [`[type='radio']:checked`],
          class: ['.seimoment-form-radio:checked'],
          styles: {
            'background-image': `url("${svgToDataUri(
              `<svg viewBox="0 0 16 16" fill="white" xmlns="http://www.w3.org/2000/svg"><circle cx="8" cy="8" r="3"/></svg>`,
            )}")`,

            '@media (forced-colors: active) ': {
              appearance: 'auto',
            },
          },
        },
        {
          base: [
            `[type='checkbox']:checked:hover`,
            `[type='checkbox']:checked:focus`,
            `[type='radio']:checked:hover`,
            `[type='radio']:checked:focus`,
          ],
          class: [
            '.seimoment-form-checkbox:checked:hover',
            '.seimoment-form-checkbox:checked:focus',
            '.seimoment-form-radio:checked:hover',
            '.seimoment-form-radio:checked:focus',
          ],
          styles: {
            'border-color': 'transparent',
            'background-color': 'currentColor',
          },
        },
        {
          base: [`[type='checkbox']:indeterminate`],
          class: ['.seimoment-form-checkbox:indeterminate'],
          styles: {
            'background-image': `url("${svgToDataUri(
              `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 16 16"><path stroke="white" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8h8"/></svg>`,
            )}")`,
            'border-color': `transparent`,
            'background-color': `currentColor`,
            'background-size': `100% 100%`,
            'background-position': `center`,
            'background-repeat': `no-repeat`,

            '@media (forced-colors: active) ': {
              appearance: 'auto',
            },
          },
        },
        {
          base: [
            `[type='checkbox']:indeterminate:hover`,
            `[type='checkbox']:indeterminate:focus`,
          ],
          class: [
            '.seimoment-form-checkbox:indeterminate:hover',
            '.seimoment-form-checkbox:indeterminate:focus',
          ],
          styles: {
            'border-color': 'transparent',
            'background-color': 'currentColor',
          },
        },
        {
          base: [`[type='file']`],
          class: null,
          styles: {
            background: 'unset',
            'border-color': 'inherit',
            'border-width': '0',
            'border-radius': '0',
            padding: '0',
            'font-size': 'unset',
            'line-height': 'inherit',
          },
        },
        {
          base: [`[type='file']:focus`],
          class: null,
          styles: {
            outline: [
              `1px solid ButtonText`,
              `1px auto -webkit-focus-ring-color`,
            ],
          },
        },
      ];

      const getStrategyRules = (strategy: Options['strategy'] = 'base') =>
        rules
          .map(rule => {
            const selectors = (rule[strategy] ?? []).join(',');
            return { [selectors]: rule.styles };
          })
          .filter(Boolean);

      if (strategy.includes('base')) {
        addBase(getStrategyRules('base'));
      }

      if (strategy.includes('class')) {
        addComponents(getStrategyRules('class'));
      }
    };
  },
);

export { forms };
