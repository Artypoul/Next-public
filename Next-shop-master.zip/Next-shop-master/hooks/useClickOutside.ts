import { useEffect, useRef, useState } from 'react';

export function useClickOutside<T extends HTMLElement>(callback: () => void) {
  const [callbackFn] = useState(() => callback);
  const ref = useRef<T>(null);

  useEffect(() => {
    const handleClick = (event: MouseEvent | TouchEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        callbackFn();
      }
    };

    document.addEventListener('mousedown', handleClick, true);

    return () => {
      document.removeEventListener('mousedown', handleClick, true);
    };
  }, [callbackFn]);

  return ref;
}
