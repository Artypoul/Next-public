import { useCallback, useEffect, useState } from 'react';
import resolveConfig from 'tailwindcss/resolveConfig';

import tailwindConfig from '@/tailwind.config';

const fullConfig = resolveConfig(tailwindConfig);
const screens = fullConfig.theme.screens;
const screensArray = Object.entries(screens).map(([screen, size]) => [
  screen,
  parseFloat(size),
]) as [keyof typeof screens, number][];
const screensShapes = screensArray.map((screen, index) => {
  return {
    min: !index ? 0 : screensArray[index - 1][1],
    max: screen[1],
    key: screen[0],
  };
});

export function useTailwindBreakpoint() {
  const [screen, setScreen] = useState<keyof typeof screens>();
  const [width, setWidth] = useState(
    typeof window !== 'undefined' ? window.innerWidth : 0,
  );

  const onWindowResize = useCallback(() => {
    const width = typeof window !== 'undefined' ? window.innerWidth : 0;
    const shape = screensShapes.find(
      ({ min, max }) => width >= min && width < max,
    );

    if (shape) {
      setScreen(shape.key);
    } else if (width < screensShapes[0].max) {
      setScreen(screensShapes[0].key);
    } else if (width >= screensShapes[screensShapes.length - 1].max) {
      setScreen(screensShapes[screensShapes.length - 1].key);
    }

    setWidth(width);
  }, []);

  useEffect(() => {
    onWindowResize();
    window.addEventListener('resize', onWindowResize);
    return () => {
      window.removeEventListener('resize', onWindowResize);
    };
  }, [onWindowResize]);

  const down = useCallback(
    (screen: keyof typeof screens) => {
      const shape = screensShapes.find(shape => shape.key === screen);
      if (!shape) return false;

      return width < shape.min;
    },
    [width],
  );

  const up = useCallback(
    (screen: keyof typeof screens) => {
      const shape = screensShapes.find(shape => shape.key === screen);
      if (!shape) return false;

      return width > shape.max;
    },
    [width],
  );

  return { screen, width, down, up };
}
