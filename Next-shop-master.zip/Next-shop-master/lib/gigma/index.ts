import {
  ContentBlock,
  CreateOrderRequest,
  CreateOrderResponse,
  GetBrandsResponse,
  GetCategoriesResponse,
  GetContentResponse,
  GetCountriesResponse,
  GetDeliverySubTypeParamsResponse,
  GetDeliverySubTypesResponse,
  GetDeliveryTypesResponse,
  GetDictionariesResponse,
  GetFavoritesRequest,
  GetFavoritesResponse,
  GetMenuResponse,
  GetNotificationsResponse,
  GetOrdersResponse,
  GetPaymentTypesResponse,
  GetPopularSeachResponse,
  GetPriceRangeRequest,
  GetPriceRangeResponse,
  GetPriceRequest,
  GetPriceResponse,
  GetProductResponse,
  GetProductsRequest,
  GetProductsResponse,
  GetSearchHistoryResponse,
  GetShopsResponse,
  GetTagsResponse,
  MenuItems,
  Notification,
  SearchAddressResponse,
  User,
  UserUpdate,
} from './types';

const REVALIDATE_TIME = 60;
const ENDPOINT = process.env.NEXT_PUBLIC_API ?? '';
const TOKEN = process.env.NEXT_PUBLIC_TOKEN ?? '';

export default async function gigmaRequest<T>({
  cache = 'force-cache',
  method,
  path,
  payload,
  tags,
  revalidateTime,
  headers = {},
  options = {},
}: {
  cache?: RequestCache;
  method: string;
  path: string;
  payload?: Record<string, unknown> | undefined;
  tags?: string[];
  revalidateTime?: number;
  headers?: HeadersInit;
  options?: RequestInit;
}) {
  const optionsDefault: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      Token: TOKEN,
      ...headers,
    },
    cache,
    next: {},
  };

  const optionsMerged = { ...optionsDefault, ...options };

  if (tags) {
    optionsMerged.next!.tags = tags;
  }

  if (revalidateTime) {
    optionsMerged.next!.revalidate = revalidateTime;
  }

  if (payload) {
    optionsMerged.body = JSON.stringify(payload);
  }
  try {
    const result = await fetch(`${ENDPOINT}/${path}`, optionsMerged);

    if (result.status === 404 || result.status === 401) {
      return undefined;
    }

    const body = await result.json();
    if (!result.ok && body.message) {
      throw `Gigma API returned an error: ${body.message}. API route is: ${ENDPOINT}/${path}`;
    } else if (!result.ok) {
      throw `Gigma API returned an error ${result.status}. API route is: ${ENDPOINT}/${path}`;
    }

    return {
      status: result.status,
      body: body as T,
    };
  } catch (e) {
    throw {
      error: e,
    };
  }
}

export async function getMenu(
  id: string | number,
): Promise<MenuItems | undefined> {
  const res = await gigmaRequest<GetMenuResponse>({
    method: 'GET',
    path: `counterparty/menus/${id}`,
    tags: ['menu'],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  const { menuItems } = res.body;

  return menuItems;
}

export async function getCategories({
  limit = 100,
  parentId,
}: {
  limit?: number | string;
  parentId?: number | string;
}): Promise<GetCategoriesResponse | undefined> {
  let path = `counterparty/categories?limit=${limit}`;
  if (parentId) path += `&parent_id=${parentId}`;

  const res = await gigmaRequest<GetCategoriesResponse>({
    method: 'GET',
    path,
    tags: ['categories'],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  return res.body;
}

export async function getProducts({
  query,
  page = 1,
  perPage = 9,
  orderBy,
  brand,
  category,
  country,
  token,
  priceFrom,
  priceTo,
  available,
}: GetProductsRequest & { token?: string }): Promise<
  GetProductsResponse | undefined
> {
  let path = `counterparty/products?page=${page}&per_page=${perPage}`;

  if (query) {
    path += `&query=${query}`;
  }
  if (orderBy) {
    path += `&order_by=${orderBy}`;
  }

  if (brand) {
    const parts = brand.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&brand_id[]=${part}`;
    }
  }

  if (category) {
    const parts = category.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&category_id[]=${part}`;
    }
  }

  if (country) {
    const parts = country.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&country_id[]=${part}`;
    }
  }

  if (priceFrom) {
    path += `&price_from=${priceFrom}`;
  }

  if (priceTo) {
    path += `&price_to=${priceTo}`;
  }

  if (available) {
    const parts = available.split(',');
    if (parts.includes('2') && !parts.includes('1')) {
      path += `&available=offline`;
    } else if (parts.includes('1') && !parts.includes('2')) {
      path += `&available=online`;
    }
  }

  const res = await gigmaRequest<GetProductsResponse>({
    method: 'GET',
    path,
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    tags: ['products'],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  return res.body;
}

export async function getSliderContent(): Promise<ContentBlock | undefined> {
  const res = await gigmaRequest<GetContentResponse>({
    method: 'GET',
    path: `counterparty/blocks/id/slider`,
    tags: ['blocks'],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  return res.body.block;
}

export async function getPrivacyPolicyContent(): Promise<
  ContentBlock | undefined
> {
  const res = await gigmaRequest<GetContentResponse>({
    method: 'GET',
    path: `counterparty/blocks/id/privacy-policy`,
    tags: ['blocks'],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body?.block;
}

export async function getLogoContent(): Promise<ContentBlock | undefined> {
  const res = await gigmaRequest<GetContentResponse>({
    method: 'GET',
    path: `counterparty/blocks/id/logo`,
    tags: ['blocks'],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body?.block;
}

export async function getBrands(): Promise<GetBrandsResponse | undefined> {
  const res = await gigmaRequest<GetBrandsResponse>({
    method: 'GET',
    path: 'counterparty/brands',
    tags: ['brands'],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  return res.body;
}

export async function getProduct(
  id: string,
): Promise<GetProductResponse | undefined> {
  const res = await gigmaRequest<GetProductResponse>({
    method: 'GET',
    path: `counterparty/products/${id}`,
    tags: [`product${id}`],
    revalidateTime: REVALIDATE_TIME,
  });

  if (!res) return undefined;

  return res.body;
}

export async function getOrders(
  token: string,
): Promise<GetOrdersResponse | undefined> {
  const res = await gigmaRequest<GetOrdersResponse>({
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` },
    path: `counterparty/orders`,
    cache: 'no-cache',
  });

  if (!res) return undefined;

  return res.body;
}

export async function getFavorites({
  token,
  page,
  perPage,
}: GetFavoritesRequest): Promise<GetFavoritesResponse | undefined> {
  const res = await gigmaRequest<GetFavoritesResponse>({
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` },
    path: `counterparty/products/favourites?per_page=${perPage}&page=${page}`,
    cache: 'no-cache',
  });

  if (!res) return undefined;

  return res.body;
}

export async function addToFavorite(
  product_id: number,
  token: string,
): Promise<boolean> {
  const res = await gigmaRequest<boolean>({
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    payload: { product_id },
    path: `counterparty/products/favourites`,
    cache: 'no-cache',
  });

  if (!res) return false;

  return true;
}

export async function removeFromFavorite(
  product_id: number,
  token: string,
): Promise<boolean> {
  const res = await gigmaRequest<boolean>({
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
    path: `counterparty/products/favourites/${product_id}`,
    cache: 'no-cache',
  });

  if (!res) return false;

  return true;
}

export async function sendCode(phone: string): Promise<boolean> {
  const res = await gigmaRequest<{ message: string }>({
    method: 'POST',
    payload: { phone },
    path: `counterparty/send_password`,
    cache: 'no-cache',
  });

  return res?.status === 200;
}

export async function login({
  phone,
  password,
}: {
  phone: string;
  password: string;
}): Promise<User | undefined> {
  const res = await gigmaRequest<User>({
    method: 'POST',
    payload: { phone, password },
    path: `counterparty/login`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function logout(
  token: string,
  from_all_devices?: boolean,
): Promise<boolean> {
  const res = await gigmaRequest<{ message: string }>({
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    payload: { from_all_devices: !!from_all_devices },
    path: `counterparty/logout`,
    cache: 'no-cache',
  });

  return res?.status === 200;
}

export async function requestPnoneChange(
  phone: string,
  token: string,
): Promise<boolean> {
  const res = await gigmaRequest<{ message: string }>({
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    payload: { new_phone_number: phone },
    path: `counterparty/phone/request_change`,
    cache: 'no-cache',
  });

  return res?.status === 200;
}

export async function verifyPhoneChange(
  code: string,
  token: string,
): Promise<User | undefined> {
  const res = await gigmaRequest<User>({
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    payload: { password: code },
    path: `counterparty/phone/verify_change`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getUser(token: string): Promise<User | undefined> {
  const res = await gigmaRequest<User>({
    method: 'GET',
    headers: { Authorization: `Bearer ${token}` },
    path: `counterparty`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function updateUser({
  token,
  ...payload
}: UserUpdate & {
  token: string;
}): Promise<User | undefined> {
  const res = await gigmaRequest<User>({
    method: 'PUT',
    headers: { Authorization: `Bearer ${token}` },
    payload,
    path: `counterparty`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getOrderPrice(
  products: GetPriceRequest,
): Promise<GetPriceResponse> {
  const res = await gigmaRequest<GetPriceResponse>({
    method: 'POST',
    payload: { products },
    path: `counterparty/orders/precalculate`,
    cache: 'no-cache',
  });

  return (
    res?.body ?? {
      price: 0,
      total: 0,
      discount: 0,
    }
  );
}

export async function getDeliveryTypes(): Promise<
  GetDeliveryTypesResponse | undefined
> {
  const res = await gigmaRequest<GetDeliveryTypesResponse>({
    method: 'GET',
    path: `counterparty/delivery_types`,
    tags: [`deliveryTypes`],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body;
}

export async function getDeliverySubTypes(
  deliveryType: number,
): Promise<GetDeliverySubTypesResponse | undefined> {
  const res = await gigmaRequest<GetDeliverySubTypesResponse>({
    method: 'GET',
    path: `counterparty/delivery_types/${deliveryType}/subtypes`,
    tags: [`deliverySubTypes`],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body;
}

export async function getDeliverySubTypeParams(
  deliveryType: number,
  deliverySubType: number,
): Promise<GetDeliverySubTypeParamsResponse | undefined> {
  const res = await gigmaRequest<GetDeliverySubTypeParamsResponse>({
    method: 'GET',
    path: `counterparty/delivery_types/${deliveryType}/subtypes/${deliverySubType}/params`,
    tags: [`deliverySubTypeParams`],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body;
}

export async function getShops(): Promise<GetShopsResponse | undefined> {
  const res = await gigmaRequest<GetShopsResponse>({
    method: 'GET',
    path: `counterparty/shops`,
    tags: [`shops`],
    revalidateTime: REVALIDATE_TIME,
  });

  return res?.body;
}

export async function searchAddress(
  query: string,
  options?: RequestInit,
): Promise<SearchAddressResponse | undefined> {
  const res = await gigmaRequest<SearchAddressResponse>({
    method: 'POST',
    path: `counterparty/search_address`,
    payload: {
      query,
    },
    cache: 'no-cache',
    options,
  });

  return res?.body;
}

export async function getPaymentTypes(): Promise<
  GetPaymentTypesResponse | undefined
> {
  const res = await gigmaRequest<GetPaymentTypesResponse>({
    method: 'GET',
    path: `counterparty/payment_types`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function createOrder({
  token,
  ...payload
}: CreateOrderRequest): Promise<CreateOrderResponse | undefined> {
  const res = await gigmaRequest<CreateOrderResponse>({
    method: 'POST',
    path: `counterparty/orders`,
    payload,
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getAllTags(): Promise<GetTagsResponse | undefined> {
  const res = await gigmaRequest<GetTagsResponse>({
    method: 'GET',
    path: `counterparty/tags`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getTopSearch(): Promise<
  GetPopularSeachResponse | undefined
> {
  const res = await gigmaRequest<GetPopularSeachResponse>({
    method: 'GET',
    path: `counterparty/search/popular`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getSearchHistory(
  token: string,
): Promise<GetSearchHistoryResponse | undefined> {
  const res = await gigmaRequest<GetSearchHistoryResponse>({
    method: 'GET',
    path: `counterparty/search/history`,
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getPricesRange({
  query,
  orderBy,
  brand,
  category,
  country,
  available,
}: GetPriceRangeRequest): Promise<GetPriceRangeResponse | undefined> {
  let path = `counterparty/prices?order_by=${orderBy || 'price_asc'}`;

  if (query) {
    path += `&query=${query}`;
  }

  if (brand) {
    const parts = brand.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&brand_id[]=${part}`;
    }
  }

  if (category) {
    const parts = category.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&category_id[]=${part}`;
    }
  }

  if (country) {
    const parts = country.split(',');
    for (let index = 0; index < parts.length; index++) {
      const part = parts[index];
      path += `&country_id[]=${part}`;
    }
  }

  if (available) {
    const parts = available.split(',');
    if (parts.includes('2') && !parts.includes('1')) {
      path += `&available=offline`;
    } else if (parts.includes('1') && !parts.includes('2')) {
      path += `&available=online`;
    }
  }

  const res = await gigmaRequest<GetPriceRangeResponse>({
    method: 'GET',
    path,
  });

  if (!res) return undefined;

  return res.body;
}

export async function getCountries(): Promise<
  GetCountriesResponse | undefined
> {
  const res = await gigmaRequest<GetCountriesResponse>({
    method: 'GET',
    path: `counterparty/countries`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getDictionaries(): Promise<
  GetDictionariesResponse | undefined
> {
  const res = await gigmaRequest<GetDictionariesResponse>({
    method: 'GET',
    path: `counterparty/dictionaries?include=categories,brands,countries,tags,popular_requests`,
    cache: 'no-cache',
  });

  return res?.body;
}

export async function getNotifications(token: string): Promise<Notification[]> {
  const res = await gigmaRequest<GetNotificationsResponse>({
    method: 'GET',
    path: `counterparty/notifications?page=1&limit=1000`,
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-cache',
  });

  return res?.body?.notifications ?? [];
}
