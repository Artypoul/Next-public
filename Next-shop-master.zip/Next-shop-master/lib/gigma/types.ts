export type Nullable<T> = T | null;

export type MenuItems = {
  code: number;
  avatar: string;
  name: string;
  url: string;
  children: MenuItems[];
};

export type GetMenuResponse = {
  menuItems: MenuItems;
};

export type Category = {
  id: number;
  name: string;
  photo: string;
  parent: Category | null;
};

export type GetCategoriesResponse = {
  categories: Category[];
  categoriesCount: number;
};

export type CategoriesTree = Omit<Category, 'parent'> & {
  children: CategoriesTree[];
};

export type Brand = {
  id: number;
  name: string;
  photo: string;
  created_at: string;
};

export type Tag = {
  id: number;
  name: string;
  avatar: string;
  created_at: string;
};

export type Product = {
  id: number;
  views_count: number;
  photo: string;
  name: string;
  brand: Brand;
  old_price: string;
  price: string;
  discount: string;
  quantity: number;
  unit: unknown;
  is_favourite: boolean;
  tags: Tag[];
};

export type Link = {
  url?: string;
  label: string;
  active: boolean;
};

export type OrderBy =
  | 'name_asc'
  | 'name_desc'
  | 'popularity_asc'
  | 'popularity_desc'
  | 'price_asc'
  | 'price_desc';

export type GetProductsRequest = {
  query?: string | null;
  page?: number | null;
  perPage?: number | null;
  orderBy?: OrderBy | null;
  brand?: string | null;
  category?: string | null;
  country?: string | null;
  priceFrom?: string | null;
  priceTo?: string | null;
  available?: string;
};

export type ProductSearchParams = GetProductsRequest;

export type GetProductsResponse = {
  products: {
    current_page: number;
    data: Product[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: Link[];
    next_page_url: string;
    path: string;
    per_page: number;
    prev_page_url: string;
    to: number;
    total: number;
  };
};

export interface Avatar {
  id: number;
  name: string;
  type: {
    id: number;
    name: string;
    avatar: string;
    created_at: string;
  };
  path: string;
  link: Link;
  created_at: string;
  updated_at: string;
}

export enum BlockTypeId {
  Text = 1,
  RichText = 2,
  Image = 3,
  Video = 4,
  Link = 5,
}

export type ContentBlock = {
  id?: number;
  code: string | null;
  name: string;
  avatar?: Avatar;
  block_type?: {
    id: BlockTypeId;
    name: string;
    avatar: string;
    created_at: string;
  };
  link?: string;
  file?: Avatar;
  text?: string;
  identifier?: string;
  parent?: ContentBlock;
  children?: ContentBlock[];
};

export type GetContentResponse = {
  block: ContentBlock;
};

export type GetBrandsResponse = {
  brands: Brand[];
  brandsCount: number;
};
export type ProductPhoto = {
  id: number;
  name: string;
  path: string;
  link: string;
};

export type SingleProduct = {
  id: number;
  views_count: number;
  photos: ProductPhoto[];
  name: string;
  brand: Brand;
  description: string;
  specification: string;
  old_price: string;
  price: string;
  discount: number;
  quantity: number;
  unit: unknown;
  is_favourite: boolean;
  share_link: string;
  tags: Tag[];
};

export type GetProductResponse = {
  product: SingleProduct;
};

export type OrderData = {
  id: number;
  status: {
    id: number;
    name: string;
    photo: string;
    created_at: string;
  };
  price: string;
  delivery_type: DeliveryType;
  delivery_subtype?: DeliveryType;
  delivery_subtype_param?: DeliverySubTypeParam;
  payment_type: PaymentType;
  shop?: Shop;
  address: string;
  products: SingleProduct[];
  payment_link: string;
  created_at: string;
};

export type GetOrdersResponse = {
  orders: OrderData[];
  ordersCount: number;
};

export type GetFavoritesRequest = {
  token: string;
  page?: number;
  perPage?: number;
};

export type GetFavoritesResponse = {
  products: {
    current_page: number;
    data: Product[];
    first_page_url: string;
    from: number;
    last_page: number;
    last_page_url: string;
    links: Array<{
      url?: string;
      label: string;
      active: boolean;
    }>;
    next_page_url: string;
    path: string;
    per_page: number;
    prev_page_url: string;
    to: number;
    total: number;
  };
};

export type User = {
  counterparty: {
    id: number;
    type: {
      id: number;
      name: string;
      created_at: string;
    };
    favourite_products: Product[];
    manager: {
      id: number;
      first_name: string;
      last_name: string;
      middle_name: string;
      name: string;
    };
    avatar: Avatar;
    first_name: string;
    last_name: string;
    middle_name: string;
    birthday: string;
    address: string;
    phone_1: string;
    phone_2: string;
    email: string;
    created_at: string;
    updated_at: string;
    access_token?: {
      value: string;
    };
  };
};

export type UserUpdate = {
  first_name?: string;
  last_name?: string;
  email?: string;
  phone?: string;
  address?: string;
};

export type GetPriceRequest = {
  id: number;
  quantity: number;
}[];

export type GetPriceResponse = {
  price: number;
  discount: number;
  total: number;
};

export type DeliveryType = {
  id: number;
  name: string;
  price: string;
  is_active: number;
};

export type GetDeliveryTypesResponse = {
  deliveryType: DeliveryType[];
  deliveryTypeCount: number;
};

export type GetDeliverySubTypesResponse = {
  deliverySubtypes: DeliveryType[];
  deliverySubtypesCount: number;
};

export type DeliverySubTypeParam = {
  id: number;
  name: string;
};

export type GetDeliverySubTypeParamsResponse = {
  deliverySubtypeParams: DeliverySubTypeParam[];
  deliverySubtypeParamsCount: number;
};

export type Shop = {
  id: number;
  photo: string | null;
  name: string;
  address: string;
  phone: string;
  schedule: string;
};

export type GetShopsResponse = {
  shops: Shop[];
  shopsCount: number;
};

export type DadataAddress = {
  name: string;
  value: string;
};

export type SearchAddressResponse = {
  addresses: DadataAddress[];
  addressesCount: number;
};

export type PaymentType = {
  id: number;
  photo: string;
  name: string;
  description: string;
};

export type GetPaymentTypesResponse = {
  paymentTypes: PaymentType[];
  paymentTypesCount: number;
};

export type CreateOrderRequest = {
  token: string;
  delivery_type_id: number;
  delivery_subtype_id?: number;
  delivery_subtype_param_id?: number;
  shop_id?: number;
  payment_type_id: number;
  address?: string;
  products: {
    id: number;
    quantity: number;
  }[];
};

export type CreateOrderResponse = {
  order: OrderData;
};

export type SeachHistoryData = {
  id: number;
  value: string;
  created_at: string;
};

export type GetSearchHistoryResponse = {
  searchRequests: SeachHistoryData[];
  searchRequestsCount: number;
};

export type TagData = {
  id: number;
  name: string;
  avatar?: string;
  created_at: string;
};

export type GetTagsResponse = {
  tags: TagData[];
  tagsCount: number;
};

export type PopularSeachData = {
  id: number;
  value: string;
  created_at: string;
};

export type GetPopularSeachResponse = {
  searchRequests: PopularSeachData[];
  searchRequestsCount: number;
};

export type GetPriceRangeRequest = GetProductsRequest;

export type GetPriceRangeResponse = {
  min_price: number;
  max_price: number;
};

export type Country = {
  id: number;
  name: string;
  created_at: string;
};

export type GetCountriesResponse = {
  countries: Country[];
  countriesCount: number;
};

export type Notification = {
  id: number;
  icon?: string;
  title: string;
  status: string;
  action_url?: string;
  created_at: string;
};

export type GetNotificationsResponse = {
  notifications: Notification[];
};

export type GetDictionariesResponse = {
  dictionaries: {
    categories: Category[];
    brands: Brand[];
    countries: Country[];
    tags: Tag[];
    popular_requests: PopularSeachData[];
  };
};
