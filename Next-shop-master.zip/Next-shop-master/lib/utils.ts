import {
  addDays,
  addMinutes,
  addYears,
  differenceInMilliseconds,
  endOfDay,
  getHours,
  getTime,
  isDate,
  startOfDay,
  subDays,
  subYears,
} from 'date-fns';

import { CategoriesTree, Category, User } from './gigma/types';

export const getNoun = (
  number: number,
  one: string,
  two: string,
  five: string,
): string => {
  let n = Math.abs(number);
  n %= 100;
  if (n >= 5 && n <= 20) {
    return five;
  }
  n %= 10;
  if (n === 1) {
    return one;
  }
  if (n >= 2 && n <= 4) {
    return two;
  }
  return five;
};

export const money = (
  sum = 0,
  currency = 'RUB',
  currencyDisplay = 'symbol',
  maximumFractionDigits = 2,
): string => {
  let cur = currency;
  if (cur === 'RUR') cur = 'RUB';
  const formatter = new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: cur,
    currencyDisplay: currencyDisplay as never,
    maximumFractionDigits,
  });

  return formatter.format(parseFloat(sum.toString()));
};

export const formatNumber = (
  sum = 0,
  minimumFractionDigits = 0,
  maximumFractionDigits = 2,
): string => {
  const formatter = new Intl.NumberFormat('ru-RU', {
    style: 'decimal',
    minimumFractionDigits,
    maximumFractionDigits,
  });

  return formatter.format(parseFloat(sum.toString()));
};

export const generatePagination = (currentPage: number, totalPages: number) => {
  // If the total number of pages is 7 or less,
  // display all pages without any ellipsis.
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, i) => i + 1);
  }

  // If the current page is among the first 3 pages,
  // show the first 3, an ellipsis, and the last 2 pages.
  if (currentPage <= 3) {
    return [1, 2, 3, '...', totalPages - 1, totalPages];
  }

  // If the current page is among the last 3 pages,
  // show the first 2, an ellipsis, and the last 3 pages.
  if (currentPage >= totalPages - 2) {
    return [1, 2, '...', totalPages - 2, totalPages - 1, totalPages];
  }

  // If the current page is somewhere in the middle,
  // show the first page, an ellipsis, the current page and its neighbors,
  // another ellipsis, and the last page.
  return [
    1,
    '...',
    currentPage - 1,
    currentPage,
    currentPage + 1,
    '...',
    totalPages,
  ];
};

export const formatCompactNumber = (number: number) => {
  if (number < 1000) {
    return number;
  } else if (number >= 1000 && number < 1_000_000) {
    return (number / 1000).toFixed(2) + 'K';
  } else if (number >= 1_000_000 && number < 1_000_000_000) {
    return (number / 1_000_000).toFixed(2) + 'M';
  } else if (number >= 1_000_000_000 && number < 1_000_000_000_000) {
    return (number / 1_000_000_000).toFixed(2) + 'B';
  } else if (number >= 1_000_000_000_000 && number < 1_000_000_000_000_000) {
    return (number / 1_000_000_000_000).toFixed(2) + 'T';
  }
};

export const getSwitchedKey = <
  T extends HTMLInputElement | HTMLTextAreaElement = HTMLInputElement,
>(
  e: React.KeyboardEvent<T>,
): string => {
  const key = e.key;
  const code = e.code;

  let letter = key;

  if (e.ctrlKey || e.metaKey || e.key.length !== 1) return letter;
  const codes: Record<string, string> = {
    KeyQ: 'й',
    KeyW: 'ц',
    KeyE: 'у',
    KeyR: 'к',
    KeyT: 'е',
    KeyY: 'н',
    KeyU: 'г',
    KeyI: 'ш',
    KeyO: 'щ',
    KeyP: 'з',
    BracketLeft: 'х',
    BracketRight: 'ъ',
    KeyA: 'ф',
    KeyS: 'ы',
    KeyD: 'в',
    KeyF: 'а',
    KeyG: 'п',
    KeyH: 'р',
    KeyJ: 'о',
    KeyK: 'л',
    KeyL: 'д',
    Semicolon: 'ж',
    Quote: 'э',
    KeyZ: 'я',
    KeyX: 'ч',
    KeyC: 'с',
    KeyV: 'м',
    KeyB: 'и',
    KeyN: 'т',
    KeyM: 'ь',
    Comma: 'б',
    Period: 'ю',
    Backquote: 'ё',
  };

  if (!(code in codes)) {
    return letter;
  } else {
    letter = codes[code] as string;
  }

  const isUpper = key === key.toUpperCase();

  if (isUpper) letter = letter.toUpperCase();

  return letter;
};

export const formatPhone = (phone: string | number, lead = ''): string => {
  if (!phone) return '';
  let str = Number(lead + phone.toString().replace(/\D/g, '')).toString();
  str = str.replace(
    /(?<countryCode>\d{1})(?<operatorCode>\d{3})(?<one>\d{3})(?<two>\d{2})(?<three>\d{2})/,
    '$1 ($2) $3 $4 $5',
  );

  return `+${str}`;
};

export const isMS = (value: unknown): boolean => {
  if (typeof value !== 'number' || isNaN(value)) return false;
  return value === parseInt(String(value), 10);
};

export const toUTC = (value: Date | number): number => {
  const date = new Date(value);
  return getTime(addMinutes(date, -date.getTimezoneOffset()));
};

export const fromUTC = (
  value: Date | number | undefined,
): number | undefined => {
  if (value === undefined) return value;
  let date = new Date(value);
  const offset = date.getTimezoneOffset();
  date = addMinutes(date, offset);
  if (getHours(date) !== 0) {
    date.setTime(
      getTime(date) + (date.getTimezoneOffset() - offset) * 60 * 1000,
    );
  }
  return getTime(date);
};

export const toMs = (
  value: Date | undefined,
  time: 'startOfDay' | 'endOfDay' | 'current' | undefined = 'startOfDay',
): number | null => {
  if (time !== 'startOfDay' && time !== 'endOfDay' && time !== 'current') {
    throw new Error(
      'time argument must be one of: startOfDay, endOfDay, current',
    );
  }
  if (!value || !isDate(new Date(value))) {
    return null;
  }

  let newValue = null;
  if (time === 'startOfDay') {
    newValue = toUTC(startOfDay(value));
  } else if (time === 'current') {
    const now = Date.now();
    const nowInUTC = toUTC(now);
    const startOfDayInUTC = toUTC(startOfDay(now));
    const offsetMS = differenceInMilliseconds(
      new Date(nowInUTC),
      new Date(startOfDayInUTC),
    );
    newValue = toUTC(new Date(getTime(value) + offsetMS));
  } else {
    newValue = toUTC(endOfDay(new Date(value)));
  }
  return newValue;
};

export const fromMs = (value: number | null | undefined): Date | null => {
  if (value === null || value === undefined) return null;
  if (!isMS(value)) return null;
  if (!isDate(new Date(value))) return null;
  const fromUtcValue = fromUTC(value);
  if (fromUtcValue === undefined) return null;
  return startOfDay(fromUtcValue);
};

export const getMinDateByAge = (age: number, currentDate?: number) => {
  const now = currentDate ?? Date.now();
  return startOfDay(addDays(subYears(now, age + 1), 1));
};

export const getMaxDateByAge = (age: number, currentDate?: number) => {
  const now = currentDate ?? Date.now();
  return endOfDay(subYears(now, age));
};

export const addToDate = ({
  date,
  inUTC,
  outUTC,
  amount,
  add,
  outMs = false,
  outEndOfDay = false,
  subDay = false,
}: {
  date: Date | number;
  /**Input Date in UTC */
  inUTC: boolean;
  /**Output Date in UTC */
  outUTC: boolean;
  /**Output Date in milliseconds */
  outMs?: boolean;
  /**Rewind output Date to day ending */
  outEndOfDay?: boolean;
  /**Date amount */
  amount: number;
  /**Should we add days or years? */
  add: 'days' | 'years';
  /**Should sub on day? */
  subDay?: boolean;
}) => {
  const refDateMs = inUTC ? fromUTC(date) : getTime(date);
  const addFunction = add === 'days' ? addDays : addYears;
  const resultDate =
    add === 'years' && subDay
      ? subDays(addFunction(refDateMs!, amount), 1)
      : addFunction(refDateMs!, amount);
  const rewindedDate = outEndOfDay
    ? endOfDay(resultDate)
    : startOfDay(resultDate);
  const resultDateMs = outUTC ? toUTC(rewindedDate) : getTime(rewindedDate);
  return outMs ? resultDateMs : new Date(resultDateMs);
};

export const getEndDateByBeginDate = (
  beginDate: number,
  amount: number,
  add?: 'days' | 'years',
) => {
  return addToDate({
    date: beginDate,
    add: add ?? 'years',
    amount,
    inUTC: true,
    outUTC: false,
    outEndOfDay: true,
    subDay: true,
  });
};

export const capitalize = (str: string, lower = true): string => {
  let v = lower ? str.toLowerCase() : str;

  v = v.split('').reduce((acc, current) => {
    let val = acc;
    const prev = val ? val.slice(-1) : '';
    if (
      (prev === ' ' || prev === '-' || prev === "'") &&
      (current === ' ' || current === '-' || current === "'")
    ) {
      return acc;
    }
    val += current;
    return val;
  }, '');

  v = v.replace(/(?:^|\s|-|["'([{])+\S/g, match => match.toUpperCase());
  return v;
};

export const validateEmail = (value?: string) => {
  const validByRegex =
    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(
      String(value ?? '').toLowerCase(),
    );

  return validByRegex;
};

export const getUserFullName = (user?: User) => {
  if (!user) return '';
  const { first_name, last_name } = user?.counterparty ?? {};

  return `${first_name ?? ''} ${last_name ?? ''}`.trim();
};

export const getDiscount = ({
  price = 0,
  percent = 0,
}: {
  price: string | number;
  percent: string | number;
}) => {
  const priceValue = typeof price === 'string' ? parseFloat(price) : price;
  const discount = typeof percent === 'string' ? parseFloat(percent) : percent;
  return (priceValue * discount) / 100 + priceValue;
};

export const buildCategoryTree = (categories: Category[]): CategoriesTree[] => {
  const categoryMap: Record<number, CategoriesTree> = {};
  categories.forEach(category => {
    categoryMap[category.id] = {
      id: category.id,
      name: category.name,
      photo: category.photo,
      children: [],
    };
  });

  // Создаем корневой массив для категорий верхнего уровня
  const tree: CategoriesTree[] = [];

  // Связываем категории между собой
  categories.forEach(category => {
    const node = categoryMap[category.id];
    if (category.parent) {
      // Если у категории есть родитель, добавляем ее в children родителя
      if (categoryMap[category.parent.id]) {
        categoryMap[category.parent.id].children.push(node);
      }
    } else {
      // Если нет родителя, добавляем в корневой массив
      tree.push(node);
    }
  });

  return tree;
};
