import type { Config } from 'tailwindcss';

import { forms } from './forms';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './ui/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        foreground: '#020202',
        contrast: '#161c24',
        gold: '#C8B3A3',
        light: '#FAFAFA',
        tag: {
          bg: '#7B809A',
        },
        card: {
          'bg-light': '#F2F2F2',
        },
        auth: {
          'bg-light': '#F0F2F5',
        },
        input: {
          bg: 'rgb(230 230 230 / 0.5)',
          text: '#B7B7B7',
        },
        error: {
          DEFAULT: '#F6957F',
          contrast: '#FAFAFA',
        },
      },
      animation: {
        progress: 'progress 1s linear',
      },
    },
    keyframes: {
      shimmer: {
        '100%': {
          transform: 'translateX(100%)',
        },
      },
      progress: {
        '0%': {
          transform: 'scaleX(0)',
        },
        '100%': {
          transform: 'scaleX(1)',
        },
      },
    },
  },
  plugins: [forms({ strategy: 'base' })],
};

export default config;
