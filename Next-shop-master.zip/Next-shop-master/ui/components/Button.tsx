import type { ButtonHTMLAttributes } from 'react';

import { forwardRef } from 'react';
import { extendTailwindMerge, twJoin } from 'tailwind-merge';

const twMerge = extendTailwindMerge({
  extend: {
    classGroups: { 'font-size': ['text-button'] },
  },
});

type ButtonProps = {
  variant?: 'animated' | 'outlined';
} & ButtonHTMLAttributes<HTMLButtonElement>;

const Button = forwardRef<HTMLButtonElement, ButtonProps>((props, ref) => {
  const { className, type = 'button', variant = 'animated', ...rest } = props;

  const rootClassName = twMerge(
    twJoin(
      variant === 'animated' &&
        'relative z-0 flex items-center justify-center gap-[10px] overflow-hidden rounded bg-black px-4 py-[13px] text-sm font-medium leading-6 text-white before:absolute before:inset-0 before:-z-10 before:translate-y-full before:bg-gold before:duration-300 before:content-[""] hover:before:translate-y-0 disabled:pointer-events-none disabled:opacity-50',
      variant === 'outlined' &&
        'border-input-bg hover:border-gold border-2 rounded bg-[#E6E6E6] px-4 py-[10px] text-xs font-medium leading-6 tracking-[12%] text-black disabled:pointer-events-none disabled:opacity-50',
    ),
    className,
  );

  return <button className={rootClassName} ref={ref} type={type} {...rest} />;
});

Button.displayName = 'Button';

export { Button };
export type { ButtonProps };
