import type { InputHTMLAttributes, ReactNode } from 'react';

import { forwardRef, useId } from 'react';
import { twJoin, twMerge } from 'tailwind-merge';

type CheckboxProps = {
  /** Checkbox label */
  label?: ReactNode;
  /** Label will be placed before or after the checkbox */
  labelPosition?: 'before' | 'after';
  /** Checkbox type */
  type?: 'checkbox' | 'switch' | 'radio';
  wrapperClassName?: string;
} & InputHTMLAttributes<HTMLInputElement>;

const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>((props, ref) => {
  const {
    label,
    labelPosition = 'after',
    type = 'checkbox',
    wrapperClassName = '',
    className = '',
    ...rest
  } = props;

  const isSwitch = type === 'switch';
  const isReversed = labelPosition === 'before';
  const { disabled } = rest;

  const id = useId();

  const rootClassName = twMerge(
    twJoin(
      'flex gap-2.5 text-grey-3',
      disabled ? 'pointer-events-none' : 'lg:cursor-pointer',
      isReversed && 'flex-row-reverse',
    ),
    wrapperClassName,
  );
  const inputWrapperClassName = twJoin(isSwitch && 'relative w-10');
  const inputClassName = twMerge(
    twJoin(
      isSwitch ? 'peer w-[35px] rounded-full checked:bg-none' : 'w-5 my-px',
      'bg-transparent dark:bg-black block h-5',
      'transition-[color,background-color,border-color,box-shadow]',
      'disabled:pointer-events-none disabled:opacity-50 lg:[&:not(:disabled)]:cursor-pointer',
      type === 'radio' && 'rounded-full',
    ),
    className,
  );

  const switchClassName = twJoin(
    'pointer-events-none absolute top-[2px] rounded-full transition-[background-color,left] bg-white',
    'left-[2px] h-4 w-4',
    'peer-checked:left-[17px]',
    'peer-[:not(:checked):disabled]:opacity-50',
  );
  const labelClassName = twJoin('select-none', disabled && 'text-gray-400');

  return (
    <label className={rootClassName}>
      <div className={inputWrapperClassName}>
        <input
          className={inputClassName}
          ref={ref}
          {...rest}
          id={rest.id || id}
          type={type === 'radio' ? 'radio' : 'checkbox'}
        />
        {isSwitch ? <div className={switchClassName} /> : null}
      </div>
      <div className={labelClassName}>{label}</div>
    </label>
  );
});

Checkbox.displayName = 'Checkbox';

export { Checkbox };
export type { CheckboxProps };
