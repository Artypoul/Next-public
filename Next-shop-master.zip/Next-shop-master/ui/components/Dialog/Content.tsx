import type { ComponentRef, PropsWithoutRef } from 'react';
import type { ContentProps } from './types';

import { forwardRef, useContext } from 'react';
import {
  FloatingFocusManager,
  FloatingOverlay,
  FloatingPortal,
} from '@floating-ui/react';

import ContentInner from './ContentInner';
import Context from './Context';

const Content = forwardRef<
  ComponentRef<typeof ContentInner>,
  PropsWithoutRef<ContentProps>
>((props, ref) => {
  const { context, isOpen } = useContext(Context);

  return (
    <FloatingPortal>
      {isOpen && (
        <FloatingOverlay
          className='z-50 flex items-center justify-center bg-gray-500 bg-opacity-20 backdrop-blur-sm'
          lockScroll
        >
          <FloatingFocusManager context={context}>
            <ContentInner ref={ref} {...props} />
          </FloatingFocusManager>
        </FloatingOverlay>
      )}
    </FloatingPortal>
  );
});

Content.displayName = 'DialogContent';

export default Content;
