import type { ContentInnerProps } from './types';

import { forwardRef, useContext, useRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { twMerge } from 'tailwind-merge';

import { Close } from '../Icons';
import Context from './Context';

const ContentInner = forwardRef<HTMLDivElement, ContentInnerProps>(
  ({ children, className, style, ...rest }, propRef) => {
    const { close, getFloatingProps, refs, showCloseButton } =
      useContext(Context);
    const container = useRef<HTMLDivElement>(null!);
    const ref = useMergeRefs([refs.setFloating, container, propRef]);

    return (
      <div
        ref={ref}
        className={twMerge(
          'relative mx-4 w-full max-w-2xl rounded-lg bg-white p-4 shadow-xl transition-[top] duration-300 dark:bg-gray-700',
          className,
        )}
        style={style}
        {...getFloatingProps(rest)}
      >
        {showCloseButton && (
          <button
            aria-label='Close'
            className='absolute right-1 top-1 flex h-10 w-10 items-center justify-center text-gray-600 outline-0 ring-0 hover:text-gray-900 focus:border-none dark:text-gray-300'
            onClick={close}
            type='button'
          >
            <Close />
          </button>
        )}
        {children}
      </div>
    );
  },
);

ContentInner.displayName = 'ContentInner';

export default ContentInner;
