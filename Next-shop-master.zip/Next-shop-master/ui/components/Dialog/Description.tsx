import type { ComponentRef, ElementType, ForwardedRef, JSX } from 'react';
import type { DescriptionProps } from './types';

import { createElement, forwardRef } from 'react';
import { twMerge } from 'tailwind-merge';

const Description = forwardRef(
  <T extends ElementType>(
    { as = 'p' as T, className, ...rest }: DescriptionProps<T>,
    ref: ForwardedRef<ComponentRef<T>>,
  ) =>
    createElement(as, {
      ref,
      className: twMerge('mb-3 text-gray-600', className),
      ...rest,
    }),
) as <T extends ElementType = 'p'>(props: DescriptionProps<T>) => JSX.Element;

//@ts-expect-error -- displayName
Description.displayName = 'DialogDescription';

export default Description;
