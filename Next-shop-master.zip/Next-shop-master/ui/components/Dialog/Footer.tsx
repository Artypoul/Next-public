import type { ComponentRef, ElementType, ForwardedRef, JSX } from 'react';
import type { FooterProps } from './types';

import { createElement, forwardRef } from 'react';
import { twMerge } from 'tailwind-merge';

const Footer = forwardRef(
  <T extends ElementType>(
    { as = 'div' as T, className, ...rest }: FooterProps<T>,
    ref: ForwardedRef<ComponentRef<T>>,
  ) =>
    createElement(as, {
      ref,
      className: twMerge('mt-3 flex flex-wrap justify-end', className),
      ...rest,
    }),
) as <T extends ElementType = 'div'>(props: FooterProps<T>) => JSX.Element;

//@ts-expect-error -- displayName
Footer.displayName = 'DialogFooter';

export default Footer;
