import type { ComponentRef, ElementType, ForwardedRef, JSX } from 'react';
import type { HeaderProps } from './types';

import { createElement, forwardRef } from 'react';
import { twMerge } from 'tailwind-merge';

const Header = forwardRef(
  <T extends ElementType>(
    { as = 'h2' as T, className, ...rest }: HeaderProps<T>,
    ref: ForwardedRef<ComponentRef<T>>,
  ) =>
    createElement(as, {
      ref,
      className: twMerge('mb-3 psb-font-title-medium pr-8', className),
      ...rest,
    }),
) as <T extends ElementType = 'h2'>(props: HeaderProps<T>) => JSX.Element;

//@ts-expect-error -- displayName
Header.displayName = 'DialogHeader';

export default Header;
