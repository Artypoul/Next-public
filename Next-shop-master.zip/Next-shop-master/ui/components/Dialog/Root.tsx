'use client';

import type { RootProps } from './types';

import { JSX, useEffect, useMemo, useRef, useState } from 'react';
import {
  autoUpdate,
  flip,
  offset,
  shift,
  useClick,
  useDismiss,
  useFloating,
  useInteractions,
  useRole,
} from '@floating-ui/react';

import Context from './Context';

const Dialog = ({
  children,
  defaultIsOpen = false,
  showCloseButton = true,
  ...rest
}: RootProps): JSX.Element => {
  const [uncontrolledIsOpen, setUncontrolledIsOpen] = useState(defaultIsOpen);
  const mounted = useRef(true);

  useEffect(() => {
    if (!mounted.current) {
      setUncontrolledIsOpen(defaultIsOpen);
    }
  }, [defaultIsOpen]);

  const isOpen = rest.isOpen ?? uncontrolledIsOpen;
  const onToggle = rest.onToggle ?? setUncontrolledIsOpen;

  const floating = useFloating({
    middleware: [offset(3), flip(), shift()],
    open: isOpen,
    onOpenChange: onToggle,
    whileElementsMounted: autoUpdate,
  });

  const { context } = floating;

  const click = useClick(context);
  const dismiss = useDismiss(context, { outsidePressEvent: 'mousedown' });
  const role = useRole(context);

  const interactions = useInteractions([click, dismiss, role]);

  const contextValue = useMemo(
    () => ({
      close: () => onToggle(false),
      showCloseButton,
      isOpen,
      ...floating,
      ...interactions,
    }),
    [floating, interactions, isOpen, onToggle, showCloseButton],
  );

  useEffect(() => {
    mounted.current = false;
  }, []);

  return <Context.Provider value={contextValue}>{children}</Context.Provider>;
};

export default Dialog;
