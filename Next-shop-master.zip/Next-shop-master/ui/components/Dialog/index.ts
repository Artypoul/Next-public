export { default as Dialog } from './Root';
export { default as DialogContent } from './Content';
export { default as DialogDescription } from './Description';
export { default as DialogHeader } from './Header';
export { default as DialogFooter } from './Footer';
export { default as DialogTrigger } from './Trigger';

export type {
  RootProps as DialogProps,
  ContentProps as DialogContentProps,
  DescriptionProps as DialogDescriptionProps,
  HeaderProps as DialogHeaderProps,
  FooterProps as DialogFooterProps,
  TriggerProps as DialogTriggerProps,
} from './types';
