import type { UseFloatingReturn } from '@floating-ui/react';
import type { ComponentProps, ElementType, ReactNode } from 'react';

import { useInteractions } from '@floating-ui/react';

type GenericComponentProps<T extends ElementType, P = object> = {
  as?: T;
} & P &
  Omit<ComponentProps<T>, keyof P>;

export type RootProps = {
  children: ReactNode;
  defaultIsOpen?: boolean;
  isOpen?: boolean;
  showCloseButton?: boolean;
  onToggle?(isOpen: boolean): void;
};

export type ContentProps = GenericComponentProps<
  'div',
  { children: ReactNode }
>;

export type DescriptionProps<T extends ElementType> = GenericComponentProps<
  T,
  { children?: ReactNode }
>;

export type HeaderProps<T extends ElementType> = GenericComponentProps<
  T,
  { children?: ReactNode }
>;

export type FooterProps<T extends ElementType> = GenericComponentProps<
  T,
  { children?: ReactNode }
>;

export type TriggerProps<T extends ElementType> = GenericComponentProps<T>;

export type ContentInnerProps = GenericComponentProps<
  'div',
  { children?: ReactNode }
>;

export type ContextType = {
  close(): void;
  isOpen: boolean;
  showCloseButton: boolean;
} & UseFloatingReturn &
  ReturnType<typeof useInteractions>;
