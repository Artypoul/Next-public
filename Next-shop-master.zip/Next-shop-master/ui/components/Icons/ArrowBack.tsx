import { SVGProps } from 'react';

export function ArrowBack(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='18'
      height='16'
      viewBox='0 0 18 16'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M17.25 8H0.75M0.75 8L7.5 1.25M0.75 8L7.5 14.75'
        stroke='currentColor'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
