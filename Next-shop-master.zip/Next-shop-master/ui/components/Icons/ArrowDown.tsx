import { SVGProps } from 'react';

export function ArrowDown(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='14'
      height='7'
      viewBox='0 0 14 7'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M1.16858 0.682495L6.05858 5.5725C6.63608 6.15 7.58108 6.15 8.15858 5.5725L13.0486 0.682495'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
