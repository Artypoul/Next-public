import { SVGProps } from 'react';

export function ArrowLeft(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='7'
      height='14'
      viewBox='0 0 7 14'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M6.31738 1.05994L1.42738 5.94994C0.849883 6.52744 0.849883 7.47244 1.42738 8.04994L6.31738 12.9399'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
