import { SVGProps } from 'react';

export function ArrowRight(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='7'
      height='14'
      viewBox='0 0 7 14'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M0.682617 12.9401L5.57262 8.05006C6.15012 7.47256 6.15012 6.52756 5.57262 5.95006L0.682617 1.06006'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
