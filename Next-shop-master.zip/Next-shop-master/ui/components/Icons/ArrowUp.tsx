import { SVGProps } from 'react';

export function ArrowUp(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='14'
      height='7'
      viewBox='0 0 14 7'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M12.9401 6.3175L8.05006 1.4275C7.47256 0.849997 6.52756 0.849997 5.95006 1.4275L1.06006 6.3175'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
