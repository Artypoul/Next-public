import { SVGProps } from 'react';

export function Bag(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='22'
      height='24'
      viewBox='0 0 22 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M14.78 8.22004V5.07004C14.78 2.9824 13.0876 1.29004 11 1.29004C8.91235 1.29004 7.21998 2.9824 7.21998 5.07004V8.22004M3.36362 22.71H18.6363C19.9859 22.71 21.08 21.6363 21.08 20.3118L19.5145 7.59001C19.5145 6.26551 18.4205 5.19179 17.0709 5.19179H4.62362C3.27404 5.19179 2.17998 6.26551 2.17998 7.59001L0.919983 20.3118C0.919983 21.6363 2.01404 22.71 3.36362 22.71Z'
        stroke='currentColor'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
