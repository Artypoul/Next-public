import { SVGProps } from 'react';

export function Category(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='16'
      height='17'
      viewBox='0 0 16 17'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M11.5 7.1H12.9C14.3 7.1 15 6.4 15 5V3.6C15 2.2 14.3 1.5 12.9 1.5H11.5C10.1 1.5 9.4 2.2 9.4 3.6V5C9.4 6.4 10.1 7.1 11.5 7.1Z'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M3.1 15.5H4.5C5.9 15.5 6.6 14.8 6.6 13.4V12C6.6 10.6 5.9 9.9 4.5 9.9H3.1C1.7 9.9 1 10.6 1 12V13.4C1 14.8 1.7 15.5 3.1 15.5Z'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M3.8 7.1C5.3464 7.1 6.6 5.8464 6.6 4.3C6.6 2.7536 5.3464 1.5 3.8 1.5C2.2536 1.5 1 2.7536 1 4.3C1 5.8464 2.2536 7.1 3.8 7.1Z'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M12.2 15.5C13.7464 15.5 15 14.2464 15 12.7C15 11.1536 13.7464 9.9 12.2 9.9C10.6536 9.9 9.4 11.1536 9.4 12.7C9.4 14.2464 10.6536 15.5 12.2 15.5Z'
        stroke='currentColor'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
