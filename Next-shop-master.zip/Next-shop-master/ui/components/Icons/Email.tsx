import { SVGProps } from 'react';

export function Email(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='24'
      height='19'
      viewBox='0 0 24 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        fillRule='evenodd'
        clipRule='evenodd'
        d='M4.3 1H19.7C21.5225 1 23 2.42709 23 4.1875V14.8125C23 16.5729 21.5225 18 19.7 18H4.3C2.47746 18 1 16.5729 1 14.8125V4.1875C1 2.42709 2.47746 1 4.3 1ZM12.55 7.87437L19.7 3.125H4.3L11.45 7.87437C11.7903 8.06417 12.2097 8.06417 12.55 7.87437Z'
        stroke='currentColor'
        strokeWidth='1'
      />
    </svg>
  );
}
