import { SVGProps } from 'react';

export function Filter(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='18'
      height='19'
      viewBox='0 0 18 19'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M10.5 4.25V5.75C10.5 7.25 11.25 8 12.75 8H14.25C15.75 8 16.5 7.25 16.5 5.75V4.25C16.5 2.75 15.75 2 14.25 2L12.75 2C11.25 2 10.5 2.75 10.5 4.25Z'
        stroke='currentColor'
        strokeOpacity='0.5'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M10.5 13.25V14.75C10.5 16.25 11.25 17 12.75 17H14.25C15.75 17 16.5 16.25 16.5 14.75V13.25C16.5 11.75 15.75 11 14.25 11H12.75C11.25 11 10.5 11.75 10.5 13.25Z'
        stroke='currentColor'
        strokeOpacity='0.5'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M1.5 13.25V14.75C1.5 16.25 2.25 17 3.75 17H5.25C6.75 17 7.5 16.25 7.5 14.75V13.25C7.5 11.75 6.75 11 5.25 11H3.75C2.25 11 1.5 11.75 1.5 13.25Z'
        stroke='currentColor'
        strokeOpacity='0.5'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M1.5 4.25V5.75C1.5 7.25 2.25 8 3.75 8H5.25C6.75 8 7.5 7.25 7.5 5.75V4.25C7.5 2.75 6.75 2 5.25 2L3.75 2C2.25 2 1.5 2.75 1.5 4.25Z'
        stroke='currentColor'
        strokeOpacity='0.5'
        strokeMiterlimit='10'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
