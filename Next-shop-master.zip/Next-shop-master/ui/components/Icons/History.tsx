import { SVGProps } from 'react';

export function History(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns='http://www.w3.org/2000/svg'
      width='24'
      height='24'
      viewBox='0 0 24 24'
      {...props}
    >
      <path
        fill='currentColor'
        d='M4.993 6.352A1.5 1.5 0 0 0 2 6.5v4A1.5 1.5 0 0 0 3.5 12h4a1.5 1.5 0 0 0 0-3h-.698a6 6 0 1 1 .397 6.6 1.5 1.5 0 0 0-2.398 1.802 9 9 0 1 0 .192-11.05'
      ></path>
      <path
        fill='currentColor'
        d='M12 8a1 1 0 0 1 1 1v2.586l1.707 1.707a1 1 0 0 1-1.414 1.414l-2-2A1 1 0 0 1 11 12V9a1 1 0 0 1 1-1'
      ></path>
    </svg>
  );
}
