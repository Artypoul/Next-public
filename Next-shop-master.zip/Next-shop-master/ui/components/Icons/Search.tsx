import { SVGProps } from 'react';

export function Search(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='14'
      height='15'
      viewBox='0 0 14 15'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M10.8037 11.28L13.4086 13.8M12.5686 7.08001C12.5686 10.3274 9.93603 12.96 6.68859 12.96C3.44116 12.96 0.808594 10.3274 0.808594 7.08001C0.808594 3.83258 3.44116 1.20001 6.68859 1.20001C9.93603 1.20001 12.5686 3.83258 12.5686 7.08001Z'
        stroke='currentColor'
        strokeLinecap='round'
      />
    </svg>
  );
}
