import { SVGProps } from 'react';

export function Settings(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      width='20'
      height='21'
      viewBox='0 0 20 21'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      {...props}
    >
      <path
        d='M1 7.60998V13.38C1 15.5 1 15.5 3 16.85L8.5 20.03C9.33 20.51 10.68 20.51 11.5 20.03L17 16.85C19 15.5 19 15.5 19 13.39V7.60998C19 5.49998 19 5.49999 17 4.14999L11.5 0.969985C10.68 0.489985 9.33 0.489985 8.5 0.969985L3 4.14999C1 5.49999 1 5.49998 1 7.60998Z'
        stroke='currentColor'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
      <path
        d='M10 13.5C11.6569 13.5 13 12.1568 13 10.5C13 8.84313 11.6569 7.49999 10 7.49999C8.34315 7.49999 7 8.84313 7 10.5C7 12.1568 8.34315 13.5 10 13.5Z'
        stroke='currentColor'
        strokeLinecap='round'
        strokeLinejoin='round'
      />
    </svg>
  );
}
