'use client';

import type {
  ClipboardEventHandler,
  FocusEventHandler,
  InputHTMLAttributes,
} from 'react';

import { forwardRef, useId, useState } from 'react';
import { twJoin, twMerge } from 'tailwind-merge';

type InputProps = {
  /**
   * Block ability to past any text from a clipboard
   */
  disablePaste?: boolean;
  /**
   * Mark input as invalid
   */
  isInvalid?: boolean;
} & InputHTMLAttributes<HTMLInputElement>;

const Input = forwardRef<HTMLInputElement, InputProps>((props, ref) => {
  const {
    disablePaste = false,
    isInvalid = false,
    className,
    onFocus: propOnFocus = () => void 0,
    onBlur: propOnBlur = () => void 0,
    onPaste: propOnPaste = () => void 0,
    onChange: propOnСhange,
    type = 'text',
    placeholder = '',
    value: propValue,
    defaultValue = '',
    disabled,
    ...rest
  } = props;

  const [uncontrolledValue, setUncontrolledValue] = useState(defaultValue);

  const inputValue = propValue ?? uncontrolledValue;

  const id = useId();

  const onFocus: FocusEventHandler<HTMLInputElement> = e => {
    propOnFocus(e);
  };

  const onBlur: FocusEventHandler<HTMLInputElement> = e => {
    propOnBlur(e);
  };

  const onPaste: ClipboardEventHandler<HTMLInputElement> = e => {
    if (disablePaste) {
      e.preventDefault();
    }
    propOnPaste(e);
  };

  const onChange: React.ChangeEventHandler<HTMLInputElement> = e => {
    if (propOnСhange) {
      propOnСhange(e);
    } else {
      setUncontrolledValue(e.target.value);
    }
  };

  const inputClassName = twMerge(
    twJoin(
      'focus:placeholder:text-transparent focus:ring-0 focus:outline-none w-full rounded bg-white dark:bg-input-bg box-border border-black/50 border-b dark:border-white/50 dark:placeholder:text-white/50 px-[14px] text-xl',
      isInvalid && 'border-error focus:border-error',
      disabled && 'text-gray-400',
    ),
    className,
  );

  return (
    <div className='relative'>
      <input
        aria-invalid={isInvalid}
        className={inputClassName}
        disabled={disabled}
        id={rest.id || id}
        onBlur={onBlur}
        onChange={onChange}
        onFocus={onFocus}
        onPaste={onPaste}
        placeholder={placeholder}
        ref={ref}
        type={type}
        value={inputValue}
        {...rest}
      />
    </div>
  );
});

Input.displayName = 'Input';

export { Input };
export type { InputProps };
