'use client';

import type { ComponentRef } from 'react';
import type {
  NumberFormatValues,
  NumericFormatProps,
  OnValueChange,
} from 'react-number-format';
import type { InputProps } from './Input';

import { forwardRef, useState } from 'react';
import { NumericFormat } from 'react-number-format';

import { Input } from './Input';

type NumberInputProps = {
  onValueChange?(value: number | string): void;
  use?: keyof NumberFormatValues;
  isInvalid?: boolean;
  className?: string;
} & Omit<
  NumericFormatProps<InputProps>,
  'customInput' | 'getInputRef' | 'onValueChange'
>;

const NumberInput = forwardRef<ComponentRef<typeof Input>, NumberInputProps>(
  (props, ref) => {
    const {
      onValueChange: propOnСhange,
      defaultValue,
      value: propValue,
      use = 'floatValue',
      className = '',
      isInvalid = false,
      allowedDecimalSeparators = ['.', ','],
      ...rest
    } = props;

    const [uncontrolledValue, setUncontrolledValue] = useState(defaultValue);

    const inputValue = propValue ?? uncontrolledValue;

    const onChange: OnValueChange = values => {
      if (propOnСhange) {
        propOnСhange(values[use] || '');
      } else {
        setUncontrolledValue(values[use] || '');
      }
    };

    return (
      <NumericFormat
        allowedDecimalSeparators={allowedDecimalSeparators}
        className={className}
        customInput={Input}
        isInvalid={isInvalid}
        getInputRef={ref}
        onValueChange={onChange}
        {...rest}
        value={inputValue}
        inputMode='numeric'
      />
    );
  },
);

NumberInput.displayName = 'NumberInput';

export { NumberInput };
export type { NumberInputProps };
