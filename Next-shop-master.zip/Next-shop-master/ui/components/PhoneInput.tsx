'use client';

import type { ComponentRef, FocusEventHandler } from 'react';
import type { OnValueChange, PatternFormatProps } from 'react-number-format';
import type { InputProps } from './Input';

import { forwardRef, useCallback, useState } from 'react';
import { NumberFormatBase, usePatternFormat } from 'react-number-format';

import { Input } from './Input';

type PhoneInputProps = {
  errorClassName?: string;
  onValueChange?: (value: string) => void;
} & Omit<
  PatternFormatProps<InputProps>,
  | 'customInput'
  | 'format'
  | 'getInputRef'
  | 'onValueChange'
  | 'trimOnBlur'
  | 'sanitizeOnBlur'
  | 'disablePaste'
  | 'allowEmptyFormatting'
  | 'patternChar'
>;

const PHONE_LENGTH = 10;
export const phoneFormatString = '+7 (###) ### ## ##';
const normalizePhone = (phoneNumber: string): string => {
  if (phoneNumber.length <= PHONE_LENGTH) {
    return phoneNumber;
  }

  if (phoneNumber.startsWith('7') || phoneNumber.startsWith('8')) {
    return phoneNumber.slice(1, 11);
  }

  return phoneNumber.slice(0, 10);
};

const leaveOnlyNumbersInString = (stringWithNumbers: string): string => {
  return stringWithNumbers.replace(/\D/gm, '');
};

const PhoneInput = forwardRef<ComponentRef<typeof Input>, PhoneInputProps>(
  (props, propRef) => {
    const {
      mask = '_',
      onValueChange,
      onBlur: propOnBlur = () => void 0,
      onFocus: propOnFocus = () => void 0,
      value: controlledValue,
      ...rest
    } = props;

    const [value, setValue] = useState('');
    const [focus, setFocus] = useState(false);

    const isControlled = !!onValueChange;

    const _onFocus: FocusEventHandler<HTMLInputElement> = e => {
      setFocus(true);
      propOnFocus(e);
    };

    const _onBlur: FocusEventHandler<HTMLInputElement> = e => {
      setFocus(false);
      propOnBlur(e);
    };

    const _onPaste: React.ClipboardEventHandler<HTMLInputElement> = e => {
      const pastedText = leaveOnlyNumbersInString(
        e.clipboardData.getData('Text'),
      );

      if (pastedText.length < PHONE_LENGTH) {
        return;
      }

      const normalized = normalizePhone(pastedText);

      if (!isControlled) {
        setValue(normalized);
      } else {
        onValueChange(normalized);
      }
    };

    const _onValueChange: OnValueChange = values => {
      const val = values.formattedValue !== '+7 (' ? values.value : '';

      if (!isControlled) {
        setValue(val);
      } else {
        onValueChange(val);
      }
    };

    const { format, ...formatProps } = usePatternFormat({
      ...rest,
      value: isControlled ? controlledValue : value,
      getInputRef: propRef,
      customInput: Input,
      mask,
      format: phoneFormatString,
      placeholder: '+7 (000) 00 00 00',
      valueIsNumericString: true,
      onFocus: _onFocus,
      onBlur: _onBlur,
      onPaste: _onPaste,
      onValueChange: _onValueChange,
    });

    const _format = useCallback(
      (val: string): string => {
        if (!val && !focus) return '';
        if (!val && focus) return '+7 (';

        let phone = leaveOnlyNumbersInString(val);
        phone = normalizePhone(val);
        return format?.(phone) || '';
      },
      [focus, format],
    );

    return <NumberFormatBase format={_format} {...formatProps} />;
  },
);

PhoneInput.displayName = 'PhoneInput';

export { PhoneInput };
export type { PhoneInputProps };
