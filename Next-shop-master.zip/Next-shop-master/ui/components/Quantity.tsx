'use client';

import { twMerge } from 'tailwind-merge';

type QuantityProps = {
  quantity: number;
  maxCount?: number;
  onDecrease: () => void;
  onIncrease: () => void;
  className?: string;
};

const Quantity = ({
  quantity = 0,
  maxCount = Infinity,
  className = '',
  onDecrease,
  onIncrease,
}: QuantityProps) => {
  return (
    <div>
      <div
        className={twMerge(
          'mt-2 rounded-[44px] bg-input-bg/25 text-lg font-medium',
          className,
        )}
      >
        <div className='flex items-center'>
          <button
            type='button'
            className='h-[42px] w-[35px] font-semibold text-black/50 duration-300 hover:text-black'
            onClick={onDecrease}
          >
            -
          </button>
          <div className='h-6 w-px' />
          <div className='min-w-7 text-center'>{quantity}</div>
          <div className='h-6 w-px' />
          <button
            type='button'
            className='h-[42px] w-[35px] font-semibold text-black/50 duration-300 hover:text-black'
            disabled={!!maxCount && quantity >= maxCount}
            onClick={onIncrease}
          >
            +
          </button>
        </div>
      </div>
    </div>
  );
};

export { Quantity };
export type { QuantityProps };
