'use client';

import type { ComponentRef, JSX } from 'react';
import type {
  GroupBase,
  MultiValue,
  OnChangeValue,
  PropsValue,
  Props as ReactSelectProps,
  SingleValue,
} from 'react-select';

import { forwardRef, useId } from 'react';
import ReactSelect from 'react-select';
import { twJoin, twMerge } from 'tailwind-merge';

type SelectProps<
  Option,
  IsMulti extends boolean = false,
  Group extends GroupBase<Option> = GroupBase<Option>,
> = {
  isInvalid?: boolean;
} & Omit<
  ReactSelectProps<Option, IsMulti, Group>,
  'classNames' | 'components' | 'unstyled'
>;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type OptionType = Record<string, any>;

const Select = forwardRef<
  ComponentRef<typeof ReactSelect<OptionType, boolean, GroupBase<OptionType>>>,
  SelectProps<OptionType, boolean, GroupBase<OptionType>>
>((props, ref) => {
  const { isInvalid = false, className, placeholder = '', ...rest } = props;

  const id = useId();

  return (
    <ReactSelect
      classNames={{
        control: ({ isDisabled }) =>
          twMerge(
            twJoin(
              'border border-gold !min-h-[40px] text-sm focus:placeholder:text-transparent focus:ring-0 focus:outline-none w-full rounded bg-white dark:bg-input-bg dark:placeholder:text-white/50 px-[14px]',
              isInvalid && 'border-error focus:border-error',
              isDisabled && 'opacity-50',
            ),
            className,
          ),
        menuList: () =>
          'bg-white shadow-lg select-none psb-font-title-large my-[5px] dark:bg-black',
        menuPortal: () => '!z-50',
        option: ({ isFocused, isDisabled }) =>
          twJoin(
            'px-[14px] py-[10px] border-b border-black/50 dark:border-white/50 last:border-0 !cursor-pointer',
            isFocused && !isDisabled && '!text-white dark:!text-black bg-gold',
            !isDisabled && 'hover:text-gray-400',
          ),
        indicatorSeparator: () => twJoin('hidden'),
        loadingIndicator: () =>
          twJoin('absolute inset-y-0 right-8 flex items-center'),
        dropdownIndicator: () =>
          twJoin('absolute inset-y-0 right-4 flex items-center'),
        multiValue: () => twJoin('psb-font-title-large'),
        multiValueLabel: () => 'relative top-px',
        clearIndicator: () =>
          twJoin(
            'absolute inset-y-0 right-10 flex items-center cursor-pointer mt-[4px]',
          ),
      }}
      instanceId={id}
      isClearable={false}
      isInvalid={isInvalid}
      maxMenuHeight={276}
      placeholder={placeholder}
      ref={ref}
      unstyled
      menuPortalTarget={
        typeof document !== 'undefined' ? document.body : undefined
      }
      {...rest}
    />
  );
}) as <T extends OptionType, M extends boolean>(
  props: SelectProps<T, M, GroupBase<T>>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
Select.displayName = 'Select';

export { Select };
export type {
  SelectProps,
  SingleValue as SelectSingleValue,
  MultiValue as SelectMultiValue,
  PropsValue as SelectPropsValue,
  GroupBase as SelectPropsGroupBase,
  OnChangeValue as SelectOnChangeValue,
};
