export function Shimmer() {
  return (
    <div className='absolute inset-0 isolate z-10 bg-black/10 before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_1s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/70 before:to-transparent dark:before:via-white/10' />
  );
}
