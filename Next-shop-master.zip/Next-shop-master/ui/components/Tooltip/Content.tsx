'use client';

import type { ContentProps } from './types';

import { forwardRef, useContext } from 'react';
import { FloatingPortal, useMergeRefs } from '@floating-ui/react';
import { twMerge } from 'tailwind-merge';

import Context from './Context';
import { getArrowStyle } from './utils';

const Content = forwardRef<HTMLDivElement, ContentProps>(
  ({ children, className, ...rest }, propRef) => {
    const {
      arrowRef,
      getFloatingProps,
      isOpen,
      middlewareData: { arrow },
      placement,
      refs,
      strategy,
      x,
      y,
    } = useContext(Context);
    const ref = useMergeRefs([refs.setFloating, propRef]);

    return (
      <FloatingPortal>
        {!!isOpen && (
          <div
            className={twMerge(
              'border-gray group z-[1000] rounded-lg border bg-white p-2 shadow-lg data-[placement^=bottom]:mt-[11px] data-[placement^=left]:-ml-[11px] data-[placement^=right]:ml-[11px] data-[placement^=top]:-mt-[11px]',
              className,
            )}
            data-placement={placement}
            ref={ref}
            style={{
              left: x,
              position: strategy,
              top: y,
              ...rest.style,
            }}
            {...getFloatingProps(rest)}
          >
            {children}
            <div
              className='-z-1 absolute h-[16px] w-[16px] border-l border-t border-inherit bg-inherit group-[[data-placement^=bottom]]:-top-[9px] group-[[data-placement^=left]]:-right-[9px] group-[[data-placement^=right]]:-left-[9px] group-[[data-placement^=top]]:-bottom-[9px] group-[[data-placement^=bottom]]:rotate-45 group-[[data-placement^=left]]:rotate-[135deg] group-[[data-placement^=right]]:-rotate-45 group-[[data-placement^=top]]:rotate-[225deg]'
              ref={arrowRef}
              style={getArrowStyle(arrow, placement)}
            />
          </div>
        )}
      </FloatingPortal>
    );
  },
);

Content.displayName = 'TooltipContent';

export default Content;
