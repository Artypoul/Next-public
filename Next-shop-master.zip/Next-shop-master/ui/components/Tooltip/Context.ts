'use client';

import type { ContextType } from './types';

import { createContext } from 'react';

export default createContext<ContextType>({} as ContextType);
