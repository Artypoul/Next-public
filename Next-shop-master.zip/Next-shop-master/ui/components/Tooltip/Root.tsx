'use client';

import type { JSX } from 'react';
import type { ContextType, RootProps } from './types';

import { useMemo, useRef, useState } from 'react';
import {
  arrow,
  autoUpdate,
  flip,
  offset,
  shift,
  useClick,
  useDismiss,
  useFloating,
  useFocus,
  useHover,
  useInteractions,
  useRole,
} from '@floating-ui/react';

import Context from './Context';

const Tooltip = ({
  children,
  isClickable = true,
  defaultIsOpen = false,
  isFocusable = true,
  isHoverable = true,
  placement = 'bottom',
  ...rest
}: RootProps): JSX.Element => {
  const [uncontrolledIsOpen, setUncontrolledIsOpen] = useState(defaultIsOpen);

  const arrowRef = useRef(null);

  const isOpen = rest.isOpen ?? uncontrolledIsOpen;
  const onToggle = rest.onToggle ?? setUncontrolledIsOpen;

  const floating = useFloating({
    middleware: [
      offset(5),
      flip({
        crossAxis: placement.includes('-'),
        fallbackAxisSideDirection: 'start',
        padding: 5,
      }),
      shift({ padding: 5 }),
      arrow({ element: arrowRef }),
    ],
    open: isOpen,
    onOpenChange: onToggle,
    placement,
    whileElementsMounted: autoUpdate,
  });

  const { context } = floating;

  const click = useClick(context, { enabled: isClickable });
  const hover = useHover(context, { enabled: isHoverable, move: true });
  const focus = useFocus(context, { enabled: isFocusable });
  const dismiss = useDismiss(context);
  const role = useRole(context, { role: 'tooltip' });

  const interactions = useInteractions([click, hover, focus, dismiss, role]);

  const contextValue = useMemo<ContextType>(
    () => ({
      arrowRef,
      isOpen,
      ...floating,
      ...interactions,
    }),
    [floating, interactions, isOpen],
  );

  return <Context.Provider value={contextValue}>{children}</Context.Provider>;
};

export default Tooltip;
