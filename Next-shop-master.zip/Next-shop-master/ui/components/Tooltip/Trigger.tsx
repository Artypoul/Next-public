'use client';

import type { ComponentRef, ElementType, ForwardedRef, JSX, Ref } from 'react';
import type { TriggerProps } from './types';

import { createElement, forwardRef, useContext } from 'react';
import { useMergeRefs } from '@floating-ui/react';

import Context from './Context';

const Trigger = forwardRef(
  <T extends ElementType>(
    { as = 'div' as T, ...rest }: TriggerProps<T>,
    propRef: ForwardedRef<ComponentRef<T>>,
  ) => {
    const { getReferenceProps, refs } = useContext(Context);
    const ref = useMergeRefs([refs.setReference, propRef] as Ref<
      ComponentRef<T>
    >[]);

    return createElement(as, { ref, ...getReferenceProps(rest) });
  },
) as <T extends ElementType = 'div'>(props: TriggerProps<T>) => JSX.Element;

//@ts-expect-error -- !
Trigger.displayName = 'TooltipTrigger';

export default Trigger;
