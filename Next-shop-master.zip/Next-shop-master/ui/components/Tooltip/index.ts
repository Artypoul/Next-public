export { default as Tooltip } from './Root';
export { default as TooltipContent } from './Content';
export { default as TooltipTrigger } from './Trigger';

export type {
  RootProps as TooltipProps,
  ContentProps as TooltipContentProps,
  TriggerProps as TooltipTriggerProps,
} from './types';
