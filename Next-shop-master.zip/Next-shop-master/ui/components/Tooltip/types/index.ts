import type {
  Placement,
  UseFloatingReturn,
  useInteractions,
} from '@floating-ui/react';
import type { ComponentProps, ElementType, ReactNode, Ref } from 'react';

type GenericComponentProps<T extends ElementType, P = object> = {
  as?: T;
} & P &
  Omit<ComponentProps<T>, keyof P>;

export interface RootProps {
  children: ReactNode;
  defaultIsOpen?: boolean;
  isClickable?: boolean;
  isFocusable?: boolean;
  isHoverable?: boolean;
  isOpen?: boolean;
  onToggle?: (open: boolean) => void;
  placement?: Placement;
}

export type ContentProps = GenericComponentProps<
  'div',
  { children: ReactNode }
>;

export type TriggerProps<T extends ElementType> = GenericComponentProps<T>;

export type ContextType = {
  arrowRef: Ref<HTMLDivElement>;
  isOpen: boolean;
} & UseFloatingReturn &
  ReturnType<typeof useInteractions>;
