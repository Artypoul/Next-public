import type { MiddlewareData, Placement } from '@floating-ui/react';
import type { CSSProperties } from 'react';

export const getArrowStyle = (
  arrow: MiddlewareData['arrow'],
  placement: Placement,
): CSSProperties => {
  const side = placement.split('-')[0];
  const arrowOffset = -10 * Math.sign(arrow?.centerOffset ?? 0);

  return side === 'top' || side === 'bottom'
    ? { left: (arrow?.x ?? 0) + arrowOffset }
    : { top: (arrow?.y ?? 0) + arrowOffset };
};
