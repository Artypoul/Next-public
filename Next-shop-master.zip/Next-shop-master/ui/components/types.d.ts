/* eslint-disable */
import type {} from 'react-select/base';

//import type { GroupBase } from "react-select";
// This import is necessary for module augmentation.
// It allows us to extend the 'Props' interface in the 'react-select/base' module
// and add our custom property 'label' and isInvalid to it.
interface RefObject<T> {
  readonly current: T | null;
}
type RefCallback<T> = {
  bivarianceHack: (instance: T | null) => void;
}['bivarianceHack'];
type Ref<T> = RefCallback<T> | RefObject<T> | null;

interface GroupBase<Option> {
  readonly options: readonly Option[];
  readonly label?: string;
}

declare module 'react-select/base' {
  export interface Props<
    Option,
    IsMulti extends boolean,
    Group extends GroupBase<Option> = GroupBase<Option>,
  > {
    isInvalid?: boolean;
    ref?: Ref<any> | undefined;
  }
}
