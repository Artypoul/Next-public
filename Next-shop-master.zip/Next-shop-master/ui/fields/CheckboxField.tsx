import type {
  ChangeEventHandler,
  ComponentRef,
  ForwardedRef,
  JSX,
  PropsWithoutRef,
} from 'react';
import type { FieldValues } from 'react-hook-form';
import type { CheckboxFieldProps } from './types';

import { forwardRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';

import { Checkbox } from '../components/Checkbox';

const CheckboxField = forwardRef(
  <Values extends FieldValues>(
    props: PropsWithoutRef<CheckboxFieldProps<Values>>,
    propRef: ForwardedRef<ComponentRef<typeof Checkbox>>,
  ) => {
    const {
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format,
      isDisabled = false,
      parse,
      showErrorMessage = true,
      ...rest
    } = props;

    const {
      field: { ref, onChange: fieldOnChange, onBlur, value, ...fieldProps },
      fieldState: { error },
    } = useController<Values>({
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
    });

    const formattedValue = format ? format(value) : value;

    const onChange: ChangeEventHandler<HTMLInputElement> = e => {
      fieldOnChange(parse ? parse(e.target.checked) : e.target.checked);
      onBlur();
    };

    const errorMessage = error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div>
        <Checkbox
          checked={Boolean(formattedValue)}
          disabled={isDisabled}
          onChange={onChange}
          ref={refCallback}
          {...rest}
          {...fieldProps}
        />
        {!!errorMessage && showErrorMessage && (
          <div className='mt-2 text-error'>{errorMessage}</div>
        )}
      </div>
    );
  },
) as <Values extends FieldValues>(
  props: CheckboxFieldProps<Values>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
CheckboxField.displayName = 'CheckboxField';

export { CheckboxField };
