import type { DadataAddress, Nullable } from '@/lib/gigma/types';
import type { KeyboardEventHandler } from 'react';
import type { FieldValues, Path, PathValue } from 'react-hook-form';
import type { SelectFieldProps } from '../fields/types';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useFormContext } from 'react-hook-form';

import { searchAddress } from '@/lib/gigma';

import { SelectAsyncField } from '../fields';

type DadataProps<FormValues extends FieldValues> = {
  initialValue?: string;
  disabled?: boolean;
} & SelectFieldProps<FormValues, DadataAddress>;

const DadataField = <FormValues extends FieldValues = FieldValues>({
  disabled = false,
  initialValue = '',
  name,
  control,
  ...rest
}: DadataProps<FormValues>) => {
  const [query, setQuery] = useState(initialValue);
  const [options, setOptions] = useState<DadataAddress[]>([]);
  const { watch, setValue } = useFormContext<FormValues>();

  const selected = watch(name as Path<FormValues>) as Nullable<DadataAddress>;
  const abort = useRef<AbortController | null>(null);

  const getDadata = useCallback(async (inputValue: string) => {
    setOptions([]);
    if (abort.current) abort.current.abort();
    if (!inputValue || inputValue?.length < 3) return [];

    const controller = new AbortController();
    abort.current = controller;

    try {
      const res = await searchAddress(inputValue, {
        signal: abort.current.signal,
      });

      if (!res) throw new Error('error');

      abort.current = null;

      setOptions(res.addresses ?? []);

      return res.addresses;
    } catch {
      return [];
    }
  }, []);

  const handleKeyDown: KeyboardEventHandler<HTMLDivElement> = e => {
    const target = e.target as HTMLInputElement;

    switch (e.key) {
      case 'Home': {
        e.preventDefault();
        if (e.shiftKey) target.selectionStart = 0;
        else target.setSelectionRange(0, 0);
        break;
      }
      case 'End': {
        e.preventDefault();
        const len = target.value.length;
        if (e.shiftKey) target.selectionEnd = len;
        else target.setSelectionRange(len, len);
        break;
      }
      case 'Backspace': {
        const { selectionStart, selectionEnd, value } = target;
        if (selectionStart === null || selectionEnd === null) return;
        if (selectionEnd - selectionStart === value.length) {
          setQuery('');
          setValue(name, null as PathValue<FormValues, Path<FormValues>>);
        }
      }
    }
  };

  useEffect(() => {
    if (initialValue) {
      getDadata(initialValue);
    } else {
      setQuery('');
    }
  }, [getDadata, initialValue]);

  return (
    <SelectAsyncField
      name={name}
      control={control}
      defaultOptions={options}
      isDisabled={disabled}
      loadOptions={getDadata}
      getOptionLabel={o => o.name}
      getOptionValue={o => o.value}
      formatOptionLabel={(data, { context }) => {
        if (context === 'value') {
          return data.name;
        } else {
          return (
            <div>
              {data.name}
              <div className='text-xs opacity-70'>{data.value}</div>
            </div>
          );
        }
      }}
      inputValue={query}
      onInputChange={newValue => {
        setQuery(newValue);
      }}
      onMenuOpen={() => {
        setQuery(selected?.name ?? query);
      }}
      onKeyDown={handleKeyDown}
      {...rest}
    />
  );
};

export { DadataField };
