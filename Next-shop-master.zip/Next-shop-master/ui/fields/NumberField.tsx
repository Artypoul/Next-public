import type { ComponentRef, ForwardedRef, JSX } from 'react';
import type { FieldValues } from 'react-hook-form';
import type { NumberFieldProps } from './types';

import { forwardRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';

import { NumberInput } from '../components/NumberInput';

const NumberField = forwardRef(
  <Values extends FieldValues>(
    props: NumberFieldProps<Values>,
    propRef: ForwardedRef<ComponentRef<typeof NumberInput>>,
  ) => {
    const {
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format = value => value,
      isDisabled = false,
      parse = value => value,
      ...rest
    } = props;

    const {
      field: { ref, onChange: fieldOnChange, value, ...fieldProps },
      fieldState: { error },
    } = useController<Values>({
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
    });

    const formattedValue = format ? format(value) : value;

    const onValueChange = (newValue: number | string) => {
      if (newValue !== formattedValue) {
        fieldOnChange(parse ? parse(newValue) : newValue);
      }
    };

    const errorMessage = error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div>
        <NumberInput
          disabled={isDisabled}
          isInvalid={!!error}
          onValueChange={onValueChange}
          ref={refCallback}
          value={formattedValue}
          allowNegative={false}
          decimalScale={2}
          thousandSeparator={' '}
          {...rest}
          {...fieldProps}
        />
        <div className='mt-2 text-error'>{errorMessage}</div>
      </div>
    );
  },
) as <Values extends FieldValues>(
  props: NumberFieldProps<Values>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
NumberField.displayName = 'NumberField';

export { NumberField };
