import type { ComponentRef, ForwardedRef, JSX } from 'react';
import type { FieldValues, Path, PathValue } from 'react-hook-form';
import type { PhoneFieldProps } from './types';

import { forwardRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';
import { usePatternFormat } from 'react-number-format';
import { twMerge } from 'tailwind-merge';

import { phoneFormatString, PhoneInput } from '../components/PhoneInput';

const PhoneField = forwardRef(
  <Values extends FieldValues>(
    props: PhoneFieldProps<Values>,
    propRef: ForwardedRef<ComponentRef<typeof PhoneInput>>,
  ) => {
    const {
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format,
      isDisabled = false,
      parse,
      errorClassName = '',
      ...rest
    } = props;

    const {
      field: { ref, onChange: fieldOnChange, value, ...fieldProps },
      fieldState: { error },
    } = useController<Values>({
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
    });

    const { format: formatPhone, removeFormatting } = usePatternFormat({
      format: phoneFormatString,
    });

    const numericValue = removeFormatting?.(value ?? '');

    const onChange = (val: string): void => {
      const formatFn = format || formatPhone;
      const formattedPhone =
        val.length === 10 && formatFn
          ? formatFn(val as PathValue<Values, Path<Values>>)
          : val;
      fieldOnChange(parse ? parse(formattedPhone) : formattedPhone);
    };

    const errorMessage = error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div>
        <PhoneInput
          disabled={isDisabled}
          inputMode='numeric'
          isInvalid={!!error}
          onValueChange={onChange}
          ref={refCallback}
          value={numericValue}
          {...rest}
          {...fieldProps}
        />
        <div className={twMerge('mt-2 text-error', errorClassName)}>
          {errorMessage}
        </div>
      </div>
    );
  },
) as <Values extends FieldValues>(
  props: PhoneFieldProps<Values>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
PhoneField.displayName = 'PhoneField';

export { PhoneField };
