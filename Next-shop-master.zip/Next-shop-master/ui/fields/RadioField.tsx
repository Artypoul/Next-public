import type { ComponentRef, ForwardedRef, JSX, PropsWithoutRef } from 'react';
import type { FieldValues } from 'react-hook-form';
import type { DataObject, RadioFieldProps } from './types';

import { forwardRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';
import { twMerge } from 'tailwind-merge';

import { Checkbox } from '../components/Checkbox';

type OptionProps = {
  name?: string;
  [key: string]: unknown;
};

const RadioField = forwardRef(
  <Values extends FieldValues, Option extends OptionProps>(
    props: PropsWithoutRef<RadioFieldProps<Values, Option>>,
    propRef: ForwardedRef<ComponentRef<typeof Checkbox>>,
  ) => {
    const {
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format,
      isDisabled = false,
      parse,
      showErrorMessage = true,
      options = [],
      className = '',
      ...rest
    } = props;

    const {
      field: { ref, onChange: fieldOnChange, value, ...fieldProps },
      fieldState: { error },
    } = useController<Values>({
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
    });

    const formattedValue = format ? format(value) : value;

    const onChange = (option: Option) => {
      fieldOnChange(parse ? parse(option) : option);
    };

    const errorMessage = error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div ref={refCallback}>
        <div className={twMerge('flex items-center gap-4', className)}>
          {options.map((option, index) => {
            const isCkecked =
              option?.code ===
              (typeof formattedValue === 'boolean'
                ? formattedValue
                : (formattedValue as DataObject)?.code);

            const label = option?.name;

            return (
              <Checkbox
                key={index}
                checked={isCkecked}
                disabled={isDisabled}
                onChange={() => onChange(option)}
                {...rest}
                {...fieldProps}
                label={label}
                type='radio'
              />
            );
          })}
        </div>

        {!!errorMessage && showErrorMessage && (
          <div className='mt-2 text-error'>{errorMessage}</div>
        )}
      </div>
    );
  },
) as <Values extends FieldValues, Option extends OptionProps>(
  props: RadioFieldProps<Values, Option>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
RadioField.displayName = 'RadioField';

export { RadioField };
