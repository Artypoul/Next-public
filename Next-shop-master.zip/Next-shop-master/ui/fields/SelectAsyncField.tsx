import type { ComponentRef, ForwardedRef, JSX } from 'react';
import type { FieldValues } from 'react-hook-form';
import type { SelectMultiValue, SelectSingleValue } from '../components/Select';
import type { SelectFieldAsyncProps } from './types';

import { forwardRef } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';

import { SelectAsync } from '../components/Select/async';

const SelectAsyncField = forwardRef(
  <
    Values extends FieldValues,
    Option extends Record<string, unknown>,
    IsMulti extends boolean,
  >(
    props: SelectFieldAsyncProps<Values, Option, boolean>,
    propRef: ForwardedRef<ComponentRef<typeof SelectAsync<Option, IsMulti>>>,
  ) => {
    const {
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format,
      isDisabled = false,
      parse,
      ...rest
    } = props;

    const {
      field: { ref, onChange: fieldOnChange, value, ...fieldProps },
      fieldState: { error },
    } = useController({ control, defaultValue, name, rules, shouldUnregister });

    const formattedValue = format ? format(value) : value;

    const onChange = (
      newValue: SelectMultiValue<Option> | SelectSingleValue<Option>,
    ): void => {
      fieldOnChange(parse ? parse(newValue) : newValue);
    };

    const errorMessage = error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div>
        <SelectAsync
          isDisabled={isDisabled}
          isInvalid={!!error}
          onChange={onChange}
          ref={refCallback}
          value={formattedValue}
          noOptionsMessage={() => 'Нет опций'}
          blurInputOnSelect
          {...rest}
          {...fieldProps}
        />
        <div className='mt-2 text-error'>{errorMessage}</div>
      </div>
    );
  },
) as <
  Values extends FieldValues,
  Option extends Record<string, unknown>,
  IsMulti extends boolean = false,
>(
  props: SelectFieldAsyncProps<Values, Option, IsMulti>,
) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
SelectAsyncField.displayName = 'SelectAsyncField';

export { SelectAsyncField };
