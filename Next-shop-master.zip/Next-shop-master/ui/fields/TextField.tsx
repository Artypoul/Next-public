import type {
  ChangeEventHandler,
  ComponentRef,
  FocusEventHandler,
  ForwardedRef,
  JSX,
  PropsWithoutRef,
} from 'react';
import type { FieldValues } from 'react-hook-form';
import type { TextFieldProps } from './types';

import { forwardRef, useRef, useState } from 'react';
import { useMergeRefs } from '@floating-ui/react';
import { useController } from 'react-hook-form';
import { twMerge } from 'tailwind-merge';

import { getSwitchedKey } from '@/lib/utils';

import { Input } from '../components/Input';

const TextField = forwardRef(
  <Values extends FieldValues>(
    props: PropsWithoutRef<TextFieldProps<Values>>,
    propRef: ForwardedRef<ComponentRef<typeof Input>>,
  ) => {
    const {
      staticValidate,
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
      format,
      isDisabled = false,
      parse,
      trimOnBlur = false,
      sanitizeOnBlur = false,
      keybordLayout,
      errorClassName = '',
      ...rest
    } = props;

    const {
      field: {
        ref,
        onBlur: fieldOnBlur,
        onChange: fieldOnChange,
        value,
        ...fieldProps
      },
      fieldState: { error },
    } = useController<Values>({
      control,
      defaultValue,
      name,
      rules,
      shouldUnregister,
    });

    const [staticErrorMessage, setStaticErrorMessage] = useState('');

    const switchedKey = useRef<{
      value: string;
      selection: {
        start: number;
        end: number;
      };
    }>(undefined);

    const formattedValue = format ? format(value) : value;

    const onBlur: FocusEventHandler<HTMLInputElement> = e => {
      let newValue = e.target.value;
      if (trimOnBlur) {
        newValue = newValue.trim();
      }

      if (sanitizeOnBlur && newValue) {
        newValue = newValue.replace(/^[^A-ZА-ЯёЁ]+|[^A-ZА-ЯёЁ]+$/gi, '');
      }

      if (newValue !== formattedValue) {
        fieldOnChange(parse ? parse(newValue) : newValue);
      }
      setStaticErrorMessage('');
      fieldOnBlur();
    };

    const onChange: ChangeEventHandler<HTMLInputElement> = e => {
      let newValue = e.target.value;
      if (switchedKey.current) {
        const { value, selection } = switchedKey.current;

        newValue =
          newValue.slice(0, selection.start) +
          value +
          newValue.slice(selection.end);

        setTimeout(() => {
          e.target.setSelectionRange(selection.start + 1, selection.start + 1);
        }, 0);

        switchedKey.current = undefined;
      }

      if (staticValidate) {
        const { pattern, message } = staticValidate;
        if (newValue && !pattern.test(newValue)) {
          setStaticErrorMessage(message ?? 'Недопустимый символ');
          return;
        }
        setStaticErrorMessage('');
      }
      if (newValue !== formattedValue) {
        fieldOnChange(parse ? parse(newValue) : newValue);
      }
    };

    const onKeyboardSwitch = (e: React.KeyboardEvent<HTMLInputElement>) => {
      if (!e.ctrlKey && !e.metaKey && e.key.length === 1) {
        const key = getSwitchedKey(e);
        if (key !== e.key) {
          const { selectionStart } = e.target as HTMLInputElement;
          switchedKey.current = {
            value: key,
            selection: {
              start: selectionStart ?? 0,
              end: (selectionStart ?? 0) + 1,
            },
          };
          return;
        }
      }
      switchedKey.current = undefined;
    };

    const errorMessage = staticErrorMessage || error?.message;
    const refCallback = useMergeRefs([ref, propRef]);

    return (
      <div>
        <Input
          disabled={isDisabled}
          isInvalid={!!error}
          onBlur={onBlur}
          onChange={onChange}
          onKeyDown={keybordLayout === 'fio' ? onKeyboardSwitch : undefined}
          ref={refCallback}
          spellCheck={false}
          value={formattedValue ?? ''}
          {...rest}
          {...fieldProps}
        />
        <div className={twMerge('mt-2 text-error', errorClassName)}>
          {errorMessage}
        </div>
      </div>
    );
  },
) as <Values extends FieldValues>(props: TextFieldProps<Values>) => JSX.Element;

//@ts-expect-error - displayName of forwarded ref with generic parameters
TextField.displayName = 'TextField';

export { TextField };
