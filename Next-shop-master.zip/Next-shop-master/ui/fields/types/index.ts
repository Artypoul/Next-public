import type {
  FieldValues,
  Path,
  PathValue,
  UseControllerProps,
} from 'react-hook-form';
import type { CheckboxProps } from '../../components/Checkbox';
import type { InputProps } from '../../components/Input';
import type { NumberInputProps } from '../../components/NumberInput';
import type { PhoneInputProps } from '../../components/PhoneInput';
import type {
  SelectProps,
  SelectPropsGroupBase,
} from '../../components/Select';
import type { SelectAsyncProps } from '../../components/Select/async';

export type DataObject = {
  code?: string | number;
  [key: string]: unknown;
};
export type DataFormat = DataObject | string | number | null | undefined | Date;

type FieldProps<
  FieldOwnProps extends object,
  Values extends FieldValues,
> = FieldOwnProps &
  UseControllerProps<Values> & {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    parse?: (value: any) => PathValue<Values, Path<Values>>;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    format?: (value: PathValue<Values, Path<Values>>) => any;
    isDisabled?: boolean;
  };

export type CheckboxFieldProps<Values extends FieldValues> = FieldProps<
  {
    showErrorMessage?: boolean;
  } & CheckboxProps,
  Values
>;

export type RadioFieldProps<
  Values extends FieldValues,
  Option extends Record<string, unknown>,
> = FieldProps<
  {
    showErrorMessage?: boolean;
  } & Omit<CheckboxProps, 'type' | 'label'> & {
      options: Option[];
    },
  Values
>;

export type PhoneFieldProps<Values extends FieldValues> = FieldProps<
  PhoneInputProps,
  Values
>;

export type SelectFieldProps<
  Values extends FieldValues,
  Option extends Record<string, unknown>,
  IsMulti extends boolean = false,
  Group extends SelectPropsGroupBase<Option> = SelectPropsGroupBase<Option>,
> = FieldProps<SelectProps<Option, IsMulti, Group>, Values> & {
  errorClassName?: string;
};

export type SelectFieldAsyncProps<
  Values extends FieldValues,
  Option extends Record<string, unknown>,
  IsMulti extends boolean = false,
  Group extends SelectPropsGroupBase<Option> = SelectPropsGroupBase<Option>,
> = FieldProps<SelectAsyncProps<Option, IsMulti, Group>, Values> & {
  errorClassName?: string;
};

export type TextFieldProps<Values extends FieldValues> = FieldProps<
  {
    trimOnBlur?: boolean;
    errorClassName?: string;
    sanitizeOnBlur?: boolean;
    keybordLayout?: 'fio';
    staticValidate?: {
      pattern: RegExp;
      message?: string;
    };
  } & Omit<InputProps, 'disabled'>,
  Values
>;

export type NumberFieldProps<Values extends FieldValues> = FieldProps<
  NumberInputProps,
  Values
>;
